"""Callbacks for Keras."""

from tensorflow import keras

from t9k import tuner


class AutoTuneFitCallback(keras.callbacks.Callback):
    """Logs training metrics for AutoTune.

    Examples:

        ```
        from t9k.tuner.keras import AutoTuneFitCallback

        model.fit(train_images,
                  train_labels,
                  epochs=10,
                  validation_split=0.2,
                  callbacks=AutoTuneFitCallback(metric='accuracy'))
        ```

    Args:
        metric: Name of the metric that is reported to tuner.
    """

    def __init__(self, metric='loss'):
        super(AutoTuneFitCallback, self).__init__()
        self.metric = metric

    def on_test_end(self, logs=None):
        tuner.report_intermediate_result(
            logs[self.metric],
            step=int(self.model.optimizer.iterations.numpy()))


class AutoTuneEvalCallback(keras.callbacks.Callback):
    """Logs testing metrics for AutoTune.

    Examples:

        ```
        from t9k.tuner.keras import AutoTuneEvalCallback

        model.evaluate(test_images,
                       test_labels,
                       callbacks=AutoTuneEvalCallback(metric='accuracy'))
        ```

    Args:
        metric: Name of the metric that is reported to tuner.
    """

    def __init__(self, metric='loss'):
        super(AutoTuneEvalCallback, self).__init__()
        self.metric = metric

    def on_test_end(self, logs=None):
        tuner.report_final_result(logs[self.metric])
