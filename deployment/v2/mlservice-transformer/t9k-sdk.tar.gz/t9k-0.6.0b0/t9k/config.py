"""Initialization of SDK config."""

import os
from pathlib import Path
import pprint
from typing import Any, Callable, Dict, ItemsView, Optional, Sequence, Union

from t9k.utils.file_utils import (abspath, expanduser, join, isfile,
                                  read_yaml_file)
from t9k.utils.object_utils import assert_type
from t9k.utils.url_utils import check_url
from t9k.utils.uuid_utils import is_uuid

if 'T9K_CONFIG' in os.environ:
    CONFIG_FILE_PATH = expanduser(os.getenv('T9K_CONFIG'))
else:
    CONFIG_FILE_PATH = join(str(Path.home()), '.t9k', 't9k-config.yaml')
CONFIG_CONTEXT = os.getenv('T9K_CONFIG_CONTEXT')
CONFIG_ITEMS = {'api_key': str, 'aistore_host': str, 'asset_hub_host': str}


class ConfigItem():
    """SDK config item.

    Attributes:
        name: Name of config item.
        value: Value of config item.
    """

    def __init__(
        self,
        name: str,
        value: Optional[Any] = None,
        processor: Union[Callable, Sequence[Callable], None] = None,
        validator: Union[Callable, Sequence[Callable], None] = None,
        hook: Union[Callable, Sequence[Callable], None] = None,
    ):
        self._name = name
        self._processor = processor
        self._validator = validator
        self._hook = hook

        self._value = self._validate(self._process(value))

    @property
    def name(self) -> str:
        return self._name

    @property
    def value(self) -> Any:
        value_ = self._value
        if self._hook is not None:
            hook = [self._hook] if callable(self._hook) else self._hook
            for h in hook:
                value_ = h(value_)
        return value_

    def _process(self, value: Any) -> Any:
        if value is not None and self._processor is not None:
            processor = [self._processor] if callable(
                self._processor) else self._processor
            for p in processor:
                value = p(value)
        return value

    def _validate(self, value: Any) -> Any:
        if value is not None:
            assert_type(value=value, type_=CONFIG_ITEMS[self.name])
            if self._validator is not None:
                validator = [self._validator] if callable(
                    self._validator) else self._validator
                for v in validator:
                    if not v(value):
                        # guaranteed error raised for invalid value
                        raise ValueError(
                            'Invalid value for config item {}: {}'.format(
                                self.name, value))
        return value

    def _update(self, value: Any) -> None:
        self._value = self._validate(self._process(value))

    def __str__(self) -> str:
        return str(self.value)

    def __repr__(self) -> str:
        return self.value.__repr__()


def _validate_api_key(api_key: str) -> bool:
    # empty string ok
    if not api_key or is_uuid(api_key):
        return True

    raise ValueError('Invalid API Key format')


def _validate_host(host: str) -> bool:
    # empty string ok
    if not host:
        return True
    check_url(host)
    return True


class Config():
    """SDK config."""

    def __init__(self):
        object.__setattr__(self, '_items', {})
        config_items = {
            'api_key': {
                'validator': _validate_api_key,
            },
            'aistore_host': {
                'validator': _validate_host,
            },
            'asset_hub_host': {
                'validator': _validate_host,
            },
        }
        for k, v in config_items.items():
            self._items[k] = ConfigItem(
                name=k,
                processor=v.get('processor', None),
                validator=v.get('validator', None),
                hook=v.get('hook', None),
            )
        self._load()

    def _load(self) -> None:
        """Loads from T9k config file."""
        path = abspath(CONFIG_FILE_PATH)
        if not isfile(path):
            return
        config = read_yaml_file(path)

        # defaults to current-context in the config
        context_name = CONFIG_CONTEXT or config['current-context']
        contexts = {i['name']: i for i in config['contexts']}
        if context_name not in contexts:
            return
        context = contexts[context_name]

        host = context['server']
        aistore_host = host + context['prefixes']['aistore']
        ah_host = host + context['prefixes']['asset-hub']
        self.update({'aistore_host': aistore_host, 'asset_hub_host': ah_host})

        if 'apikey' not in context['auth']:
            return
        api_key = context['auth']['apikey']
        self.update({'api_key': api_key})

    def __getitem__(self, key: str) -> Any:
        if key not in CONFIG_ITEMS:
            raise ValueError('Invalid SDK config item: {}'.format(key))
        return self._items[key].value

    def __setitem__(self, key: str, value: Any) -> None:
        if key not in CONFIG_ITEMS:
            raise ValueError('Invalid SDK config item: {}'.format(key))
        self._items[key]._update(value)

    def __delitem__(self, key: str) -> None:
        if key not in CONFIG_ITEMS:
            raise ValueError('Invalid SDK config item: {}'.format(key))
        del self._items[key]

    def update(self, new_config: Dict[str, Any]) -> None:
        for k, v in new_config.items():
            self[k] = v

    def get(self, key: str, default: Any = None) -> Any:
        try:
            return self.__getitem__(key)
        except (KeyError, ValueError):
            return default

    def to_dict(self) -> Dict[str, Any]:
        return {k: v.value for k, v in self._items.items()}

    def items(self) -> ItemsView[str, Any]:
        return self.to_dict().items()

    def __str__(self) -> str:
        return pprint.pformat(self._items)

    __repr__ = __str__


CONFIG = Config()
