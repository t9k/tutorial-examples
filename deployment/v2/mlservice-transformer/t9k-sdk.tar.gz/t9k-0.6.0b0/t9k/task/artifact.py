import json


def _gen_base_artifact(name=None, url=None, namespace=None, display=None, description=None, author=None):
    return {
        "name": name,
        "namespace": namespace,
        "url": url,
        "displayName": display,
        "description": description,
        "author": author
    }


def _gen_dataset_artifact(fileset_storage, name=None, url=None, namespace=None, display=None, description=None, author=None, content_type=None, single_file=True):
    artifact = _gen_base_artifact(name, url, namespace, display, description, author)
    artifact["contentType"] = content_type
    artifact["singleFile"] = single_file
    artifact["fileSetStorage"] = fileset_storage
    return artifact


def gen_dataset_artifact(key: str, fileset_storage, id=None, name=None, url=None, namespace=None, display=None, description=None, author=None, content_type=None, single_file=True, type="Dataset"):
    properties = _gen_dataset_artifact(fileset_storage, name, url, namespace, display,
                                     description, author, content_type, single_file)
    result = {
        "key": key,
        "id": id,
        "name": name,
        "type": "Dataset",
        "properties": properties
    }
    return result


def gen_docs_artifact(key: str, fileset_storage, id=None, name=None, url=None, namespace=None, display=None, description=None, author=None, content_type=None, single_file=True):
    properties = _gen_dataset_artifact(fileset_storage, name, url, namespace, display,
                                     description, author, content_type, single_file)
    result = {
        "key": key,
        "id": id,
        "name": name,
        "type": "Docs",
        "properties": properties
    }
    return result


def gen_source_code_artifact(key: str, fileset_storage, id=None, name=None, url=None, namespace=None, display=None, description=None, author=None, content_type=None, single_file=True):
    properties = _gen_dataset_artifact(fileset_storage, name, url, namespace, display,
                                     description, author, content_type, single_file)
    result = {
        "key": key,
        "id": id,
        "name": name,
        "type": "SourceCode",
        "properties": properties
    }
    return result


def gen_visualization_artifact(key: str, html_fileset_storage=None, tensorboard_fileset_storage=None, id=None, name=None, url=None, namespace=None, display=None, description=None, author=None):
    properties = _gen_base_artifact(name, url, namespace, display, description, author)
    properties["htmlVisualization"] = html_fileset_storage
    properties["tensorboardVisualization"] = tensorboard_fileset_storage

    result = {
        "key": key,
        "id": id,
        "name": name,
        "type": "Visualization",
        "properties": properties
    }
    return result


def gen_service_endpoint_artifact(key: str, host: str, port: int, protocol="HTTP", service_type=None, id=None, name=None, url=None, namespace=None, display=None, description=None, author=None):
    properties = _gen_base_artifact(name, url, namespace, display, description, author)
    properties["serviceType"] = service_type
    properties["host"] = host
    properties["port"] = port
    properties["protocol"] = protocol

    result = {
        "key": key,
        "id": id,
        "name": name,
        "type": "ServiceEndpoint",
        "properties": properties
    }
    return result


def gen_model_artifact(key: str, fileset_storage=None, modelman_secret_ref=None, id=None, name=None, url=None, namespace=None, display=None, description=None, author=None):
    properties = _gen_base_artifact(name, url, namespace, display, description, author)
    properties["fileSetStorage"] = fileset_storage
    properties["modelmanSecretRef"] = modelman_secret_ref

    result = {
        "key": key,
        "id": id,
        "name": name,
        "type": "Model",
        "properties": properties
    }
    return result


def write_artifacts_to_file(inputs, outputs, filename):
    if not isinstance(inputs, list):
        inputs = [inputs]
    if not isinstance(outputs, list):
        outputs = [outputs]
    artifacts = {
        "inputs": inputs,
        "outputs": outputs
    }
    with open(filename, "w") as f:
        json.dump(artifacts, f)
