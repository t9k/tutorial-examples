"""Utility functions for generating and checking UUID."""

import re
import uuid

check_uuid = re.compile(
    r'[0-9a-f]{8}\-[0-9a-f]{4}\-[0-9a-f]{4}\-[0-9a-f]{4}\-[0-9a-f]{12}')


def new_uuid() -> str:
    """Generates a new UUID as a string of hex digits in standard form."""
    return str(uuid.uuid4())


def is_uuid(id_: str) -> bool:
    """Tests whether the ID is a string of hex digits in standard form of
    UUID.
    """
    return bool(check_uuid.fullmatch(id_))
