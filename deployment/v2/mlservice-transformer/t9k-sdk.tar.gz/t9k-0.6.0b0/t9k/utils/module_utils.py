"""Utility functions for importing optional modules."""

import logging
import importlib
from types import ModuleType
from typing import Optional

_logger = logging.getLogger(__name__)

_NOT_IMPORTABLE = set()


def get_module(name: str,
               required: bool = False,
               error_msg: Optional[str] = None) -> Optional[ModuleType]:
    """Imports a module returns it.

    Absolute import is required.

    Args:
        name:
            Dot-separated module path, e.g. 'torch', 'torch.distributed'.
        required:
            If True and failed to import the module, raise a RuntimeError.
        error_msg:
            Error message used by logger and exception.

    Returns:
        Return the module if it is imported successfully, else return None.

    Raises:
        RuntimeError: Failed to import the module and required is True.
    """

    if name not in _NOT_IMPORTABLE:
        try:
            return importlib.import_module(name)
        except ModuleNotFoundError:
            _NOT_IMPORTABLE.add(name)

    if required:
        msg = error_msg or (
            "Failed to import module '{}', program will exit".format(name))
        _logger.error(msg)
        raise RuntimeError(msg)
    else:
        msg = error_msg or ("Failed to import module '{}', some features "
                            "will not work correctly".format(name))
        _logger.error(msg)
