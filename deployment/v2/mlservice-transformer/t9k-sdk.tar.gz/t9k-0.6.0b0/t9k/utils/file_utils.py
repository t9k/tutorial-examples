"""File utility functions."""

import functools
import hashlib
import json
import logging
import os
from typing import Any, Callable, Dict, Optional

import jsonstream
import yaml

_logger = logging.getLogger(__name__)

abspath = os.path.abspath
basename = os.path.basename
dirname = os.path.dirname
exists = os.path.exists
expanduser = os.path.expanduser
isabs = os.path.isabs
isdir = os.path.isdir
isfile = os.path.isfile
join = os.path.join
relpath = os.path.relpath

get_file_size = os.path.getsize


def get_file_hash(path: str, algorithm: str) -> str:
    """Returns file hash with specified algorithm."""
    h = getattr(hashlib, algorithm)()
    with open(path, 'rb') as file:
        data = file.read()
    h.update(data)
    digest = h.hexdigest()
    return digest


get_file_md5 = functools.partial(get_file_hash, algorithm='md5')
get_file_sha256 = functools.partial(get_file_hash, algorithm='sha256')


def human_readable_size(size: int, suffix='B'):
    """Converts file size in bytes to human readable form."""
    for unit in ['', 'K', 'M', 'G', 'T', 'P', 'E', 'Z']:
        if abs(size) < 1024.0:
            return f'{size:3.1f}{unit}{suffix}'
        size /= 1024.0
    return f'{size:.1f}Y{suffix}'


def read_json_file(file_path: str, error_msg: Optional[str] = None) -> Any:
    """Parses the JSON doc in a file to an object and returns it.

    Raises:
        FileNotFoundError: File does not exist.
        IOError: Permission denied.
        json.decoder.JSONDecodeError: JSON parsing error.
    """
    try:
        with open(file_path, 'rt') as f:
            return json.loads(f.read())
    except json.decoder.JSONDecodeError as e:
        msg = error_msg or 'Invalid JSON document'
        _logger.error(msg)
        raise e


def read_jsons_file(file_path: str, error_msg: Optional[str] = None) -> Any:
    """Parses multiple JSON docs in a file to an object list and returns it.

    Raises:
        FileNotFoundError: File does not exist.
        IOError: Permission denied.
        json.decoder.JSONDecodeError: JSON parsing error.
    """
    try:
        with open(file_path, 'rt') as f:
            return list(jsonstream.loads(f.read()))
    except json.decoder.JSONDecodeError as e:
        msg = error_msg or 'Invalid JSON document'
        _logger.error(msg)
        raise e


def write_json_file(file_path: str, data: Any, append: bool = False) -> None:
    """Serializes an object into JSON formatted string and writes to a file.

    Raises:
        IOError: Permission denied.
    """
    if append:
        with open(file_path, 'at') as f:
            f.write(json.dumps(data) + '\n')
    else:
        with open(file_path, 'wt') as f:
            f.write(json.dumps(data))


def update_json_file(
        file_path: str,
        preprocessor: Optional[Callable[[Dict[str, Any]], Dict[str,
                                                               Any]]] = None,
        update: Optional[Dict[str, Any]] = None,
        postprocessor: Optional[Callable[[Dict[str, Any]], Dict[str,
                                                                Any]]] = None,
        not_exist_ok: bool = True,
        not_exist_initial: Optional[Dict[str, Any]] = None) -> None:
    """Updates the JSON doc in a file.

    Args:
        file_path:
            Path of the file to be updated.
        preprocessor:
            A function used to preprocess the data directly after it is read.
        update:
            A dict used to update the data dict.
        postprocessor:
            A function used to postprocess the data directly before it is
            written.
        not_exist_ok:
            If True and the file does not exist, make the file; if False and
            the file does not exist, raise a FileNotFoundError.
        not_exist_initial:
            If the file does not exist and `not_exist_ok` is True, this dict
            will be initial data.

    Raises:
        FileNotFoundError: File does not exist and `not_exist_ok` is False.
        IOError: Permission denied.
        json.decoder.JSONDecodeError: JSON parsing error.
    """
    if os.path.isfile(file_path):
        data = read_json_file(file_path)
        if preprocessor:
            data = preprocessor(data)
    elif not_exist_ok:
        data = not_exist_initial or {}
    else:
        msg = 'File does not exist: `{}`'.format(file_path)
        raise FileNotFoundError(msg)
    assert isinstance(data, dict)

    if update:
        data.update(update)
    if postprocessor:
        data = postprocessor(data)
    write_json_file(file_path, data)


def read_yaml_file(file_path: str, error_msg: Optional[str] = None) -> Any:
    """Parses the first YAML doc in a file to an object and returns it.

    Raises:
        IOError: Permission denied.
        yaml.scanner.ScannerError: YAML parsing error.
    """
    try:
        with open(file_path, 'rt') as f:
            return yaml.safe_load(f.read())
    except yaml.scanner.ScannerError as e:
        msg = error_msg or 'Invalid YAML document'
        _logger.error(msg)
        raise e


def write_yaml_file(file_path: str, data: Any, append: bool = False) -> None:
    """Serializes an object into YAML stream and writes to a file.

    Raises:
        IOError: Permission denied.
    """
    mode = 'at' if append else 'wt'
    with open(file_path, mode) as f:
        f.write(yaml.dump(data, sort_keys=False))


def update_yaml_file(
        file_path: str,
        preprocessor: Optional[Callable[[Any], Dict[str, Any]]] = None,
        update: Optional[Dict[str, Any]] = None,
        postprocessor: Optional[Callable[[Dict[str, Any]], Any]] = None,
        not_exist_ok: bool = True,
        not_exist_initial: Optional[Dict[str, Any]] = None) -> None:
    """Updates the first YAML doc in a file.

    Args:
        file_path:
            Path of the file to be updated.
        preprocessor:
            A function used to preprocess the data directly after it is read.
            Must return a dict.
        update:
            A dict used to update the data dict.
        postprocessor:
            A function used to postprocess the data directly before it is
            written.
        not_exist_ok:
            If True and the file does not exist, make the file; if False and
            the file does not exist, raise a FileNotFoundError.
        not_exist_initial:
            If the file does not exist and `not_exist_ok` is True, this dict
            will be initial data.

    Raises:
        FileNotFoundError: File does not exist.
        IOError: Permission denied.
        yaml.scanner.ScannerError: YAML parsing error.
    """
    if os.path.isfile(file_path):
        data = read_yaml_file(file_path)
        if preprocessor:
            data = preprocessor(data)
    elif not_exist_ok:
        data = not_exist_initial or {}
    else:
        msg = 'File does not exist: `{}`'.format(file_path)
        raise FileNotFoundError(msg)
    assert isinstance(data, dict)

    if update:
        data.update(update)
    if postprocessor:
        data = postprocessor(data)
    write_yaml_file(file_path, data)
