"""Utility functions for operating Python objects."""

import logging
from typing import Any, Optional

_logger = logging.getLogger(__name__)


def assert_type(value: Any, type_: type, error_msg: Optional[str] = None):
    """Asserts that value is of specified type."""
    if isinstance(value, type_):
        return

    msg = error_msg or ('{} instance expected but {} instance received'.format(
        type_.__name__,
        type(value).__name__))
    _logger.error(msg)
    raise TypeError(msg)
