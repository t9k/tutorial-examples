"""URL utility functions."""
from urllib3.util.url import parse_url
from urllib3.exceptions import LocationParseError
from requests.exceptions import InvalidURL, MissingSchema


def check_url(url: str) -> None:
    try:
        scheme, _, host, _, _, _, _ = parse_url(url)
    except LocationParseError as e:
        raise InvalidURL(*e.args) from e

    if not scheme:
        raise MissingSchema('Invalid URL "{}": No schema supplied'.format(url))

    if not host:
        raise InvalidURL('Invalid URL "{}": No host supplied'.format(url))
