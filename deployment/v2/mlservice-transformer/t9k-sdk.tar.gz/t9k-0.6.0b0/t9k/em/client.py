"""EM client."""

import json
import logging
import math
import os
from typing import Any, BinaryIO, Dict, Iterator, List, Optional

import requests
from requests import HTTPError
import simplejson
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

from t9k import CONFIG
from t9k.utils.datetime_utils import get_local_now_iso
from t9k.utils.file_utils import dirname, isfile, join, get_file_size
from t9k.utils.print_utils import red, cyan, magenta, black, eprint
from t9k.utils.url_utils import check_url
from t9k.utils.uuid_utils import is_uuid

_logger = logging.getLogger(__name__)

DOWNLOAD_CHUNK_SIZE = 16384  # 16KB


def _all_methods_online_only(cls):

    def online_only(func):

        def wrapper(self, *args, offline_ok=False, **kwargs):
            if self.online:
                return func(self, *args, **kwargs)
            elif offline_ok:
                return
            else:
                _logger.error('Cannot correspond with AIStore server for not '
                              'logging in, please first call `em.login()`')
                raise RuntimeError(
                    'Cannot correspond with AIStore server for not'
                    ' logging in, please first call `em.login()`')

        return wrapper

    for attr in cls.__dict__:
        if callable(getattr(cls, attr)) and attr not in [
                '__init__', 'test_ais_connection', 'get_username', 'request'
        ]:
            setattr(cls, attr, online_only(getattr(cls, attr)))
    return cls


@_all_methods_online_only
class _EMClient(object):
    """Corresponds with AIStore server.

    Attributes:
        api_key:
            API Key for requesting server.
        headers:
            HTTP headers of request.
        online:
            Flag to indicate whether client can connect to AIStore server. If
            False, any method call (except for magic methods) without kwarg
            `offline_ok = True` will raise a RuntimeError, any with kwarg
            `offline_ok = True` will do nothing.
        host:
            URL of server.
        timeout:
            How many seconds to wait for server to send data before giving up.
    """

    def __init__(self):
        self.ais_host = None
        self.api_key = None

        self.headers = {}
        self.timeout = None

        self.online = False

    def _create_node(self, node_data: Dict[str, Any]) -> str:
        """Creates a node and returns its ID."""
        node_path = '{}/{}'.format(node_data['parent'], node_data['name'])
        node_kind = node_data['type']
        _logger.debug('Create %s %s', node_kind, node_path)

        url = '{}/apis/v1/nodes'.format(self.ais_host)
        try:
            return self.request(method='POST', url=url,
                                json_data=node_data)['id']
        except HTTPError as e:
            resp = e.response
            if (resp.status_code == 400
                    and 'Invalid conflicting node Name' in resp.text):
                raise RuntimeError(
                    "Node already exists: '{}'".format(node_path)) from e
            elif resp.status_code == 404 and 'node not found' in resp.text:
                path = resp.text.rsplit(sep='[', maxsplit=1)[1][:-1]
                raise RuntimeError(
                    "Folder does not exist: '{}'".format(path)) from e
            else:
                raise e

    def _get_node_data(self, node_kind: str, node: str) -> Dict[str, Any]:
        """Gets data of a node."""
        node_kind = node_kind.capitalize()
        _logger.debug('Get data of %s %s', node_kind, node)

        url = '{}/apis/v1/nodes/info'.format(self.ais_host)
        params = {'node': node}
        try:
            return self.request(method='GET', url=url, params=params)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 404 and 'node not found' in resp.text:
                raise RuntimeError(
                    "Node does not exist: '{}'".format(node)) from e
            else:
                raise e

    def _update_node(self, node_kind: str, node_data: Dict[str, Any]) -> None:
        """Updates data of a node."""
        node_kind = node_kind.capitalize()
        node_data_copy = node_data.copy()
        node = node_data_copy.pop('node')
        _logger.debug('Update %s %s with data %s', node_kind, node,
                      node_data_copy)

        url = '{}/apis/v1/nodes'.format(self.ais_host)
        try:
            self.request(method='PUT', url=url, json_data=node_data)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 400 and 'conflicting node Name' in resp.text:
                name = node_data['name']
                _logger.error('%s name %s already exists', node_kind,
                              red(name))
                raise RuntimeError("{} name already exists: '{}'".format(
                    node_kind, name)) from e
            else:
                raise e

    def _delete_node(self, node_kind: str, node_path: str) -> None:
        """Deletes a node by path."""
        _logger.debug('Delete %s %s', node_kind, node_path)

        url = '{}/apis/v1/nodes'.format(self.ais_host)
        node_data = {'node': node_path}
        self.request(method='DELETE', url=url, json_data=node_data)

    def _traverse_pages(self, url: str,
                        params: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Traverses all pages and returns a complete list of data."""
        all_data = []
        page = 1

        while True:
            params['page'] = page
            data = self.request(method='GET', url=url, params=params)
            if data['data'] is None:
                break
            all_data.extend(data['data'])
            pagination = data['pagination']
            if page * pagination['size'] >= pagination['total']:
                break
            page += 1

        return all_data

    def create_folder(self, folder_path: str, labels: List[str],
                      description: str) -> str:
        """Creates a Folder and returns its ID."""
        parent, name = folder_path.rsplit(sep='/', maxsplit=1)
        folder_data = {
            'parent': parent,
            'name': name,
            'labels': labels,
            'description': description,
            'type': 'Folder',
            'storageType': 0,
            'extra': json.dumps({'createdTimestamp': get_local_now_iso()}),
        }
        return self._create_node(node_data=folder_data)

    def create_run(self,
                   name: str,
                   parent: str,
                   labels: List[str],
                   description: str,
                   extra: str = '') -> str:
        """Creates a Run and returns its ID."""
        asset_data = {
            'parent': parent,
            'name': name,
            'labels': labels,
            'description': description,
            'type': 'Run',
            'storageType': 2,
            'extra': extra
        }
        return self._create_node(node_data=asset_data)

    def delete_run(self, run_path: str) -> None:
        """Deletes a Run.

        Raises:
            requests.HTTPError: Run with `run_path` does not exist.
        """
        self._delete_node(node_kind='Run', node_path=run_path)

    def download(self, node_path: str, save_dir: str, node_type: str,
                 show_progress: bool) -> None:
        """Downloads all objects of specified Run or Artifact.

        Args:
            node_path:
                Path of the Run or Artifact in server.
            save_dir:
                Local directory which objects are downloaded to.
            node_type:
                Type of the node.
            show_progress:
                Whether to show download progress.
        """
        _logger.info('Downloading all objects of %s %s to local directory %s',
                     node_type, cyan(node_path), black(save_dir,
                                                       underline=True))
        objects_data = self._list_object(node_path=node_path)
        total = len(objects_data)
        for i, obj in enumerate(objects_data):
            file_path = join(save_dir, obj['path'].lstrip('/'))
            os.makedirs(dirname(file_path), exist_ok=True)
            if show_progress:
                _logger.info('Downloading object %s/%s %s:', i + 1, total,
                             cyan(obj['path']))
            self._download_object(node_path=node_path,
                                  key=obj['path'],
                                  size=obj['size_bytes'],
                                  download_path=file_path,
                                  show_progress=show_progress)

    def create_artifact(self, name: str, parent: str, labels: List[str],
                        description: str, extra: str) -> str:
        """Creates a Artifact and returns its ID."""
        asset_data = {
            'parent': parent,
            'name': name,
            'labels': labels,
            'description': description,
            'type': 'Artifact',
            'storageType': 2,
            'extra': extra
        }
        return self._create_node(node_data=asset_data)

    def delete_artifact(self, artifact_path: str) -> None:
        """Deletes an Artifact.

        Raises:
            requests.HTTPError: Artifact with `artifact_path` does not exist.
        """
        self._delete_node(node_kind='Artifact', node_path=artifact_path)

    def get_association(self, node_id: str) -> Dict[str, List[Dict[str, str]]]:
        """Gets associations of a node."""
        _logger.debug('Get inputs and outputs of Node %s', node_id)
        url = '{}/apis/v1/graphs'.format(self.ais_host)
        params = {'current': node_id}
        return self.request(method='GET', url=url, params=params)

    def upload_association(self, associations: List[Dict[str, str]]) -> None:
        """Uploads additional associations between nodes."""
        _logger.debug('Uploads additional associations: %s', associations)
        url = '{}/apis/v1/graphs'.format(self.ais_host)
        data = {'graphs': associations}
        self.request(method='POST', url=url, json_data=data)

    def _list_object(self, node_path: str) -> Dict[str, Any]:
        """Lists objects of specified Run or Artifact."""
        _logger.debug('List objects of node %s', node_path)
        url = '{}/apis/v1/objects/ls'.format(self.ais_host)
        params = {'path': '{}'.format(node_path), 'size': 1000}
        return self._traverse_pages(url=url, params=params)

    def _upload_object(self, node_path: str, key: str, file_path: str,
                       show_progress: bool) -> Dict[str, Any]:
        """Uploads an object to specified Run or Artifact."""
        object_path = '{}/{}'.format(node_path, key)
        _logger.debug('Upload file %s to object path %s', file_path,
                      object_path)

        assert isfile(file_path)
        size = get_file_size(file_path)
        if size <= 100 * 1024 * 1024:  # 100MiB
            if show_progress:
                print(' ' * 9 + 'Uploading...', end='', flush='True')
            url = '{}/apis/v1/objects'.format(self.ais_host)
            params = {'path': object_path}
            files = {'content': open(file_path, 'rb')}
            data = self.request(method='POST',
                                url=url,
                                params=params,
                                files=files)
            if show_progress:
                print('\r' + ' ' * 9 + 'Done' + ' ' * 8, flush='True')
            return data

        elif size <= 25_000_000 * 1024 * 1024:  # 25,000,000MiB, ~23.842TiB
            url_create = '{}/apis/v1/objects/multipart'.format(self.ais_host)
            params = {'path': object_path}
            upload_id = self.request(method='POST',
                                     url=url_create,
                                     params=params)['uploadId']

            def read_in_chunks(file_object: BinaryIO,
                               chunk_size: int) -> Iterator[bytes]:
                while True:
                    data = file_object.read(chunk_size)
                    if not data:
                        break
                    yield data

            # Expressed in units of MiB, the chunk size is determined by taking
            # the square root of the object size and rounding down, e.g.
            #
            # | object size             | chunk num * size           |
            # | ----------------------- | -------------------------- |
            # | 100MiB                  | 10 * 10Mi                  |
            # | 1,000MiB (~0.98GiB)     | 33 * 31Mi                  |
            # | 10,000MiB (~9.8GiB)     | 100 * 100 MiB              |
            # | 100,000MiB (~98GiB)     | 317 * 316Mi                |
            # | 1,000,000MiB (~0.95TiB) | 1000 * 1000 MiB (~0.98GiB) |
            # | 10,000,000MiB (~9.5TiB) | 3163 * 3162 MiB (~3.1GiB)  |
            # | 25,000,000MiB (~24TiB)  | 5000 * 5000 MiB (~4.9GiB)  |

            size_in_mib = size / 1024**2
            chunk_size_in_mib = math.floor(math.sqrt(size_in_mib))
            chunk_size = chunk_size_in_mib * 1024**2

            progress = Progress(
                ' ' * 8,
                BarColumn(bar_width=None),
                '[progress.percentage]{task.percentage:>3.1f}%',
                '•',
                DownloadColumn(),
                '•',
                TransferSpeedColumn(),
                '•',
                TimeRemainingColumn(),
                console=Console(stderr=True))
            with progress:
                task_id = progress.add_task('upload', start=False)
                progress.update(task_id, total=size)
                with open(file_path, 'rb') as f:
                    parts = []
                    progress.start_task(task_id)
                    for n, piece in enumerate(read_in_chunks(f, chunk_size),
                                              start=1):
                        url_upload = (
                            '{}/apis/v1/objects/multipart/{}').format(
                                self.ais_host, upload_id)
                        params = {'path': object_path, 'partNumber': n}

                        files = {'content': piece}
                        etag = self.request(method='PUT',
                                            url=url_upload,
                                            params=params,
                                            files=files)['eTag']

                        parts.append({'etag': etag, 'partNumber': n})
                        progress.update(task_id, advance=len(piece))

                    url_complete = ('{}/apis/v1/objects/multipart/{}').format(
                        self.ais_host, upload_id)
                    params = {'path': object_path}
                    self.request(method='POST',
                                 url=url_complete,
                                 params=params,
                                 json_data={'parts': parts})
                    return {
                        'path': key,
                        'path_type': 'object',
                        'size_bytes': size
                    }
        else:
            size_in_tib = round(size / 1024**4, 2)
            _logger.error(
                'Cannot upload object %s, its size %sTiB exceeds the limit '
                'of ~23.842TiB', *red(key, size_in_tib))
            raise RuntimeError(
                'Cannot upload object {}, its size {}TiB exceeds the limit '
                'of ~23.842TiB'.format(key, size_in_tib))

    def _download_object(self, node_path: str, key: str, size: int,
                         download_path: str, show_progress: bool) -> None:
        """Downloads an object of specified Run or Artifact."""
        object_path = join(node_path, key.lstrip('/'))
        _logger.debug('Download object %s to local path %s', object_path,
                      download_path)
        url = '{}/apis/v1/objects'.format(self.ais_host)
        params = {'path': object_path, 'apikey': self.api_key}

        _logger.debug('Request info:')
        _logger.debug('  URL: %s', url)
        _logger.debug('  method: GET')
        _logger.debug('  params: %s', params)

        with requests.get(url=url,
                          params=params,
                          stream=True,
                          timeout=self.timeout,
                          allow_redirects=False) as r:
            r.raise_for_status()
            with open(download_path, 'wb') as f:
                if show_progress:
                    progress = Progress(
                        ' ' * 8,
                        BarColumn(bar_width=None),
                        '[progress.percentage]{task.percentage:>3.1f}%',
                        '•',
                        DownloadColumn(),
                        '•',
                        TransferSpeedColumn(),
                        '•',
                        TimeRemainingColumn(),
                        console=Console(stderr=True))
                    with progress:
                        task_id = progress.add_task('download', start=False)
                        progress.update(task_id, total=size)
                        progress.start_task(task_id)
                        for chunk in r.iter_content(
                                chunk_size=DOWNLOAD_CHUNK_SIZE):
                            f.write(chunk)
                            progress.update(task_id, advance=len(chunk))
                else:
                    for chunk in r.iter_content(
                            chunk_size=DOWNLOAD_CHUNK_SIZE):
                        f.write(chunk)

    def make_folder(self, folder_path: str) -> str:
        """Makes a folder if it does not exist and returns its ID."""
        _logger.debug('Make folder %s in server if it does not exist',
                      folder_path)

        try:
            folder_id = self._get_node_data(node_kind='Folder',
                                            node=folder_path)['id']
            _logger.debug("Folder '%s' exists and is NOT made", folder_path)
        except RuntimeError as e:
            msg = e.args[0]
            if 'does not exist' in msg:
                # recursively make
                if folder_path.count('/') >= 3:
                    self.make_folder(folder_path=dirname(folder_path))
                folder_id = self.create_folder(folder_path=folder_path,
                                               labels=[],
                                               description='')
                _logger.debug("Folder '%s' does not exist and is made",
                              folder_path)
            else:
                raise e

        return folder_id

    def test_ais_connection(self) -> None:
        """Tests connection to server."""
        _logger.debug('Test connection to AIStore server with URL %s',
                      self.ais_host)

        try:
            url = '{}/oauth2/userinfo'.format(self.ais_host)
            params = {'apikey': self.api_key}
            self.user_name = self.request(method='GET', url=url,
                                          params=params)['preferred_username']
            _logger.debug("Get user name '%s'", self.user_name)

            url = '{}/apis/v1/nodes'.format(self.ais_host)
            params = {
                'parent': '/{}'.format(self.user_name),
                'type': 'Folder',
            }
            resp = self.request(method='GET', url=url, params=params)
            # resp should be like {'data': [...], 'pagination': [...]}
            assert 'data' in resp
            assert 'pagination' in resp
        except requests.ConnectionError as e:
            _logger.error(
                'Unable to connect to AIStore server, please check '
                'your network connection, status of server, or URL of server')
            raise e
        except RuntimeError as e:
            if e.args[0] == 'Incorrect URL':
                _logger.error(
                    'Incorrect URL of AIStore server: %s, please '
                    'check the provided URL', red(self.ais_host))
                raise RuntimeError(
                    "Incorrect URL of AIStore server: '{}'".format(
                        self.ais_host)) from e

        _logger.info('Logged in to AIStore server as user %s',
                     magenta(self.user_name, bold=True))

    def request(self,
                method: str,
                url: str,
                params: Optional[Dict[str, Any]] = None,
                json_data: Optional[Any] = None,
                data: Optional[Any] = None,
                files: Optional[Dict[str, Any]] = None,
                headers: Optional[Dict[str, str]] = None) -> str:
        """Sends request to server.

        Args:
            method: Method of HTTP request.
            url: URL of HTTP request.
            params: Query parameters of HTTP request.
            data: Contents to be sent in the request body.
            headers: Headers of HTTP request.

        Returns:
            A dict parsed from JSON in content of the response, or a string of
            content of the response if the response body does not contain valid
            JSON.

        Raises:
            requests.HTTPError: An HTTP error occurred.
        """
        params = params if params else {}
        params['apikey'] = self.api_key
        headers = headers if headers else self.headers

        _logger.debug('Request info:')
        _logger.debug('  URL: %s', url)
        _logger.debug('  method: %s', method)
        _logger.debug('  params: %s', params)
        if json_data:
            _logger.debug('  json: %s', json_data)
        if data:
            _logger.debug('  data: %s', data)
        if files:
            _logger.debug('  file: %s', files)

        resp = requests.request(method=method,
                                url=url,
                                params=params,
                                json=json_data,
                                data=data,
                                files=files,
                                headers=headers,
                                timeout=self.timeout,
                                allow_redirects=False)
        if not resp.ok:
            http_error_msg = ''
            if resp.status_code == 302:
                _logger.error('API Key not provided')
                raise ValueError('API Key not provided')
            if 400 <= resp.status_code < 500:
                if resp.status_code == 400 and resp.text.startswith(
                        'api key') and resp.text.endswith('not found\n'):
                    _logger.error(
                        'API Key not found, please check the provided API Key')
                    raise RuntimeError('API Key not found')
                elif resp.status_code == 400 and resp.text.startswith(
                        'query is needed'):
                    _logger.error(
                        'Empty string provided for API Key, please provide '
                        'a valid API Key')
                    raise ValueError('Empty string provided for API Key')
                if (resp.status_code == 403
                        and resp.text == 'permission denied'):
                    _logger.error(
                        'Permission denied, please confirm that the provided '
                        'API Key has corresponding permissions')
                    raise RuntimeError('Permission denied')
                elif resp.status_code == 404 and not resp.text:
                    raise ValueError('Incorrect URL')
                else:
                    http_error_msg = '%s Client Error: %s for URL %s' % (
                        resp.status_code, resp.reason, resp.url)
                    if resp.text:
                        http_error_msg = http_error_msg + ': ' + resp.text
            elif 500 <= resp.status_code < 600:
                http_error_msg = '%s Server Error: %s for URL %s' % (
                    resp.status_code, resp.reason, resp.url)
                if resp.text:
                    http_error_msg = http_error_msg + ': ' + resp.text
            if http_error_msg:
                raise requests.HTTPError(http_error_msg, response=resp)
        _logger.debug('Request succeeded')

        try:
            return resp.json()
        except simplejson.JSONDecodeError:
            return resp.text


CLIENT = _EMClient()


def login(ais_host: Optional[str] = None,
          api_key: Optional[str] = None,
          timeout: Optional[int] = None) -> None:
    """Logs in to AIStore server.

    Sets up the client that corresponds with AIStore server.

    Args:
        ais_host:
            URL of AIStore server. Defaults to `t9k.CONFIG['aistore_host']`.
        api_key:
            API Key for requesting server. Defaults to `t9k.CONFIG['api_key']`.
        timeout:
            How many seconds to wait for server to send data before giving up.

    Raises:
        requests.HTTPError:
            Unable to connect to the server and `unable_to_connect_ok` is
            False.
    """
    if ais_host:
        CLIENT.ais_host = ais_host
    elif CONFIG['aistore_host']:
        CLIENT.ais_host = CONFIG['aistore_host']
        ais_host = CONFIG['aistore_host']
    else:
        _logger.error('AIStore host not provided by either argument or config')
        raise ValueError('AIStore host not provided')

    if api_key:
        CLIENT.api_key = api_key
    elif CONFIG['api_key']:
        CLIENT.api_key = CONFIG['api_key']
        api_key = CONFIG['api_key']
    else:
        _logger.error('API Key not provided by either argument or config')
        raise ValueError('API Key not provided')

    check_url(CLIENT.ais_host)
    if not is_uuid(CLIENT.api_key):
        _logger.error('Invalid API Key format')
        raise ValueError('Invalid API Key format')

    CLIENT.ais_host = CLIENT.ais_host.rstrip('/')
    CLIENT.test_ais_connection()

    CLIENT.timeout = timeout
    CLIENT.online = True


def logout() -> None:
    """Logs out from the current AIStore server.

    The client is unset, it can no longer correspond with AIStore server until
    it is set up again.
    """
    if CLIENT.online:
        _logger.info('Logged out from AIStore server %s',
                     magenta(CLIENT.ais_host))
        CLIENT.online = False
    else:
        _logger.warning(
            'Not log out, for having not logged in to any AIStore server')


def _login_for_cli_cmd() -> None:
    """Logs in to AIStore server, for functions in `cli` module."""
    CLIENT.ais_host = CONFIG['aistore_host']
    CLIENT.api_key = CONFIG['api_key']
    check_url(CLIENT.ais_host)
    if not is_uuid(CLIENT.api_key):
        eprint('Invalid API Key format')
    CLIENT.test_ais_connection()
    CLIENT.online = True
    return


# TODO: Spawn a new process to upload Run or Artifact asynchronously and
# periodically.

# for test
if __name__ == '__main__':
    pass
