"""Run class."""

import json
import logging
import os
from typing import Any, Dict, List, Optional, Union

from t9k.em.client import CLIENT
from t9k.em.containers import Params, Metrics
from t9k.em.artifact import Artifact
from t9k.ah.core import Model, Dataset, Branch, Tag, Commit
from t9k.utils.decorators import called_once_only_each_instance
from t9k.utils.datetime_utils import get_local_now_iso
from t9k.utils.file_utils import (abspath, basename, dirname, isfile, isdir,
                                  join, relpath, read_yaml_file,
                                  write_yaml_file)
from t9k.utils.git_utils import get_git_repo_data
from t9k.utils.local_platform_utils import get_platform_data
from t9k.utils.print_utils import black, blue, cyan, red
from t9k.utils.sys_utils import _add_stdout_logfile, _remove_stdout_logfile

_logger = logging.getLogger(__name__)

EM_RUN_PARENT_DIR = os.getenv('EM_RUN_PARENT_DIR', '.em/runs')


class Run(object):
    """Implementation of Run, a run of a specific model for certain ML task.

    Args:
        metadata:
            Metadata to initialize a new Run.
        hparams:
            Hyperparameters of the Run.
        metrics:
            Metrics of the Run.
        platform:
            Platform information of the Run.
        git:
            Git information of the Run.

    Attributes:
        name:
            Name of the Run.
        labels:
            Labels of the Run.
        description:
            Description of the Run.
        start_timestamp:
            Start timestamp of the Run.
        end_timestamp:
            End timestamp of the Run.
        status:
            Status of the Run.
        alternative_name:
            Alternative name of the Run.
        associations:
            Input and output resources of the Run.
        hparams:
            Hyperparameters of the Run.
        metrics:
            Metrics produced in the Run.
        platform:
            Platform information of the Run.
        git:
            Git information of the Run.
        remote:
            Upload and download history of the Run.
        local:
            Local directory of the Run.
    """

    def __init__(self,
                 metadata: Dict[str, Any],
                 hparams: Optional[Dict[str, Any]] = None,
                 metrics: Optional[Metrics] = None,
                 platform: Optional[Dict[str, Any]] = None,
                 git: Optional[Dict[str, Any]] = None):
        self.parse_from_dict(metadata)
        self.hparams = Params(upload=self._update_hparams,
                              init_hparams=hparams)
        self._metrics = metrics or {}
        self._platform = platform
        self._git = git
        self._prepare_local_dir()

    @property
    def name(self) -> str:
        return self._name

    @property
    def labels(self) -> List[str]:
        return self._labels

    @property
    def description(self) -> str:
        return self._description

    @property
    def start_timestamp(self) -> str:
        return self._start_timestamp

    @property
    def end_timestamp(self) -> str:
        return self._end_timestamp

    @property
    def status(self) -> str:
        return self._status

    @property
    def alternative_name(self) -> str:
        return self._alternative_name

    @property
    def associations(self) -> Dict[str, List[Dict[str, str]]]:
        return self._associations

    @property
    def asso(self) -> Dict[str, List[Dict[str, str]]]:
        return self._associations

    @property
    def metrics(self) -> Metrics:
        return self._metrics

    @property
    def platform(self) -> Dict[str, Any]:
        return self._platform

    @property
    def git(self) -> Dict[str, Any]:
        return self._git

    @property
    def remote(self) -> List[Dict[str, str]]:
        return self._remote

    @property
    def local(self) -> str:
        return self._local

    def parse_from_dict(self, data: Dict[str, Any]) -> None:
        """Parses a Run instance from a dict."""
        self._name = data['name']
        self._labels = data['labels']
        self._description = data['description']
        self._start_timestamp = data['startTimestamp']
        self._end_timestamp = data['endTimestamp']
        self._status = data['status']
        self._alternative_name = data['alternativeName']
        self._associations = data['associations']
        self._remote = data['remote']

    def to_dict(self) -> Dict[str, Any]:
        """Converts Run instance to a dict and returns it."""
        return {
            'kind': 'Run',
            'name': self.name,
            'labels': self.labels,
            'description': self.description,
            'startTimestamp': self.start_timestamp,
            'endTimestamp': self.end_timestamp,
            'status': self.status,
            'alternativeName': self.alternative_name,
            'associations': self.associations,
            'remote': self.remote,
        }

    def _prepare_local_dir(self) -> None:
        """Prepares local directory and files for Run.

        Under `EM_RUN_PARENT_DIR` create a directory of Run, then under the
        directory create some files to store Run data.

        If the directory already exists, do nothing. This occurs when loading
        a local Run.
        """
        self._local = join(EM_RUN_PARENT_DIR, self._alternative_name)
        self._locals = Run._get_local_paths(self._local)
        if not isdir(self._local):
            os.makedirs(self._local)
            os.makedirs(self._locals['metrics'])
            # metadata.yaml
            write_yaml_file(self._locals['metadata'], self.to_dict())
            # index.yaml
            write_yaml_file(self._locals['index'], self._get_index())
            # hyperparameters.yaml
            write_yaml_file(self._locals['hparams'], self.hparams.as_dict())

            _logger.info('Run %s saved to local directory %s', cyan(self.name),
                         black(self._local, underline=True))

        # platform.yaml
        self._update_platform()
        # git.yaml
        self._update_git()
        # stdout.log
        _add_stdout_logfile(self._locals['log'])

    @staticmethod
    def _load_local_dir(dir: str) -> 'Run':
        """Implements loading a Run from local directory."""
        _logger.debug('Load Run from local directory %s', dir)

        local_paths = Run._get_local_paths(dir)

        for n, p in local_paths.items():
            if n == 'metrics':
                if not isdir(p):
                    _logger.error(
                        'Failed to load Run from local directory: %s, '
                        'subdirectory %s is missing', *red(dir, p))
                    raise FileNotFoundError(
                        "Missing subdirectory of Run: '{}'".format(p))
            else:
                if not isfile(p):
                    _logger.error(
                        'Failed to load Run from local directory: %s, '
                        'file %s is missing', *red(dir, p))
                    raise FileNotFoundError(
                        "Missing file of Run: '{}'".format(p))

        def load_data_file(file_path: str) -> Dict[str, Any]:
            msg = ('Invalid file of Run: {}, please read the exception '
                   'message and check the file').format(red(file_path))
            return read_yaml_file(file_path, error_msg=msg)

        metadata = load_data_file(local_paths['metadata'])
        metadata['alternativeName'] = basename(dir)

        # check that local Artifacts
        for r in ['input', 'output']:
            for a in metadata['associations'][r]:
                if a['kind'] == 'Artifact':
                    dir = a['localDir']
                    if not isdir(dir):
                        _logger.error(
                            'Local directory of associated Artifact of Run '
                            'does not exist: %s', red(dir))
                        raise FileNotFoundError(
                            ('Local directory of associated Artifact of Run '
                             "does not exist: '{}'").format(dir))
                    Artifact._load_local_dir(a['localDir'])

        hparams = load_data_file(local_paths['hparams'])

        metrics = {}
        for fname in os.listdir(local_paths['metrics']):
            assert fname.endswith('.yaml')
            fpath = join(local_paths['metrics'], fname)
            metric_type = fname[:-5]
            metrics[metric_type] = load_data_file(fpath)

        platform = load_data_file(local_paths['platform'])
        git = load_data_file(local_paths['git'])

        return Run(metadata=metadata,
                   hparams=hparams,
                   metrics=metrics,
                   platform=platform,
                   git=git)

    def upload(self,
               folder: str = 'default',
               make_folder: bool = False,
               conflict_strategy: str = 'new') -> None:
        """Uploads this Run to server.

        If this Run has input or output Artifacts, these Artifacts are uploaded
        as well if they have not been uploaded, and these associations are
        uploaded.

        Args:
            folder:
                Path of the Folder to which the Run is uploaded. If the
                provided path does not start with '/', `/<current-user>/` is
                prepended to it.
            make_folder:
                If True and Folder with path `folder` does not exist, make the
                Folder and parent Folders as needed.
            conflict_strategy:
                Strategy adopted when a Run with the same name as the Run to be
                uploaded already exists in the Folder, must be 'skip', 'error',
                'new' or 'replace'. If 'skip', skip the upload; if 'error',
                error out; if 'new', upload with the alternative name of Run;
                if 'replace', delete the existing Run and upload.
        """
        if not CLIENT.online:
            _logger.error(
                'To upload a Run or Artifact, please first call `em.login()`')
            raise RuntimeError('Not logged in')

        if not folder.startswith('/'):
            folder = '/{}/{}'.format(CLIENT.user_name, folder)
        folder = folder.rstrip('/')
        _logger.info('Uploading Run %s to Folder %s', *cyan(self.name, folder))
        run_path = join(folder, self.name)

        extra = json.dumps({'alternativeName': self.alternative_name})

        def create_run(name: str = self.name) -> str:
            nonlocal run_path
            try:
                return CLIENT.create_run(name=name,
                                         parent=folder,
                                         labels=self.labels,
                                         description=self.description,
                                         extra=extra)

            except RuntimeError as e:
                msg = e.args[0]
                if 'already exists' in msg:
                    run_data = CLIENT._get_node_data(node_kind='Run',
                                                     node=run_path)
                    run_data.update(json.loads(run_data.pop('extra')))
                    # the Run with the same name is this Run
                    if self.alternative_name == run_data['alternativeName']:
                        return run_data['id']

                    # the Run with the same name is not this Run
                    elif conflict_strategy == 'skip':
                        _logger.info(
                            'Run %s already exists in Folder %s, skip this upload',
                            *cyan(self.name, folder))
                        return
                    elif conflict_strategy == 'error':
                        _logger.error(
                            'Run %s already exists in Folder %s, abort',
                            *red(self.name, folder))
                        raise RuntimeError(
                            "Run already exists in Folder {}: '{}'".format(
                                folder, self.name)) from e
                    elif conflict_strategy == 'new':
                        _logger.info(
                            'Run %s already exists in Folder %s, '
                            'upload with alternative name %s',
                            *cyan(self.name, folder, self._alternative_name))
                        run_path = join(folder, self._alternative_name)
                        return create_run(name=self._alternative_name)
                    elif conflict_strategy == 'replace':
                        _logger.info(
                            'Run %s already exists in Folder %s, '
                            'upload to replace it', *cyan(self.name, folder))
                        CLIENT.delete_run(run_path=run_path)
                        return create_run()
                    else:
                        _logger.error('Not supported conflict strategy: %s',
                                      red(conflict_strategy))
                        raise ValueError(
                            "Not supported conflict strategy: '{}'".format(
                                conflict_strategy)) from e
                elif 'Folder does not exist' in msg:
                    if make_folder or (folder.endswith('/default')
                                       and folder.count('/') == 2):
                        CLIENT.make_folder(folder_path=folder)
                        return create_run()
                    else:
                        _logger.error('Folder %s does not exist', red(folder))
                        raise ValueError("Folder does not exist: '{}'".format(
                            folder)) from e
                else:
                    raise e

        id = create_run()
        if not id:
            return

        _logger.debug('Run %s is assigned ID %s by AIStore server',
                      self._alternative_name, id)
        self._update_remote({
            'action': 'upload',
            'timestamp': get_local_now_iso(),
            'host': CLIENT.ais_host,
            'path': run_path,
            'id': id,
        })

        for root, _, files in os.walk(self.local):
            for file in files:
                file_path = join(root, file)
                file_key = relpath(file_path, self.local).replace('\\', '/')
                CLIENT._upload_object(node_path=run_path,
                                      key=file_key,
                                      file_path=file_path,
                                      show_progress=False)

        addr = '{}/em/web/#/folders/{}/'.format(
            dirname(dirname(CLIENT.ais_host)), id)
        _logger.info('Run %s uploaded, view its data by visiting %s',
                     cyan(self.name), blue(addr, underline=True))

        associations = CLIENT.get_association(node_id=id)
        new_associations = []

        for r in ['input', 'output']:
            for a in self.associations[r]:
                if a['kind'] == 'Artifact':
                    artifact = Artifact._load_local_dir(a['localDir'])

                    aid = None
                    # If remote records of the Artifact includes the same
                    # server, and the corresponding ID still exists on the
                    # server, the Artifact will not be uploaded.
                    for rem in artifact.remote:
                        if rem['host'] == CLIENT.ais_host:
                            try:
                                CLIENT._get_node_data(node_kind='Artifact',
                                                      node=rem['id'])
                                aid = rem['id']
                                break
                            except RuntimeError:
                                pass
                    if not aid:
                        artifact.upload(folder=folder,
                                        make_folder=make_folder,
                                        conflict_strategy=conflict_strategy)
                        aid = artifact.remote[-1]['id']
                else:
                    aid = a['id']

                upload_association_flag = True
                for node in associations['in' if r == 'input' else 'out']:
                    if node['id'] == aid:
                        upload_association_flag = False
                if upload_association_flag:
                    new_associations.append({
                        'from': aid,
                        'to': id
                    } if r == 'input' else {
                        'from': id,
                        'to': aid
                    })

        if new_associations:
            CLIENT.upload_association(associations=new_associations)

    @staticmethod
    def _load_remote_path(path: str) -> 'Run':
        """Implements loading Run from remote path."""
        _logger.debug('Load Run from remote path %s', path)
        try:
            run_data = CLIENT._get_node_data(node_kind='Run', node=path)
        except RuntimeError as e:
            msg = e.args[0]
            if 'Node does not exist' in msg:
                raise RuntimeError(
                    "Remote path does not exist: '{}'".format(path)) from e
            else:
                raise e
        if run_data['type'] != 'Run':
            _logger.error(
                'Failed to load Run from remote path: %s, path refers to '
                'type %s rather than Run', *red(path, run_data['type']))
            raise RuntimeError(
                "Remote path refers to type '{}' rather than 'Run'".format(
                    run_data['type']))

        run_data.update(json.loads(run_data.pop('extra')))
        save_dir = join(EM_RUN_PARENT_DIR, run_data['alternativeName'])
        CLIENT.download(node_path=path,
                        save_dir=save_dir,
                        node_type='Run',
                        show_progress=False)
        os.makedirs(Run._get_local_paths(save_dir)['metrics'], exist_ok=True)

        run = Run._load_local_dir(save_dir)
        run._update_remote({
            'action': 'download',
            'timestamp': get_local_now_iso(),
            'host': CLIENT.ais_host,
            'path': path,
            'id': run_data['id'],
        })

        return run

    def _update_status(self, status: str) -> None:
        """Updates status of Run."""
        if self.status == status:
            return
        _logger.debug("Update status of Run %s from %s to '%s'",
                      self._alternative_name, self.status, status)
        if status in ['Running']:
            self._status = status
            self._end_timestamp = None
            write_yaml_file(self._locals['metadata'], self.to_dict())
        elif status in ['Complete', 'Error']:
            self._status = status
            self._end_timestamp = get_local_now_iso()
            write_yaml_file(self._locals['metadata'], self.to_dict())
        else:
            raise ValueError('Incorrect status type')

    def _update_hparams(self) -> None:
        """Updates hyperparameters of Run."""
        write_yaml_file(self._locals['hparams'], self.hparams.as_dict())

    def log(self,
            type: str,
            metrics: Dict[str, float],
            step: int,
            epoch: Optional[int] = None) -> None:
        """Logs a set of metrics of Run.

        Args:
            type:
                Type of the metrics, 'train' (or 'training'), 'val' (or
                'validate', 'validation') and 'test' (or 'testing', 'eval',
                'evaluate', 'evaluation') for training, validation and testing
                metrics respectively. Besides, you can also use other arbitrary
                string as custom type of the metrics.
            metrics:
                Additional metrics to be logged.
            step:
                Number of the step that the metrics belong to.
            epoch:
                Number of the epoch that the metrics belong to.
        """
        _logger.debug(
            'Log metric of Run %s: %s of type %s at step %s and epoch %s',
            self._alternative_name, metrics, type, step, epoch)

        metrics = {k: float(v) for k, v in metrics.items()}
        metrics_element = [{
            'value': metrics,
            'sequence': {
                'epoch': epoch,
                'step': step,
                'timestamp': get_local_now_iso(),
            }
        }]
        if type not in self._metrics:
            self._metrics[type] = metrics_element
            # update index.yaml
            write_yaml_file(self._locals['index'], self._get_index())
        else:
            self._metrics[type] += metrics_element

        path = join(self._locals['metrics'], type + '.yaml')
        write_yaml_file(path, metrics_element, append=True)

    def mark_input(
        self, resource: Union[Artifact, Model, Dataset, Branch, Tag,
                              Commit]) -> None:
        """Marks an Artifact, Model or Dataset as an input of this Run."""
        self._mark(resource, 'input')

    def mark_output(
        self, resource: Union[Artifact, Model, Dataset, Branch, Tag,
                              Commit]) -> None:
        """Marks an Artifact, Model or Dataset as an output of this Run."""
        self._mark(resource, 'output')

    def _mark(self, resource: Union[Artifact, Model, Dataset, Branch, Tag,
                                    Commit], role: str) -> None:
        """Implements marking."""
        if isinstance(resource, Artifact):
            artifact = resource
            _logger.debug('Mark Artifact %s as an %s of Run %s',
                          artifact.alternative_name, role,
                          self.alternative_name)

            names = [
                artifact['name'] for artifact in self.associations[role]
                if artifact['kind'] == 'Artifact'
            ]
            if artifact.alternative_name in names:
                _logger.debug('Artifact %s is already an %s of Run %s',
                              artifact.alternative_name, role,
                              self.alternative_name)
            else:
                self._associations[role].append({
                    'kind': 'Artifact',
                    'name': artifact.alternative_name,
                    'localDir': artifact.local,
                })
                write_yaml_file(self._locals['metadata'], self.to_dict())

            _logger.info('Run %s %s Artifact %s', cyan(self.name),
                         'used' if role == 'input' else 'produced',
                         cyan(artifact.name))
        elif isinstance(resource, Model) or isinstance(resource, Dataset):
            asset = resource
            _logger.debug('Mark %s %s as an %s of Run %s', asset.kind,
                          asset.id, role, self.alternative_name)

            paths = [
                asset['path'] for asset in self.associations[role]
                if asset['kind'] in ['Model', 'Dataset']
            ]
            if asset.path in paths:
                _logger.debug('%s %s is already an %s of Run %s', asset.kind,
                              asset.path, role, self.alternative_name)
            else:
                self._associations[role].append({
                    'kind': asset.kind,
                    'id': asset.id,
                    'path': asset.path,
                })
                write_yaml_file(self._locals['metadata'], self.to_dict())

            _logger.info('Run %s %s %s %s', cyan(self.name),
                         'used' if role == 'input' else 'produced', asset.kind,
                         cyan(asset.name))
        elif isinstance(resource, Branch) or isinstance(
                resource, Tag) or isinstance(resource, Commit):
            ref = resource
            _logger.debug('Mark reference %s as an %s of Run %s', ref.name,
                          role, self.alternative_name)

            paths = [
                ref['path'] for ref in self.associations[role]
                if ref['kind'] in ['branch', 'tag', 'commit']
            ]
            if ref.path in paths:
                _logger.debug('Reference %s is already an %s of Run %s',
                              ref.path, role, self.alternative_name)
            else:
                self._associations[role].append({
                    'kind':
                    ref.kind,
                    'id':
                    '{}:{}'.format(ref.asset.id, ref.name),
                    'path':
                    ref.path,
                })
                write_yaml_file(self._locals['metadata'], self.to_dict())

            _logger.info('Run %s %s %s %s', cyan(self.name),
                         'used' if role == 'input' else 'produced', ref.kind,
                         cyan(ref.path))
        else:
            _logger.error(
                '%s instance cannot be marked, only instances of Artifact, '
                'Model, Dataset, Branch, Tag and Commit can be marked',
                red(type(resource)))
            raise TypeError("Instance type cannot be marked: '{}'".format(
                type(resource)))

    def _update_platform(self) -> None:
        """Updates platform info of Run."""
        _logger.debug('Update platform info of Run %s', self._alternative_name)
        self._platform = get_platform_data()
        write_yaml_file(self._locals['platform'], self.platform)

    def _update_git(self) -> None:
        """Updates git info of Run."""
        _logger.debug('Update git info of Run %s', self._alternative_name)
        self._git = get_git_repo_data()
        write_yaml_file(self._locals['git'], self.git)

    def _update_remote(self, record: Dict[str, str]) -> None:
        """Updates upload and download history of Run."""
        _logger.debug('Update upload and download history of Run %s',
                      self._alternative_name)
        self._remote.append(record)
        write_yaml_file(self._locals['metadata'], self.to_dict())

    @called_once_only_each_instance()
    def finish(self) -> None:
        """Finishes the Run and saves data of Run."""
        _logger.debug('Finish Run %s', self._alternative_name)
        self._update_status('Complete')

        _remove_stdout_logfile(self._locals['log'])

    @staticmethod
    def _get_local_paths(dir: str) -> Dict[str, str]:
        names = [
            'metadata', 'index', 'hparams', 'metrics', 'platform', 'git', 'log'
        ]
        subpaths = [
            'metadata.yaml', 'index.yaml', 'hyperparameters.yaml', 'metrics',
            'platform.yaml', 'git.yaml', 'stdout.log'
        ]
        return {
            name: join(dir, subpath)
            for name, subpath in zip(names, subpaths)
        }

    def _get_index(self) -> Dict[str, Any]:
        return {
            'hyperparameters': 'hyperparameters.yaml',
            'metrics': {
                t: 'metrics/{}.yaml'.format(t)
                for t in list(self.metrics.keys())
            },
            'platform': 'platform.yaml',
            'git': 'git.yaml',
            'log': 'stdout.log'
        }
