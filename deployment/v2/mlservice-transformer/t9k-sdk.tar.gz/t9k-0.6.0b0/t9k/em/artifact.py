"""Artifact class."""

import json
import logging
import os
import shutil
from typing import Any, Dict, List, Optional

from t9k.em.client import CLIENT
from t9k.utils.datetime_utils import get_local_now_iso
from t9k.utils.file_utils import (abspath, basename, dirname, isdir, isfile,
                                  join, relpath, get_file_size, get_file_md5,
                                  read_yaml_file, write_yaml_file,
                                  update_yaml_file)
from t9k.utils.print_utils import black, blue, cyan, red

_logger = logging.getLogger(__name__)

EM_ARTIFACT_PARENT_DIR = os.getenv('EM_ARTIFACT_PARENT_DIR', '.em/artifacts')


class Artifact(object):
    """Implementation of Artifact, a set of files that a Run inputs or
    outputs.

    Args:
        metadata:
            Metadata to initialize a new Artifact.
        objects:
            Data of objects of the Artifact.

    Attributes:
        name:
            Name of the Artifact.
        labels:
            Labels of the Artifact.
        description:
            Description of the Artifact.
        created_timestamp:
            Created timestamp of the Artifact.
        alternative_name:
            Alternative name of the Artifact.
        objects:
            Data of objects of the Artifact.
        remote:
            Upload and download history of the Artifact.
        local:
            Local directory of the Artifact.
    """

    def __init__(self,
                 metadata: Dict[str, Any],
                 objects: Optional[Dict[str, Dict[str, Any]]] = None):
        self.parse_from_dict(metadata)
        self._objects = objects or {}
        self._prepare_local_dir()

    @property
    def name(self) -> str:
        return self._name

    @property
    def labels(self) -> List[str]:
        return self._labels

    @property
    def description(self) -> str:
        return self._description

    @property
    def created_timestamp(self) -> str:
        return self._created_timestamp

    @property
    def alternative_name(self) -> str:
        return self._alternative_name

    @property
    def objects(self) -> List[Dict[str, str]]:
        return self._objects

    @property
    def remote(self) -> List[Dict[str, str]]:
        return self._remote

    @property
    def local(self) -> str:
        return self._local

    def parse_from_dict(self, data: Dict[str, Any]) -> None:
        """Parses an Artifact instance from a dict."""
        self._name = data['name']
        self._labels = data['labels']
        self._description = data['description']
        self._created_timestamp = data['createdTimestamp']
        self._alternative_name = data['alternativeName']
        self._remote = data['remote']

    def to_dict(self) -> Dict[str, Any]:
        """Converts Artifact instance to a dict and returns it."""
        return {
            'kind': 'Artifact',
            'name': self.name,
            'labels': self.labels,
            'description': self.description,
            'createdTimestamp': self.created_timestamp,
            'alternativeName': self.alternative_name,
            'remote': self.remote,
        }

    def _prepare_local_dir(self) -> None:
        """Prepares local directory and files for Artifact.

        Under `EM_ARTIFACT_PARENT_DIR` create a directory of Artifact, then under
        the directory create a YAML file to store Artifact data and put files
        of objects of this Artifact.

        If the directory already exists, do nothing. This occurs when loading
        a local Artifact.
        """
        self._local = join(EM_ARTIFACT_PARENT_DIR, self._alternative_name)
        self._local_metadata = join(self._local, 'metadata.yaml')
        self._local_references = join(self._local, 'references.yaml')
        if isdir(self._local):
            return

        _logger.debug('Create local directory for Artifact %s', self.name)

        os.makedirs(self._local)
        # metadata.yaml
        write_yaml_file(self._local_metadata, self.to_dict())

        _logger.debug('Local directory created: %s', abspath(self._local))
        _logger.info('Artifact %s saved to local directory %s',
                     cyan(self.name), black(self._local, underline=True))

    @staticmethod
    def _load_local_dir(dir: str) -> 'Artifact':
        """Implements loading an Artifact by ID from local."""
        _logger.debug('Load Artifact from local directory %s', dir)

        local_metadata = join(dir, 'metadata.yaml')

        if not isfile(local_metadata):
            _logger.error(
                'Failed to load Artifact from local directory: %s, '
                'file %s is missing', *red(dir, local_metadata))
            raise FileNotFoundError(
                "Missing file of Artifact: '{}'".format(local_metadata))

        def load_data_file(file_path: str) -> Dict[str, Any]:
            msg = ('Invalid file of Artifact: {}, please read the '
                   'exception message and check the file').format(
                       red(file_path))
            return read_yaml_file(file_path, error_msg=msg)

        metadata = load_data_file(local_metadata)
        metadata['alternativeName'] = basename(dir)

        objects = {}
        for root, _, files in os.walk(dir):
            for file in files:
                file_path = join(root, file)
                file_key = relpath(file_path, dir).replace('\\', '/')
                if file_key == 'metadata.yaml':
                    continue
                elif file_key == 'references.yaml':
                    references = read_yaml_file(file_path=file_path)
                    for k, v in references.items():
                        objects[k] = {'path': k, 'uri': v}
                else:
                    objects[file_key] = {
                        'path': file_key,
                        'size_bytes': get_file_size(file_path),
                        'checksum': get_file_md5(file_path)
                    }

        return Artifact(metadata=metadata, objects=objects)

    def upload(self,
               folder: str = 'default',
               make_folder: bool = False,
               conflict_strategy: str = 'new') -> None:
        """Uploads this Artifact to server.

        Args:
            folder:
                Path of the Folder to which the Artifact is uploaded. If the
                provided path does not start with '/', `/<current-user>/` is
                prepended to it.
            make_folder:
                If True and Folder with path `folder` does not exist, make the
                Folder and parent Folders as needed.
            conflict_strategy:
                Strategy adopted when an Artifact with the same name as the
                Artifact to be uploaded already exists in the Folder, must be
                'skip', 'error', 'new' or 'replace'. If 'skip', skip the
                upload; if 'error', error out; if 'new', upload with the
                alternative name of Artifact; if 'replace', delete the existing
                Artifact and upload.
        """
        if not CLIENT.online:
            _logger.error(
                'To upload a Run or Artifact, please first call `em.login()`')
            raise RuntimeError('Not logged in')

        if not folder.startswith('/'):
            folder = '/{}/{}'.format(CLIENT.user_name, folder)
        folder = folder.rstrip('/')
        _logger.info('Uploading Artifact %s to Folder %s',
                     *cyan(self.name, folder))
        artifact_path = join(folder, self.name)

        extra = json.dumps({'alternativeName': self.alternative_name})

        def create_artifact(name: str = self.name) -> str:
            nonlocal artifact_path
            try:
                return CLIENT.create_artifact(name=name,
                                              parent=folder,
                                              labels=self.labels,
                                              description=self.description,
                                              extra=extra)

            except RuntimeError as e:
                msg = e.args[0]
                if 'already exists' in msg:
                    artifact_data = CLIENT._get_node_data(node_kind='Artifact',
                                                          node=artifact_path)
                    artifact_data.update(json.loads(
                        artifact_data.pop('extra')))
                    # the Run with the same name is this Artifact
                    if self.alternative_name == artifact_data[
                            'alternativeName']:
                        return artifact_data['id']

                    # the Run with the same name is not this Artifact
                    if conflict_strategy == 'skip':
                        _logger.info(
                            'Artifact %s already exists in Folder %s, '
                            'skip this upload', *cyan(self.name, folder))
                        return
                    elif conflict_strategy == 'error':
                        _logger.error(
                            'Artifact %s already exists in Folder %s, abort',
                            *red(self.name, folder))
                        raise RuntimeError(
                            "Artifact already exists in Folder {}: '{}'".
                            format(folder, self.name)) from e
                    elif conflict_strategy == 'new':
                        _logger.info(
                            'Artifact %s already exists in Folder %s, '
                            'upload with alternative name %s',
                            *cyan(self.name, folder, self._alternative_name))
                        artifact_path = join(folder, self._alternative_name)
                        return create_artifact(name=self._alternative_name)
                    elif conflict_strategy == 'replace':
                        _logger.info(
                            'Artifact %s already exists in Folder %s, '
                            'upload to replace it', *cyan(self.name, folder))
                        CLIENT.delete_artifact(artifact_path=artifact_path)
                        return create_artifact()
                    else:
                        _logger.error('Not supported conflict strategy: %s',
                                      red(conflict_strategy))
                        raise ValueError(
                            "Not supported conflict strategy: '{}'".format(
                                conflict_strategy)) from e
                elif 'Folder does not exist' in msg:
                    if make_folder or (folder.endswith('/default')
                                       and folder.count('/') == 2):
                        CLIENT.make_folder(folder_path=folder)
                        return create_artifact()
                    else:
                        _logger.error('Folder %s does not exist', red(folder))
                        raise ValueError("Folder does not exist: '{}'".format(
                            folder)) from e
                else:
                    raise e

        id = create_artifact()
        if not id:
            return

        _logger.debug('Artifact %s is assigned ID %s by AIStore server',
                      self._alternative_name, id)
        self._update_remote({
            'action': 'upload',
            'timestamp': get_local_now_iso(),
            'host': CLIENT.ais_host,
            'id': id,
            'path': artifact_path,
        })

        total = sum([len(files) for _, _, files in os.walk(self.local)])
        i = 1
        for root, _, files in os.walk(self.local):
            for file in files:
                file_path = join(root, file)
                file_key = relpath(file_path, self.local).replace('\\', '/')
                _logger.info('Uploading object %s/%s %s:', i, total,
                             cyan(file_key))
                CLIENT._upload_object(node_path=artifact_path,
                                      key=file_key,
                                      file_path=file_path,
                                      show_progress=True)
                i += 1

        addr = '{}/em/web/#/folders/{}/'.format(
            dirname(dirname(CLIENT.ais_host)), id)
        _logger.info('Artifact %s uploaded, view its data by visiting %s',
                     cyan(self.name), blue(addr, underline=True))

    @staticmethod
    def _load_remote_path(path: str) -> 'Artifact':
        """Implements loading Artifact from remote path."""
        _logger.debug('Load Artifact from remote path %s', path)
        try:
            artifact_data = CLIENT._get_node_data(node_kind='Artifact',
                                                  node=path)
        except RuntimeError as e:
            msg = e.args[0]
            if 'Node does not exist' in msg:
                raise RuntimeError(
                    "Remote path does not exist: '{}'".format(path)) from e
            else:
                raise e
        if artifact_data['type'] != 'Artifact':
            _logger.error(
                'Failed to load Artifact from remote path: %s, path refers to '
                'type %s rather than Artifact',
                *red(path, artifact_data['type']))
            raise RuntimeError(
                "Remote path refers to type '{}' rather than 'Artifact'".
                format(artifact_data['type']))

        artifact_data.update(json.loads(artifact_data.pop('extra')))
        save_dir = join(EM_ARTIFACT_PARENT_DIR,
                        artifact_data['alternativeName'])
        CLIENT.download(node_path=path,
                        save_dir=save_dir,
                        node_type='Artifact',
                        show_progress=True)

        artifact = Artifact._load_local_dir(save_dir)
        artifact._update_remote({
            'action': 'download',
            'timestamp': get_local_now_iso(),
            'host': CLIENT.ais_host,
            'path': path,
            'id': artifact_data['id'],
        })

        return artifact

    def add_file(self, file_path: str, obj_path: Optional[str] = None) -> None:
        """Adds a local file as an object of the Artifact.

        The file will be copied to local directory of the Artifact, the
        specific subpath depends on its object path, for example:

        ```
        # file copied to `<local-dir>/1.png`
        artifact.add_file(file_path='1.png')
        # or
        artifact.add_file(file_path='1.png', obj_path='1.png')

        # file copied to `<local-dir>/a/1.png`
        artifact.add_file(file_path='1.png', obj_path='a/')
        # or
        artifact.add_file(file_path='1.png', obj_path='a/1.png')
        ```
        """
        file_path = abspath(file_path)
        if not isfile(file_path):
            _logger.error('File %s does not exist', red(file_path))
            raise RuntimeError("File does not exist: '{}'".format(file_path))

        obj_path = self._determine_object_path(file_path, obj_path)
        if obj_path in self._objects and 'uri' in self._objects[obj_path]:
            _logger.error(
                'Failed to add file %s, object reference %s '
                'already exists', *red(file_path, obj_path))
            raise ValueError(
                "Object reference already exists: '{}'".format(obj_path))

        dst_path = join(self.local, obj_path)
        os.makedirs(dirname(dst_path), exist_ok=True)

        shutil.copy(src=file_path, dst=dst_path)
        self._objects[obj_path] = {
            'path': obj_path,
            'size_bytes': get_file_size(file_path),
            'checksum': get_file_md5(file_path)
        }

        _logger.debug('Add file %s as object %s of Artifact %s', file_path,
                      obj_path, self.alternative_name)

    def add_dir(self, dir_path: str, obj_path: Optional[str] = None) -> None:
        """Adds all files under a local directory as objects of the Artifact.

        The directory will be copied to local directory of the Artifact, the
        specific subpath depends on its obj_path, for example:

        ```
        # dir copied to `<local-dir>/a`
        artifact.add_dir(dir_path='a/')
        # or
        artifact.add_dir(dir_path='a')
        # or
        artifact.add_dir(dir_path='a/', obj_path='a')

        # dir copied to `<local-dir>/b/a`
        artifact.add_dir(dir_path='a/', obj_path='b/')
        # or
        artifact.add_dir(dir_path='a/', obj_path='b/a')
        ```
        """
        dir_path = abspath(dir_path)
        if not isdir(dir_path):
            _logger.error('Directory %s does not exist', red(dir_path))
            raise RuntimeError(
                "Directory does not exist: '{}'".format(dir_path))

        obj_path = self._determine_object_path(dir_path, obj_path)

        dst_path = join(self.local, obj_path)
        os.makedirs(dirname(dst_path), exist_ok=True)

        shutil.copytree(src=dir_path, dst=dst_path, dirs_exist_ok=True)
        for root, _, files in os.walk(dst_path):
            for file in files:
                file_path = join(root, file)
                file_obj_path = relpath(file_path, self.local)
                if file_obj_path in self._objects and 'uri' in self._objects[
                        file_obj_path]:
                    _logger.error(
                        'Failed to add file %s, object reference %s '
                        'already exists', *red(file_path, file_obj_path))
                    raise ValueError(
                        "Object reference already exists: '{}'".format(
                            file_obj_path))
                self._objects[file_obj_path] = {
                    'path': file_obj_path,
                    'size_bytes': get_file_size(file_path),
                    'checksum': get_file_md5(file_path)
                }

        _logger.debug('Add directory %s to %s of Artifact %s', dir_path,
                      obj_path, self.alternative_name)

    def add_reference(self, uri: str, obj_path: Optional[str] = None) -> None:
        """Adds a URI as an object reference to the Artifact."""
        obj_path = self._determine_object_path(uri, obj_path)
        if obj_path in self._objects and 'checksum' in self._objects[obj_path]:
            _logger.error(
                'Failed to add reference %s, object file %s '
                'already exists', *red(uri, obj_path))
            raise ValueError(
                "Object file already exists: '{}'".format(obj_path))

        update = {obj_path: uri}
        update_yaml_file(self._local_references, update=update)
        self._objects[obj_path] = {'path': obj_path, 'uri': uri}

        _logger.debug('Add reference %s to %s of Artifact %s', uri, obj_path,
                      self.alternative_name)

    def _update_remote(self, record: Dict[str, str]) -> None:
        """Updates upload and download history of Artifact."""
        _logger.debug('Update upload and download history of Artifact %s',
                      self._alternative_name)
        self._remote.append(record)
        write_yaml_file(self._local_metadata, self.to_dict())

    @staticmethod
    def _determine_object_path(path: str, obj_path: Optional[str]) -> str:
        if not obj_path:
            return basename(path)

        if obj_path.startswith('/'):
            obj_path = obj_path[1:]
        if obj_path.endswith('/'):
            obj_path = obj_path + basename(path)
        return obj_path
