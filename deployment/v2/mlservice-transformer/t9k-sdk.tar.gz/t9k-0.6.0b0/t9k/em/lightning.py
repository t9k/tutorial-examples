"""Callback for PyTorch Lightning."""

from lightning.pytorch.callbacks import Callback

from t9k.em.run import Run


class EMCallback(Callback):
    """Logs metrics and retrieves hyperparameters.

    Examples:

        ```
        trainer = Trainer(max_epochs=10,
                          callbacks=EMCallback(run))
        ```

    Args:
        run: Run that the training and testing process belongs to.
    """
    def __init__(self, run: Run):
        super(EMCallback, self).__init__()
        self.run = run

    def on_train_start(self, trainer, pl_module):
        # Retrieves params from `LightningModule.hparams`
        self.run.params.update(dict(pl_module.hparams))
        self.run._update_status('Running')

    def on_validation_epoch_end(self, trainer, pl_module, outputs=None):
        metrics = {k: v.item() for k, v in trainer.callback_metrics.items()}
        # Keys of training metrics have the prefix 'train_' and keys of
        # validation metrics have the prefix of 'val_'.
        if 'train_loss' in metrics:
            train_metrics = {
                k[6:]: v
                for k, v in metrics.items() if k.startswith('train_')
            }
            val_metrics = {
                k[4:]: v
                for k, v in metrics.items() if k.startswith('val_')
            }
            self.run.log('train',
                         train_metrics,
                         step=trainer.global_step + 1,
                         epoch=trainer.current_epoch + 1,
                         check_status=False)
            self.run.log('val',
                         val_metrics,
                         step=trainer.global_step + 1,
                         epoch=trainer.current_epoch + 1,
                         check_status=False)

    def on_test_epoch_end(self, trainer, pl_module, outputs=None):
        metrics = {k: v.item() for k, v in trainer.callback_metrics.items()}
        # Keys of testing metrics have the prefix 'test_'.
        test_metrics = {
            k[5:]: v
            for k, v in metrics.items() if k.startswith('test_')
        }
        self.run.log('test',
                     test_metrics,
                     step=trainer.global_step,
                     check_status=False)
