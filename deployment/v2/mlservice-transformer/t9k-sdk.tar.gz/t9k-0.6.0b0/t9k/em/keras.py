"""Callbacks for Keras."""

import logging

import numpy as np
from tensorflow import keras

from t9k.em.run import Run

_logger = logging.getLogger(__name__)


class EMFitCallback(keras.callbacks.Callback):
    """Logs training metrics and retrieves hyperparameters.

    Examples:

        ```
        from t9k.em.keras import EMFitCallback

        model.fit(train_images,
                  train_labels,
                  epochs=10,
                  validation_split=0.2,
                  callbacks=EMFitCallback(run))
        ```

    Args:
        run: Run that the training process belongs to.
    """
    def __init__(self, run: Run):
        super().__init__()
        self.run = run
        # If uses epoch.
        self.epoch_flag = False

    def on_train_begin(self, logs=None):  # pylint: disable=unused-argument
        # Retrieves hparams from `keras.Model.optimizer` and
        # `keras.Model.loss`.
        optimizer_config = self.model.optimizer.get_config()
        for k, v in optimizer_config.copy().items():
            if isinstance(v, np.float32):
                optimizer_config[k] = float(v)

        new_hparams = {
            'optimizer': optimizer_config,
        }

        if isinstance(self.model.loss, str):
            new_hparams['lossType'] = self.model.loss
        elif isinstance(self.model.loss, keras.losses.Loss):
            new_hparams['lossType'] = self.model.loss.get_config()['name']
            # TODO: Adds `self.model.loss.get_config()['reduction']`
        else:
            raise TypeError('Undefined type for loss of Keras model')

        self.run.hparams.update(new_hparams)
        _logger.debug('Training starts')

    def on_epoch_begin(self, epoch, logs=None):  # pylint: disable=unused-argument
        self.epoch_flag = True

    def on_train_batch_end(self, batch, logs=None):  # pylint: disable=unused-argument
        if not self.epoch_flag:
            self.run.log('train',
                         logs,
                         step=int(self.model.optimizer.iterations.numpy()))

    def on_epoch_end(self, epoch, logs=None):
        # Keys of validation metrics have the prefix 'val_' while keys of
        # training metrics have no prefix.
        train_logs = {
            k: v
            for k, v in logs.items() if not k.startswith('val_')
        }
        self.run.log('train',
                     train_logs,
                     step=int(self.model.optimizer.iterations.numpy()),
                     epoch=int(epoch) + 1)

        if 'val_loss' in logs:
            val_logs = {
                k[4:]: v
                for k, v in logs.items() if k.startswith('val_')
            }
            self.run.log('val',
                         val_logs,
                         step=int(self.model.optimizer.iterations.numpy()),
                         epoch=int(epoch) + 1)

    def on_train_end(self, logs=None):  # pylint: disable=unused-argument
        metrics_names = self.model.metrics_names
        metrics_names.remove('loss')
        new_hparams = {
            'metricTypes': metrics_names,
        }
        self.run.hparams.update(new_hparams)


class EMEvalCallback(keras.callbacks.Callback):
    """Logs testing metrics.

    Examples:

        ```
        from t9k.em.keras import EMEvalCallback

        model.evaluate(test_images,
                       test_labels,
                       callbacks=EMEvalCallback(run))
        ```

    Args:
        run: Run that the testing process belongs to.
    """
    def __init__(self, run: Run):
        super().__init__()
        self.run = run

    def on_test_end(self, logs=None):
        self.run.log('test',
                     logs,
                     step=int(self.model.optimizer.iterations.numpy()))
