"""Implementation of CLI."""

from datetime import datetime
from glob import glob
import os
import sys
from typing import Any, Dict, List, Optional

import click
import tabulate
import yaml

import t9k
from t9k.em.apis import upload
from t9k.em.client import _login_for_cli_cmd
from t9k.utils.datetime_utils import get_local_now_iso, format_timedelta
from t9k.utils.file_utils import (abspath, basename, get_file_md5,
                                  get_file_size, human_readable_size, isdir,
                                  isfile, join, read_yaml_file, relpath)
from t9k.utils.print_utils import red
from t9k.utils.random_utils import is_random_name

CONTEXT_SETTINGS = dict(help_option_names=['--help'])

tabulate.PRESERVE_WHITESPACE = True


@click.group(context_settings=CONTEXT_SETTINGS)
@click.version_option(t9k.__version__)
@click.pass_context
def cli(ctx):
    del ctx  # Unused
    pass


@click.argument('path', type=click.Path(exists=True))
@click.option('-d',
              '--detail',
              is_flag=True,
              default=False,
              help='Show detailed information.')
@cli.command('ls', context_settings=CONTEXT_SETTINGS)
def ls(path: str, detail: bool):
    """List local Runs or Artifacts.

    \b
    Examples:
        \b
        # List Runs under the parent directory `.em/runs`:
        em ls .em/runs
        \b
        # List Artifacts under `EM_ARTIFACT_PARENT_DIR`:
        em ls $EM_ARTIFACT_PARENT_DIR
    """
    path = path.rstrip('/')

    pattern = '{}/*_{}_{}_*'.format(path, '[0-9]' * 6, '[0-9]' * 6)
    paths = glob(pattern)

    run_table = []
    artifact_table = []
    for p in paths:
        metadata_file_path = join(p, 'metadata.yaml')
        if not isfile(metadata_file_path):
            eprint(
                'Metadata file does not exist: {}'.format(metadata_file_path))

        try:
            metadata = read_yaml_file(metadata_file_path)
        except yaml.scanner.ScannerError:
            eprint('Invalid YAML document: {}'.format(metadata_file_path))

        if metadata['kind'] == 'Run':
            name = metadata['name']
            status = metadata['status']
            started = format_timedelta(
                datetime.fromisoformat(get_local_now_iso()) -
                datetime.fromisoformat(metadata['startTimestamp']),
                brief=True) + ' ago'
            if status == 'Complete':
                duration = format_timedelta(
                    datetime.fromisoformat(metadata['endTimestamp']) -
                    datetime.fromisoformat(metadata['startTimestamp']))
            else:
                duration = ''

            if detail:
                alternative_name = metadata['alternativeName']
                labels = ', '.join(metadata['labels'])
                run_table.append([
                    name, alternative_name, status, labels, started, duration
                ])
            else:
                run_table.append([name, status, started, duration])

        elif metadata['kind'] == 'Artifact':
            name = metadata['name']
            alternative_name = metadata['alternativeName']
            labels = ', '.join(metadata['labels'])
            created = format_timedelta(
                datetime.fromisoformat(get_local_now_iso()) -
                datetime.fromisoformat(metadata['createdTimestamp']),
                brief=True) + ' ago'

            artifact_table.append([name, alternative_name, labels, created])

        else:
            eprint('Invalid kind: {}'.format(metadata['kind']))

    if run_table:
        if detail:
            headers = [
                'NAME', 'ALTERNATIVE_NAME', 'STATUS', 'LABELS', 'STARTED',
                'DURATION'
            ]
        else:
            headers = ['NAME', 'STATUS', 'STARTED', 'DURATION']
        click.echo(tabulate.tabulate(run_table, headers, tablefmt='plain'))

    if artifact_table:
        headers = ['NAME', 'ALTERNATIVE_NAME', 'LABELS', 'CREATED']
        click.echo(tabulate.tabulate(artifact_table, headers,
                                     tablefmt='plain'))


@click.argument('path', type=click.Path(exists=True))
@click.option('-d',
              '--detail',
              is_flag=True,
              default=False,
              help='Show detailed information.')
@cli.command('describe', context_settings=CONTEXT_SETTINGS)
def describe(path: str, detail: bool):
    """Describe local Runs or Artifacts.

    \b
    Examples:
      \b
      # Describe a Run:
      em describe .em/runs/cnn_keras_220823_194728_4e48t2
      \b
      # Describe all Runs under the parent directory:
      em describe .em/runs
      \b
      # Show hyperparameters, metrics, platform info and git info of a Run:
      em describe .em/runs/cnn_keras_220823_194728_4e48t2 --detail
      \b
      # Show objects of an Artifact:
      em describe .em/artifacts/tensorboard_logs_220823_194728_4e48t2 --detail
    """
    describe_list = []

    path = abspath(path)
    if is_random_name(basename(path)) and isdir(path):  # Run or Artifact
        describe_list.append(path)
    else:  # parent directory
        for entry in os.listdir(path):
            if is_random_name(entry) and isdir(join(path, entry)):
                describe_list.append(join(path, entry))

    def load_data_file(file_path: str) -> Dict[str, Any]:
        if not isfile(file_path):
            eprint('File does not exist: {}'.format(file_path))
        try:
            data = read_yaml_file(file_path)
        except yaml.scanner.ScannerError:
            eprint('Invalid YAML document: {}'.format(file_path))
        return data

    print_delimiter_flag = False
    for p in describe_list:
        if not print_delimiter_flag:
            print_delimiter_flag = True
        else:
            click.echo('---')

        metadata_file_path = join(p, 'metadata.yaml')
        metadata = load_data_file(metadata_file_path)

        if metadata['kind'] == 'Run':
            hparams_file_path = join(p, 'hyperparameters.yaml')
            metric_dir_path = join(p, 'metrics')
            platform_file_path = join(p, 'platform.yaml')
            git_file_path = join(p, 'git.yaml')

            table = [
                ['Name:', metadata['name']],
                ['Alternative Name:', metadata['alternativeName']],
                ['Labels:', metadata['labels']],
                ['Description:', metadata['description']],
                ['Status:', metadata['status']],
                ['Start Time:', metadata['startTimestamp']],
                ['End Time:', metadata['endTimestamp']],
            ]

            def populate_artifact(table: List[List[str]],
                                  metadata: Dict[str, Any], role: str):
                if not metadata['artifacts'][role]:
                    table.append(['  {}:'.format(role), '<none>'])
                else:
                    table.append(['  {}:'.format(role), ''])
                    for a in metadata['artifacts'][role]:
                        if a['kind'] == 'Artifact':
                            table.extend([['  - kind:', a['kind']],
                                          ['    name:', a['name']],
                                          ['    localDir:', a['localDir']]])
                        else:
                            table.extend([['  - kind:', a['kind']],
                                          ['    ID:', a['ID']],
                                          ['    remotePath:',
                                           a['remotePath']]])

            table.append(['Artifacts:', ''])
            populate_artifact(table, metadata, 'input')
            populate_artifact(table, metadata, 'output')

            remote_info = metadata['remote']
            if not remote_info:
                table.append(['Remote:', '<none>'])
            else:
                table.append(['Remote:', ''])
                for r in remote_info:
                    table.extend([['- action:', r['action']],
                                  ['  timestamp:', r['timestamp']],
                                  ['  host:', r['host']], ['  id:', r['id']],
                                  ['  path:', r['path']]])

            if detail:
                parameters = load_data_file(hparams_file_path)
                table.append(['Hyperparameters:', ''])
                for k, v in parameters.items():
                    if isinstance(v, dict):
                        table.append(['  {}:'.format(k), ''])
                        for k_, v_ in v.items():
                            table.append(['    {}:'.format(k_), v_])
                    else:
                        table.append(['  {}:'.format(k), v])

                table.append(['Metrics:', ''])
                for file in os.listdir(metric_dir_path):
                    assert file.endswith('.yaml')
                    metric_type = file[:-5]
                    metric_file_path = join(metric_dir_path, file)
                    metric_list = load_data_file(metric_file_path)

                    headers = []
                    metric_0 = metric_list[0]

                    contain_epoch_flag = metric_0['sequence'][
                        'epoch'] is not None
                    if contain_epoch_flag:
                        headers.append('epoch')
                    headers.extend(['step', 'timestamp'])

                    for metric_name in metric_0['value']:
                        headers.append('{}'.format(metric_name))

                    subtable = []
                    last_timestamp = ''
                    for metric in metric_list:
                        row = []

                        if contain_epoch_flag:
                            row.append(metric['sequence']['epoch'])

                        row.append(metric['sequence']['step'])

                        timestamp = metric['sequence']['timestamp']
                        if timestamp[:10] == last_timestamp[:10]:
                            row.append(timestamp[11:19])
                        else:
                            row.append(timestamp[:19])
                        last_timestamp = timestamp

                        row.extend(list(metric['value'].values()))

                        subtable.append(row)

                    table.append([
                        '  {}:'.format(metric_type),
                        tabulate.tabulate(subtable,
                                          headers,
                                          tablefmt='plain',
                                          stralign='right',
                                          floatfmt='.4f')
                    ])
                if table[-1][0] == 'Metrics:':
                    table[-1] = ['Metrics:', '<none>']

                platform_info = load_data_file(platform_file_path)
                table.extend([
                    ['Platform:', ''],
                    ['  Hostname:', platform_info['hostname']],
                    ['  OS:', platform_info['os']],
                    ['  Python version:', platform_info['python']],
                    ['  Framework:', platform_info['framework']],
                    ['  Python packages:', ''],
                ])
                for k, v in platform_info['pypkgs'].items():
                    table.append(['    {}:'.format(k), v])

                git_info = load_data_file(git_file_path)
                table.extend([
                    ['Git:', ''],
                    ['  Repo path:', git_info['repo_path']],
                    ['  Remote URL:', git_info['remote_url']],
                    ['  Branch:', git_info['branch']],
                    ['  Commit:', git_info['commit']],
                    ['  IsDirty:', git_info['is_dirty']],
                    ['  Entrypoint:', git_info['entrypoint']],
                ])

            click.echo(tabulate.tabulate(table, tablefmt='plain'))

        elif metadata['kind'] == 'Artifact':
            table = [
                ['Name:', metadata['name']],
                ['Alternative Name:', metadata['alternativeName']],
                ['Labels:', metadata['labels']],
                ['Description:', metadata['description']],
                ['Create Time:', metadata['createdTimestamp']],
            ]

            remote_info = metadata['remote']
            if not remote_info:
                table.append(['Remote:', '<none>'])
            else:
                table.append(['Remote:', ''])
                for r in remote_info:
                    table.extend([['- action:', r['action']],
                                  ['  timestamp:', r['timestamp']],
                                  ['  host:', r['host']], ['  id:', r['id']],
                                  ['  path:', r['path']]])

            if detail:
                object_files = {}
                object_refs = {}
                for root, _, files in os.walk(p):
                    for file in files:
                        file_path = join(root, file)
                        file_key = relpath(file_path, p).replace('\\', '/')
                        if file_key == 'metadata.yaml':
                            continue
                        elif file_key == 'references.yaml':
                            references = read_yaml_file(file_path=file_path)
                            for k, v in references.items():
                                object_refs[k] = {'path': k, 'uri': v}
                        else:
                            object_files[file_key] = {
                                'path': file_key,
                                'size_bytes': get_file_size(file_path),
                                'checksum': get_file_md5(file_path)
                            }

                table.append(['Objects:', ''])
                if not object_files:
                    table.append(['  files:', '<none>'])
                else:
                    table.append(['  files:', ''])
                    total_size = 0
                    for obj in object_files.values():
                        table.extend([['  - path:', obj['path']],
                                      [
                                          '    size:',
                                          human_readable_size(
                                              obj['size_bytes'])
                                      ], ['    checksum:', obj['checksum']]])
                        total_size += obj['size_bytes']
                    table.append([
                        '  ({} files, {} in total)'.format(
                            len(object_files), human_readable_size(total_size))
                    ])
                if not object_refs:
                    table.append(['  references:', '<none>'])
                else:
                    table.append(['  references:', ''])
                    for obj in object_refs.values():
                        table.extend([['  - path:', obj['path']],
                                      ['    uri:', obj['uri']]])

            click.echo(tabulate.tabulate(table, tablefmt='plain'))

        else:
            eprint('Invalid kind: {}'.format(metadata['kind']))


@click.argument('path', type=click.Path(exists=True))
@click.option('-f',
              '--folder',
              type=str,
              metavar='FOLDER',
              help='Path of the Folder to which the Run is uploaded.')
@click.option('-m',
              '--make-folder',
              is_flag=True,
              default=False,
              help='Make the Folder and parent Folders as needed.')
@click.option('-c',
              '--conflict-strategy',
              type=click.Choice(['skip', 'error', 'new', 'replace']),
              default='new',
              help='Strategy adopted when a Run with the same name as the Run '
              'to be uploaded already exists in the Folder')
@cli.command('upload', context_settings=CONTEXT_SETTINGS)
def cli_upload(path: str, folder: Optional[str], make_folder: bool,
               conflict_strategy: Optional[str]):
    """Upload local Runs or Artifacts.

    \b
    Examples:
      \b
      # Upload a Run:
      em upload .em/runs/cnn_keras_220823_194728_4e48t2
      \b
      # Upload all Artifacts under the parent directory:
      em upload .em/artifacts
      \b
      # Specify the path of Folder to which the Run is uploaded:
      em upload .em/runs/cnn_keras_220823_194728_4e48t2 -f image_classification/mnist
    """
    _login_for_cli_cmd()
    upload(path=path,
           folder=folder,
           make_folder=make_folder,
           conflict_strategy=conflict_strategy)


def eprint(msg, prefix=True):
    """Prints error message and exits."""
    if prefix:
        click.echo(red('error: ', bold=True) + msg, err=True)
    else:
        click.echo(msg, err=True)
    sys.exit(1)
