"""Main APIs."""

from glob import glob
import logging
import os
import re
import shutil
import threading
import time
from typing import Any, Dict, Optional, Sequence

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from t9k.em.client import CLIENT
from t9k.em.run import EM_RUN_PARENT_DIR, Run
from t9k.em.artifact import EM_ARTIFACT_PARENT_DIR, Artifact
from t9k.utils.datetime_utils import get_local_now_iso
from t9k.utils.file_utils import (basename, dirname, isdir, join,
                                  read_yaml_file, relpath, write_yaml_file)
from t9k.utils.print_utils import black, cyan, red
from t9k.utils.random_utils import is_random_name, new_random_name

_logger = logging.getLogger(__name__)
_name_pattern = re.compile(
    r'^[a-zA-Z0-9][a-zA-Z0-9_-]{0,38}[a-zA-Z0-9]$|^[a-zA-Z0-9]$')


def create_run(config_path: Optional[str] = None,
               name: str = 'default',
               hparams: Optional[Dict[str, Any]] = None,
               labels: Optional[Sequence[str]] = None,
               description: str = '',
               auto_upload: bool = False,
               folder: str = 'default',
               make_folder: bool = False,
               conflict_strategy: str = 'new') -> Run:
    """Creates and initializes a new Run.

    The local files of Run are placed under the parent directory specified by
    the environment variable `EM_RUN_PARENT_DIR` (default is relative path
    `.em/runs`).

    Examples:
        Basic usage:
        ```
        from t9k import em

        run = em.create_run(name='cnn_keras',
                            folder='cv/image-classification/mnist')
        ```

        Provide initial parameters of Run:
        ```
        hparams = {
            'batch_size': 32,
            'epochs': 1,
            'learning_rate': 0.001,
            'conv_channels1': 32,
            'conv_channels2': 64,
            'conv_channels3': 64,
            'conv_kernel_size': 3,
            'maxpool_size': 2,
            'linear_features1': 64,
        }

        run = em.create_run(name='cnn_keras',
                            hparams=hparams,
                            folder_path='cv/image-classification/mnist')
        ```

        Provide a Run config file:
        ```
        run = em.create_run(config_path='./run_config.yaml')
        ```
        where the config file `run_config.yaml` is like:
        ```
        name: cnn_keras
        hparams:
          batch_size: 32
          epochs: 1
          learning_rate: 0.001
          conv_channels1: 32
          conv_channels2: 64
          conv_channels3: 64
          conv_kernel_size: 3
          maxpool_size: 2
          linear_features1: 64
        labels:
        - Keras
        description: Train a simple CNN model that classifies images of handwritten digits.
        ```

    Args:
        config_path:
            Local path of the Run config file. For all of the following args,
            the values parsed from the config file take precedence over values
            passed in.
        name:
            Name of the Run.
        hparams:
            Initial hyperparameters of the Run.
        labels:
            Labels of the Run.
        description:
            Description of the Run.
        auto_upload:
            Whether to upload the Run and its data automatically and
            asynchronously. If False, all of the following args will not be
            used.
        folder:
            Path of the Folder to which the Run is uploaded. If the provided
            path does not start with '/', `/<current-user>/` is prepended to
            it. If `auto_upload` is False, this arg will not be used.
        make_folder:
            If True and Folder with path `folder` does not exist, make the
            Folder and parent Folders as needed. If `auto_upload` is False,
            this arg will not be used.
        conflict_strategy:
            Strategy adopted when a Run with the same name as the Run to be
            uploaded already exists in the Folder, must be 'skip', 'error',
            'new' or 'replace'. If 'skip', skip the upload; if 'error', error
            out; if 'new', upload with the alternative name of Run; if
            'replace', delete the existing Run and upload. If `auto_upload`
            is False, this arg will not be used.

    Returns:
        A Run instance created and initialized.
    """
    if config_path:
        args_list = [
            'name', 'hparams', 'labels', 'description', 'auto_upload',
            'folder', 'make_folder', 'conflict_strategy'
        ]
        args = locals()

        _logger.info('Loading config file %s to create Run',
                     black(config_path, underline=True))
        config = read_yaml_file(config_path)
        for arg in config:
            if arg not in args_list:
                _logger.error('Unknown arg %s provided by config file',
                              red(arg))
                raise ValueError('Unknown arg provided by config file: '
                                 "'{}'".format(arg))
        for arg in args_list:
            if arg not in config:
                config[arg] = args[arg]

        return create_run(**config)

    if not _name_pattern.fullmatch(name) or len(name) > 40:
        _logger.error(
            'The name of Run %s is invalid. A name of Run should only consist '
            "of letters, numbers, '-', and '_', and start and end with a "
            'letter or number. Its length should not exceed 40 characters.',
            red(name))
        raise ValueError("Invalid name of Run: '{}'".format(name))

    _logger.info('Creating Run %s', cyan(name))

    run = Run(metadata={
        'name': name,
        'labels': list(labels) if isinstance(labels, Sequence) else [],
        'description': description,
        'startTimestamp': get_local_now_iso(),
        'endTimestamp': None,
        'status': 'Running',
        'alternativeName': new_random_name(base_name=name),
        'associations': {
            'input': [],
            'output': []
        },
        'remote': []
    },
              hparams=hparams)

    p = threading.Thread(target=_start_run_monitor,
                         args=(run, auto_upload, folder, make_folder,
                               conflict_strategy))
    p.start()

    return run


def load_run(path: str,
             auto_upload: bool = False,
             folder: str = 'default',
             make_folder: bool = False,
             conflict_strategy: str = 'new') -> Run:
    """Loads a Run from local or server.

    This function will first search for the corresponding local path, followed
    by remote path. If the path is not found in either location, raise a
    `RuntimeError`.

    In the case of the remote path, if the provided path does not start with
    '/', `/<current-user>/` is prepended to it.

    Examples:
        Load by local path:
        ```
        em.load_run(path='.em/runs/cnn_keras_220823_194728_4e48t2')
        ```

        Load by remote path:
        ```
        em.load_run(path='/user/path/to/cnn_keras')
        ```

    Args:
        path:
            Local directory of the Run, or path of the Run in server.
        auto_upload:
            Whether to upload the Run and its data automatically and
            asynchronously. If False, all of the following args will not be
            used.
        folder:
            Path of the Folder to which the Run is uploaded. If the provided
            path does not start with '/', `/<current-user>/` is prepended to
            it. If `auto_upload` is False, this arg will not be used.
        make_folder:
            If True and Folder with path `folder` does not exist, make the
            Folder and parent Folders as needed. If `auto_upload` is False,
            this arg will not be used.
        conflict_strategy:
            Strategy adopted when a Run with the same name as the Run to be
            uploaded already exists in the Folder, must be 'skip', 'error',
            'new' or 'replace'. If 'skip', skip the upload; if 'error', error
            out; if 'new', upload with the alternative name of Run; if
            'replace', delete the existing Run and upload. If `auto_upload`
            is False, this arg will not be used.

    Returns:
        A Run instance loaded.
    """
    if isdir(path):  # local directory
        run = Run._load_local_dir(path)
        _logger.info('Loaded Run from local directory %s',
                     black(path, underline=True))

    else:  # remote path
        try:
            if not CLIENT.online:
                _logger.error(
                    '%s is not a local directory, if it is a remote path, '
                    'please first call `em.login()`', red(path))
                raise OSError("Not a local directory: '{}'".format(path))

            if not path.startswith('/'):
                path = '/{}/{}'.format(CLIENT.user_name, path)
            run = Run._load_remote_path(path)
            _logger.info('Loaded Run from remote path %s', cyan(path))

        except RuntimeError as e:
            if e.args[0].startswith('Remote path does not exist'):
                _logger.error('%s is not a local directory or a remote path',
                              red(path))
                raise OSError(
                    "Not a local directory or a remote path: '{}'".format(
                        path)) from e
            else:
                raise e

    run._update_status('Running')

    p = threading.Thread(target=_start_run_monitor,
                         args=(run, auto_upload, folder, make_folder,
                               conflict_strategy))
    p.start()

    return run


def create_artifact(name: str,
                    labels: Optional[Sequence[str]] = None,
                    description: str = '') -> Artifact:
    """Creates and initializes a new Artifact.

    The local files of Artifact are placed under the parent directory specified
    by the environment variable `EM_ARTIFACT_PARENT_DIR` (default is relative
    path `.em/artifacts`).

    Examples:

        ```
        tensorboard_artifact = em.create_artifact(name='tensorboard_logs')
        ```

    Args:
        name:
            Name of the Artifact.
        labels:
            Labels of the Artifact.
        description:
            Description of the Artifact.

    Returns:
        An Artifact instance created and initialized.
    """
    if not _name_pattern.fullmatch(name) or len(name) > 40:
        _logger.error(
            'The name of Artifact %s is invalid. A name of Artifact should '
            "only consist of letters, numbers, '-', and '_', and start and "
            'end with a letter or number. Its length should not exceed 40 '
            'characters.', red(name))
        raise ValueError("Invalid name of Artifact: '{}'".format(name))

    _logger.info('Creating Artifact %s', cyan(name))

    return Artifact(
        metadata={
            'name': name,
            'labels': list(labels) if isinstance(labels, Sequence) else [],
            'description': description,
            'createdTimestamp': get_local_now_iso(),
            'alternativeName': new_random_name(base_name=name),
            'remote': []
        })


# TODO: 考虑之后为加载远程 Artifact 增加不下载的选项，返回的 Artifact 对象可以用于 mark
def load_artifact(path: str) -> Artifact:
    """Loads an Artifact from local or server.

    This function will first search for the corresponding local directory,
    followed by remote path. If the path is not found in either location, raise
    a `RuntimeError`.

    In the case of the remote path, if the provided path does not start with
    '/', `/<current-user>/` is prepended to it.

    Examples:
        Load by local path:
        ```
        em.load_artifact(path=
            '.em/artifacts/tensorboard_logs_220823_194728_4e48t2')
        ```

        Load by remote path:
        ```
        em.load_artifact(path='/user/path/to/tensorboard_logs')
        ```

    Args:
        path:
            Local directory of the Artifact, or path of the Artifact in server.

    Returns:
        An Artifact instance loaded.
    """
    if isdir(path):  # local directory
        artifact = Artifact._load_local_dir(path)
        _logger.info('Loaded Artifact from local directory %s',
                     black(path, underline=True))

    else:  # remote path
        try:
            if not CLIENT.online:
                _logger.error(
                    '%s is not a local directory, if it is a remote path, '
                    'please first call `em.login()`', red(path))
                raise OSError("Not a local directory: '{}'".format(path))

            if not path.startswith('/'):
                path = '/{}/{}'.format(CLIENT.user_name, path)
            artifact = Artifact._load_remote_path(path)
            _logger.info('Loaded Artifact from remote path %s', cyan(path))

        except RuntimeError as e:
            if e.args[0].startswith('Remote path does not exist'):
                _logger.error('%s is not a local directory or a remote path',
                              red(path))
                raise OSError(
                    "Not a local directory or a remote path: '{}'".format(
                        path)) from e
            else:
                raise e

    return artifact


def upload(path: str,
           folder: str = 'default',
           make_folder: bool = False,
           conflict_strategy: str = 'new') -> None:
    """Upload local Runs or Artifacts.

    Examples:
        Upload a Run by its local directory:
        ```
        em.upload(path='.em/runs/cnn_keras_220823_194728_4e48t2')
        ```

        Upload all Artifact under the parent directory:
        ```
        em.upload(path='.em/artifacts')
        ```

        Specify the path of Folder to which the Run is uploaded:
        ```
        em.upload(path='.em/runs/cnn_keras_220823_194728_4e48t2',
                      folder='image_classification/mnist')
        ```

    Args:
        path:
            Local directory of the Run to be uploaded, or parent directory
            that contains one or more Runs.
        folder:
            Path of the Folder to which the Run is uploaded. If the provided
            path does not start with '/', `/<current-user>/` is prepended to
            it.
        make_folder:
            If True and Folder with path `folder` does not exist, make the
            Folder and parent Folders as needed.
        conflict_strategy:
            Strategy adopted when a Run with the same name as the Run to be
            uploaded already exists in the Folder, must be 'skip', 'error',
            'new' or 'replace'. If 'skip', skip the upload; if 'error', error
            out; if 'new', upload with the alternative name of Run; if
            'replace', delete the existing Run and upload.
    """
    upload_list = []

    if is_random_name(basename(path)) and isdir(path):  # Run or Artifact
        upload_list.append(path)
    else:  # parent directory
        for entry in os.listdir(path):
            if is_random_name(entry) and isdir(join(path, entry)):
                upload_list.append(join(path, entry))

    if len(upload_list) > 1:
        _logger.info('%s Runs/Artifacts are to be uploaded')
    elif len(upload_list) == 1:
        _logger.info('1 Run/Artifact is to be uploaded')
    else:
        _logger.error('No Run/Artifact is to be uploaded')
        raise RuntimeError('No Run/Artifact is to be uploaded')

    if not folder.startswith('/'):
        folder = '/{}/{}'.format(CLIENT.user_name, folder)

    for p in upload_list:
        _upload(path=p,
                folder=folder,
                make_folder=make_folder,
                conflict_strategy=conflict_strategy)


def _upload(path: str, folder: str, make_folder: bool,
            conflict_strategy: str) -> None:
    """Implements uploading a local Run or Artifact."""
    metadata_file_path = join(path, 'metadata.yaml')
    kind = read_yaml_file(metadata_file_path)['kind']
    if kind == 'Run':
        _logger.info('Uploading Run at %s', black(path, underline=True))
        run = Run._load_local_dir(dir=path)
        run.upload(folder=folder,
                   make_folder=make_folder,
                   conflict_strategy=conflict_strategy)
    elif kind == 'Artifact':
        _logger.info('Uploading the Artifact at %s', black(path,
                                                           underline=True))
        artifact = Artifact._load_local_dir(dir=path)
        artifact.upload(folder=folder,
                        make_folder=make_folder,
                        conflict_strategy=conflict_strategy)
    else:
        _logger.error('Invalid kind: %s', red(kind))
        raise RuntimeError("Invalid kind: '{}'".format(kind))


def _get_local_dir_by_name(name: str, type: str) -> str:
    """Trys to get local directory of Run or Artifact by its name.

    Only `EM_RUN_PARENT_DIR` or `EM_ARTIFACT_PARENT_DIR` will be searched.
    """
    assert type in ['Run', 'Artifact']
    search_path = EM_RUN_PARENT_DIR if type == 'Run' else EM_ARTIFACT_PARENT_DIR

    dirs = glob('{}/*_*_*_*'.format(search_path))
    target = None
    candidates = []
    for p in dirs:
        if basename(p) == name:
            target = p
            break
        if basename(p).startswith(name):
            candidates.append(p)

    if not target:
        if not candidates:
            _logger.error(
                'Failed to get local directory for no local %s matches the '
                'name %s, please check the name or local files', type,
                red(name))
            raise FileNotFoundError(
                'Failed to get local directory for no local {} matches the '
                "name: '{}'".format(type, name))
        if len(candidates) == 1:
            target = candidates[0]
        else:
            _logger.error(
                'Failed to get local directory for multiple local %ss match '
                'the name: %s match %s, please pass in the alternative name '
                'of %s', type, *red(candidates, name), type)
            raise RuntimeError(
                'Failed to get local directory for multiple local {}s match '
                "the name: {} match '{}'".format(type, candidates, name))

    return target


def _start_run_monitor(run: Run, auto_upload: bool, folder: str,
                       make_folder: bool, conflict_strategy: str) -> None:
    """Subprocess that uploads Run and its data automatically."""

    class FileMonitor(FileSystemEventHandler):

        def __init__(self) -> None:
            super().__init__()
            self.id = run.remote[-1]['id']
            self.run_path = run.remote[-1]['path']
            self.associations = read_yaml_file(
                run._locals['metadata'])['associations']

        def on_created(self, event) -> None:
            if event.is_directory:
                return

            file_path = event.src_path
            file_key = relpath(file_path, run.local).replace('\\', '/')
            CLIENT._upload_object(node_path=self.run_path,
                                  key=file_key,
                                  file_path=file_path,
                                  show_progress=False)

        def on_modified(self, event) -> None:
            if event.is_directory:
                return

            file_path = event.src_path
            file_key = relpath(file_path, run.local).replace('\\', '/')
            if file_key == 'metadata.yaml':
                current_associations = read_yaml_file(
                    run._locals['metadata'])['associations']
                d = {}
                d['input'] = [
                    a for a in current_associations['input']
                    if a not in self.associations['input']
                ]
                d['output'] = [
                    a for a in current_associations['output']
                    if a not in self.associations['output']
                ]
                if d['input'] or d['output']:
                    associations = CLIENT.get_association(node_id=self.id)
                    new_associations = []

                    for r in ['input', 'output']:
                        for a in d[r]:
                            if a['kind'] == 'Artifact':
                                artifact = Artifact._load_local_dir(
                                    a['localDir'])

                                aid = None
                                for rem in artifact.remote:
                                    if rem['host'] == CLIENT.ais_host:
                                        try:
                                            CLIENT._get_node_data(
                                                node_kind='Artifact',
                                                node=rem['id'])
                                            aid = rem['id']
                                            break
                                        except RuntimeError:
                                            pass
                                if not aid:
                                    artifact.upload(
                                        folder=folder,
                                        make_folder=make_folder,
                                        conflict_strategy=conflict_strategy)
                                    aid = artifact.remote[-1]['id']
                            else:
                                aid = a['id']

                            upload_association_flag = True
                            for node in associations['in' if r ==
                                                     'input' else 'out']:
                                if node['id'] == aid:
                                    upload_association_flag = False
                            if upload_association_flag:
                                new_associations.append({
                                    'from': aid,
                                    'to': self.id
                                } if r == 'input' else {
                                    'from': self.id,
                                    'to': aid
                                })

                    if new_associations:
                        CLIENT.upload_association(
                            associations=new_associations)
                    self.associations = current_associations

            CLIENT._upload_object(node_path=self.run_path,
                                  key=file_key,
                                  file_path=file_path,
                                  show_progress=False)

    if auto_upload:
        run.upload(folder=folder,
                   make_folder=make_folder,
                   conflict_strategy=conflict_strategy)

        event_handler = FileMonitor()
        observer = Observer()
        observer.schedule(event_handler, run.local, recursive=True)
        observer.start()

    # TODO: log resource usage data

    mt = threading.main_thread()
    while True:
        if run.status == 'Complete':
            if auto_upload:
                time.sleep(3)
                observer.stop()
                observer.join()
            return
        if mt.is_alive():
            time.sleep(1)
        else:
            _logger.info(
                'Main thread terminated without finishing Run %s, '
                "change its status to 'Error'", run.name)
            run._update_status('Error')
            if auto_upload:
                time.sleep(3)
                observer.stop()
                observer.join()
            return
