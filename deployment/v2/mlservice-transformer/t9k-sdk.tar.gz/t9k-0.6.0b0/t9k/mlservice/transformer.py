import os

import logging
import requests
from tornado import httputil
from typing import Dict

PREDICTOR_URL_FORMAT = "http://{0}{1}"

class MLTransformer():
    """MLTransformer is the core class for Transformer.

    Usage: 
    Create a Class inheriting MLTransformer, overwrite method:
    1. "preprocess" for your preprocessing
    2. "postprocess" for your postprocessing

    Attributes:
        name: 
            the Transformer's corresponding model name
        predictor_host: 
            host of predictor, this value will be used to set PREDICTOR_URL_FORMAT's {0}
    """
    def __init__(self):
        self.predictor_host = os.environ['PREDICTOR_HOST']

    def preProcess(self, path: str, requestData: bytes, headers: Dict[str, str]) -> any:
        """Preprocess data of the request
        Args:
            path: path of the request, this value will be used to set PREDICTOR_URL_FORMAT's {1}
            requestData: bytes of request body from user
            headers: headers of request, can be modified directly
        Return:
            processed data, can be Dictionary, list of tuples, bytes, or file-like object 
                to send in the body of request
        """
        return requestData

    def postProcess(self, path: str, statusCode: int, responseContent: bytes, headers: Dict[str, str]) -> bytes:
        """postprocess response.Content
        Args:
            path: path of the request
            statusCode: response.status_code
            responseContent: response.content, bytes
            headers: headers of response, can be modified directly
        Return: 
            bytes to write into response
        """
        return responseContent

    def process(self, path: str, data: any, headers: Dict[str, str]) -> requests.Response:
        """send preprocessed data to predictor
        Args:
            path: path of the request
            data: preprocessed data by self.preprocess
            headers: headers of request, should not be modified in this method
        Return:
            Response: response from predictor.
        """
        if self.predictor_host is None:
            logging.error("predictor_host is missing")
            raise NotImplementedError
        
        headers["Host"] = self.predictor_host
        url = PREDICTOR_URL_FORMAT.format(self.predictor_host, path)
        return requests.post(url, data, headers=headers)
    
    def genericProcess(self, request: httputil.HTTPServerRequest) -> (any, Dict[str, str]):
        """genericProcess request
        Args:
            request: a complete request, type httputil.HTTPServerRequest
        Return:
            body: data of request to be send
            headers: headers of request to be send
        """
        return request.body, request.headers
            
    def get(self, path: str, query: str, headers):
        pathWithQuery = path + "?" + query
        headers["Host"] = self.predictor_host
        url = PREDICTOR_URL_FORMAT.format(self.predictor_host, pathWithQuery)
        return requests.get(url, headers=headers)