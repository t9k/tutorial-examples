import requests
from ..transformer import MLTransformer

import tornado.web

class LivenessHandler(tornado.web.RequestHandler):
    def get(self):
        self.write("Alive")

class HTTPHandler(tornado.web.RequestHandler):
    def initialize(self, transformer: MLTransformer):
        self.transformer = transformer # pylint:disable=attribute-defined-outside-init

class TransformHandler(HTTPHandler):
    def post(self):
        transformer = self.transformer
        body = self.request.body
        path = self.request.path
        headers = self.request.headers
        if "Content-Length" in headers:
            del(headers["Content-Length"])
        
        data = transformer.preProcess(path, body, headers)
        response = transformer.process(path, data, headers)
        responseData = transformer.postProcess(path, response.status_code, response.content, response.headers)
        
        self.set_status(response.status_code)
        if "Content-Length" in response.headers:
            del(response.headers["Content-Length"])
        for header_name, header_value in response.headers.items():
            self.set_header(header_name, header_value)
        if responseData:
            self.write(responseData)
        
    def forward_request(self):
        body, headers = self.transformer.genericProcess(self.request)

        target = self.transformer.predictor_host
        url = self.request.protocol + "://" + target + self.request.uri
        headers["Host"] = target
        response = requests.request(self.request.method, url, headers=headers, data=body)

        self.set_status(response.status_code)
        if "Content-Length" in headers:
            del(headers["Content-Length"])
        for header_name, header_value in response.headers.items():
            self.set_header(header_name, header_value)
        if response.content:
            self.write(response.content)
    

    def get(self):
        self.forward_request()

    def head(self):
        self.forward_request()

    def delete(self):
        self.forward_request()

    def patch(self):
        self.forward_request()

    def put(self):
        self.forward_request()

    def options(self):
        self.forward_request()
