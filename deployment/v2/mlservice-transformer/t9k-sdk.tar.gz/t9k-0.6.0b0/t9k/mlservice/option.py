# option.py stores global args
import argparse

DEFAULT_HTTP_PORT = 8080

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument('--http_port', default=DEFAULT_HTTP_PORT, type=int,
                    help='The HTTP Port listened to by the model server.')
parser.add_argument('--num_processes', default=1, type=int,
                    help='The number of processes to fork')

args, _ = parser.parse_known_args()
