# Copyright 2022 The TensorStack Authors. All Rights Reserved.
"""Python SDK of TensorStack AI Platform.

User guide is available at
https://docs.kube.tensorstack.net/user-docs/latest/reference/tensorstack-sdk/index.html.
"""

from t9k.config import CONFIG

__all__ = ['CONFIG']

__version__ = '0.6.0b0'
