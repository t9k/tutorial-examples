"""Core classes."""

import json
import logging
from typing import Any, Dict, List, Mapping, Optional, Sequence, Union

from requests import HTTPError

from t9k.ah.client import CLIENT
from t9k.utils.datetime_utils import get_utc_now_iso
from t9k.utils.print_utils import cyan, red
from t9k.utils.uuid_utils import is_uuid

_logger = logging.getLogger(__name__)


def _all_methods_alive_only(cls):

    def online_only(func):

        def wrapper(self, *args, **kwargs):
            if self._alive:
                return func(self, *args, **kwargs)
            else:
                _logger.error(
                    'Cannot call method, because its `delete()` method has '
                    'been called, corresponding item has been deleted in '
                    'server')
                raise RuntimeError(
                    'Cannot call method, because its `delete()` method has '
                    'been called, corresponding item has been deleted in '
                    'server')

        return wrapper

    for attr in cls.__dict__:
        if callable(getattr(cls, attr)) and attr not in ['__init__']:
            setattr(cls, attr, online_only(getattr(cls, attr)))
    return cls


@_all_methods_alive_only
class Folder(object):
    """Represents a Asset Hub Folder in server.

    Attributes:
        path:
            Path of the Folder.
        id:
            ID of the Folder in server.
        owner:
            Owner of the Folder.
        kind:
            Kind of the Folder, is a string `'Model'` or `'Dataset'`.
        name:
            Name of the Folder.
        labels:
            Labels of the Folder.
        description:
            Description of the Folder.
        extra:
            Extra information about the Folder.
        alive:
            Whether the Folder is alive.
    """

    def __init__(self, path: str, id_: str, owner: str, asset_kind: str,
                 name: str, labels: List[str], description: str,
                 extra: str) -> None:
        assert asset_kind in ['Model', 'Dataset']
        assert is_uuid(id_)

        self._path = path
        self._id = id_
        self._owner = owner
        self._asset_kind = asset_kind
        self._name = name
        self._labels = labels
        self._description = description
        self._extra = extra

        self._alive = True
        self._assets = {}

    @property
    def path(self) -> str:
        return self._path

    @property
    def id(self) -> str:
        return self._id

    @property
    def owner(self) -> str:
        return self._owner

    @property
    def kind(self) -> str:
        return 'Folder'

    @property
    def asset_kind(self) -> str:
        return self._asset_kind

    @property
    def name(self) -> str:
        return self._name

    @property
    def labels(self) -> List[str]:
        return [l for l in self._labels if not l.startswith('assethub:')]

    @property
    def description(self) -> str:
        return self._description

    # TODO: extract extra
    @property
    def extra(self) -> str:
        return self._extra

    @property
    def alive(self) -> bool:
        return self._alive

    def update(self,
               name: Optional[str] = None,
               labels: Optional[Sequence[str]] = None,
               description: Optional[str] = None) -> None:
        """Updates the metadata of this Folder.

        If none of the args is provided, do nothing.

        Args:
            name:
                New name of this Folder.
            labels:
                New labels of this Folder.
            description:
                New description of this Folder.
        """
        name = name or self.name
        labels = _labels_to_list(labels) or self.labels
        description = description or self.description

        if (name == self.name and labels == self.labels
                and description == self.description):
            return

        update_name_flag = self.name != name
        self._name = name
        self._labels = labels
        self._description = description

        folder_data = {
            'node': self.path,
            'name': self.name,
            'description': self.description,
            'labels': self.labels,
            'extra': self.extra
        }
        CLIENT.update_folder(folder_data=folder_data)

        if update_name_flag:
            old_path = self.path
            parent, _ = self.path.rsplit(sep='/', maxsplit=1)
            self._path = '{}/{}'.format(parent, self.name)
            _logger.info('Folder %s updated to %s', *cyan(old_path, self.path))

            for asset in self._assets.values():
                asset._path = '{}/{}'.format(self.path, asset.name)
        else:
            _logger.info('Folder %s updated', cyan(self.path))

    def list_asset(self) -> List[Dict[str, Any]]:
        """Lists Assets in this Folder."""
        return CLIENT.list_asset(folder_path=self.path)

    def create_asset(self,
                     name: str,
                     labels: Optional[Sequence[str]] = None,
                     description: str = '',
                     exist_ok: bool = False) -> Union['Model', 'Dataset']:
        """Creates an Asset in this Folder.

        Args:
            name:
                Name of the Asset.
            labels:
                Labels of the Asset.
            description:
                Description of the Asset.
            exist_ok:
                If True and Asset with `name` already exists, return a `Model`
                or `Dataset` instance representing this Asset; if False and
                Asset exists, raise a `RuntimeError`.

        Returns:
            A `Model` or `Dataset` instance representing created Model or
            Dataset, depending on Asset kind of this Folder.
        """
        asset_path = '{}/{}'.format(self.path, name)

        labels = _labels_to_list(labels)

        try:
            extra = json.dumps({'createdTimestamp': get_utc_now_iso()})
            id_ = CLIENT.create_asset(asset_path=asset_path,
                                      labels=labels,
                                      description=description,
                                      extra=extra)
            if self.asset_kind == 'Model':
                _logger.info('Model %s created for Folder %s',
                             *cyan(name, self.path))
                asset = Model(id_=id_,
                              folder=self,
                              name=name,
                              labels=labels,
                              description=description,
                              extra=extra)
                self._assets[name] = asset
                return asset
            else:
                _logger.info('Dataset %s created for Folder %s',
                             *cyan(name, self.path))
                asset = Dataset(id_=id_,
                                folder=self,
                                name=name,
                                labels=labels,
                                description=description,
                                extra=extra)
                self._assets[name] = asset
                return asset
        except RuntimeError as e:
            msg = e.args[0]
            if 'already exists' in msg:
                if exist_ok:
                    _logger.info('%s %s already exists and is reused',
                                 self.asset_kind, cyan(asset_path))
                    return self.get_asset(name=name)
                else:
                    _logger.error('%s %s already exists', self.asset_kind,
                                  red(asset_path))
                    raise e
            else:
                raise e

    def get_asset(self, name: str) -> Union['Model', 'Dataset']:
        """Gets an Asset in this Folder.

        If you want to get Asset directly by its path, use `ah.get_asset()`.

        Args:
            name: Name of the Asset.

        Returns:
            A `Model` or `Dataset` instance representing retrieved Model or
            Dataset, depending on Asset kind of this Folder.
        """
        asset_path = '{}/{}'.format(self.path, name)
        asset_data = CLIENT.get_asset_data(asset_kind=self.asset_kind,
                                           asset_path=asset_path)
        id_ = asset_data['id']
        labels = asset_data['labels']
        description = asset_data['description']
        extra = asset_data['extra']

        if asset_path in self._assets:
            return self._assets[asset_path]

        if self.asset_kind == 'Model':
            asset = Model(id_=id_,
                          folder=self,
                          name=name,
                          labels=labels,
                          description=description,
                          extra=extra)
            self._assets[name] = asset
            return asset
        else:
            asset = Dataset(id_=id_,
                            folder=self,
                            name=name,
                            labels=labels,
                            description=description,
                            extra=extra)
            self._assets[name] = asset
            return asset

    def delete(self) -> None:
        """Deletes this Folder."""
        CLIENT.delete_folder(folder_path=self.path)
        _logger.info('Folder %s deleted', cyan(self.path))

        self._kill()

    def _kill(self) -> None:
        """Sets the attribute `alive` to `False` recursively."""
        self._alive = False
        for asset in self._assets.values():
            asset._kill()


class _Asset(object):
    """Represents an Asset in server."""

    def __init__(self, id_: str, folder: Folder, name: str, labels: List[str],
                 description: str, extra: str) -> None:
        assert is_uuid(id_)

        self._id = id_
        self._folder = folder
        self._kind = folder.asset_kind
        self._name = name
        self._labels = labels
        self._description = description
        self._extra = extra

        self._path = '{}/{}'.format(folder.path, name)

        self._alive = True
        self._refs = {}

    @property
    def path(self) -> str:
        return self._path

    @property
    def id(self) -> str:
        return self._id

    @property
    def folder(self) -> Folder:
        return self._folder

    @property
    def kind(self) -> str:
        return self._kind

    @property
    def name(self) -> str:
        return self._name

    @property
    def labels(self) -> List[str]:
        return self._labels

    @property
    def description(self) -> str:
        return self._description

    @property
    def extra(self) -> str:
        return self._extra

    @property
    def alive(self) -> bool:
        return self._alive

    def update(self,
               name: Optional[str] = None,
               labels: Optional[Sequence[str]] = None,
               description: Optional[str] = None) -> None:
        """Updates the metadata of this Asset.

        If none of the args is provided, do nothing.

        Args:
            name:
                New name of this Asset.
            labels:
                New labels of this Asset.
            description:
                New description of this Asset.
        """
        name = name or self.name
        labels = _labels_to_list(labels) or self.labels
        description = description or self.description

        if (name == self.name and labels == self.labels
                and description == self.description):
            return

        update_name_flag = self.name != name
        self._name = name
        self._labels = labels
        self._description = description

        asset_data = {
            'node': self.path,
            'name': self.name,
            'description': self.description,
            'labels': self.labels,
            'extra': self.extra
        }
        CLIENT.update_asset(asset_kind=self.kind, asset_data=asset_data)

        if update_name_flag:
            old_path = self.path
            parent, _ = self.path.rsplit(sep='/', maxsplit=1)
            self._path = '{}/{}'.format(parent, self.name)
            _logger.info('%s %s updated to %s', self.kind,
                         *cyan(old_path, self.path))
        else:
            _logger.info('%s %s updated', self.kind, cyan(self.path))

    def list_branch(self) -> List[Dict[str, Any]]:
        """Lists branches in this Asset."""
        return CLIENT.list_branch(asset_path=self.path)

    def list_tag(self) -> List[Dict[str, Any]]:
        """Lists tags of this Asset."""
        return CLIENT.list_tag(asset_path=self.path)

    def get_tag(self, name: str, verbose: bool = True) -> 'Tag':
        """Gets a tag of this Asset.

        Args:
            name: Name of the tag.
            verbose: Whether to log error.

        Returns:
            A `Tag` instance representing retrieved tag.
        """
        if name in self._refs:
            tag = self._refs[name]
            assert tag.kind == 'tag'
            return tag

        tags = CLIENT.list_tag(asset_path=self.path)
        tags = {b['id']: b['commit_id'] for b in tags}
        if name in tags:
            ref = Tag(asset=self, name=name, commit_id=tags[name])
            self._refs[name] = ref
            return ref
        else:
            if verbose:
                _logger.error('Tag %s does not exist for %s %s', red(name),
                              self.kind, red(self.path))
            raise RuntimeError("Tag does not exist for {} '{}': '{}'".format(
                self.kind, self.path, name))

    def get_commit(self, id: str) -> 'Commit':
        """Gets a commit of this Asset.

        If no commit matches `id`, or two or more commits matche `id`,
        raise a `RuntimeError`.

        Args:
            id: A prefix of ID of the commit.

        Returns:
            A `Commit` instance representing retrieved commit.
        """
        if len(id) <= 3:
            _logger.error(
                'Provided commit ID must be longer than 3 characters')
            raise ValueError('Provided commit ID must be longer than 3 '
                             'characters')
        elif len(id) <= 6:
            _logger.warning('Provided commit ID is recommended to be longer '
                            'than 6 characters')

        match_num = 0
        for k, v in self._refs.items():
            if k.startswith(id) and v.kind == 'commit':
                commit = v
                match_num += 1
        if match_num == 1:
            return commit

        CLIENT.get_commit_data(asset_path=self.path, commit_id=id)
        return Commit(asset=self, id_=id)

    def delete(self) -> None:
        """Deletes this Asset."""
        CLIENT.delete_asset(asset_path=self.path)
        _logger.info('%s %s deleted', self.kind, cyan(self.path))

        self._kill()

    def _kill(self) -> None:
        """Sets the attribute `alive` to `False` recursively."""
        self._alive = False
        for ref in self._refs.values():
            ref._kill()


@_all_methods_alive_only
class Model(_Asset):
    """Represents a Model in server.

    Attributes:
        path:
            Path of the Model in server.
        id:
            ID of the Model in server.
        folder:
            A `Folder` instance corresponding to the Folder that the Model
            belongs to.
        kind:
            A string `'Model'`.
        name:
            Name of the Model.
        labels:
            Labels of the Model.
        description:
            Description of the Model.
        extra:
            Extra information about the Model.
        alive:
            Whether the Model is alive.
    """

    def create_branch(self, name: str) -> 'Branch':
        """Creates an empty branch of this Model.

        Args:
            name: Name of the branch.

        Returns:
            A `Branch` instance representing created branch.
        """
        # Currently, only creating an empty branch is available. Support
        # for creating branches from existing references will be provided
        # when there is a corresponding demand from users.
        try:
            id_ = CLIENT.create_empty_branch(asset_path=self.path,
                                             branch_name=name)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 409 and 'branch already exists' in resp.text:
                _logger.error('Branch %s already exists for Model %s',
                              *red(name, self.path))
                raise RuntimeError(
                    "Branch already exists for Model '{}': '{}'".format(
                        self.path, name)) from e
            else:
                raise e

        _logger.info('Branch %s created for Model %s', *cyan(name, self.path))
        ref = Branch(asset=self, name=name, commit_id=id_)
        self._refs[name] = ref
        return ref

    def get_branch(self, name: str, verbose: bool = True) -> 'Branch':
        """Gets a branch of this Model.

        Args:
            name: Name of the branch.
            verbose: Whether to log error.

        Returns:
            A `Branch` instance representing retrieved branch.
        """
        if name in self._refs:
            branch = self._refs[name]
            assert branch.kind == 'branch'
            return branch

        branches = CLIENT.list_branch(asset_path=self.path)
        branches = {b['id']: b['commit_id'] for b in branches}
        if name in branches:
            ref = Branch(asset=self, name=name, commit_id=branches[name])
            self._refs[name] = ref
            return ref
        else:
            if verbose:
                _logger.error('Branch %s does not exist for Model %s',
                              *red(name, self.path))
            raise RuntimeError(
                "Branch does not exist for Model '{}': '{}'".format(
                    self.path, name))

    def list_object(self) -> List[Dict[str, Any]]:
        """Lists objects of this Model."""
        return self.get_branch(name='main').list_object()

    def download(self,
                 paths: Optional[Sequence[str]] = None,
                 save_dir: str = '.') -> None:
        """Downloads objects of this Model.

        Args:
            paths:
                Files or directories to download from this Dataset, is a
                sequence of paths in Dataset. Here format `a/.../b` signifies
                a file while `a/.../b/` signifies a directory. Defaults to all
                objects.
            save_dir:
                Local directory which objects are downloaded to. If the
                directory does not exist, create it. Defaults to current
                working directory.
        """
        self.get_branch(name='main').download(paths=paths, save_dir=save_dir)


@_all_methods_alive_only
class Dataset(_Asset):
    """Represents a Dataset in server.

    Attributes:
        path:
            Path of the Dataset in server.
        id:
            ID of the Dataset in server.
        folder:
            A `Folder` instance corresponding to the Folder that the Dataset
            belongs to.
        kind:
            A string `'Dataset'`.
        name:
            Name of the Dataset.
        labels:
            Labels of the Dataset.
        description:
            Description of the Dataset.
        commit_id:
            ID of the commit that the main branch points to.
        extra:
            Extra information about the Dataset.
        alive:
            Whether the Dataset is alive.
    """

    def __init__(self, id_: str, folder: Folder, name: str, labels: List[str],
                 description: str, extra: str) -> None:
        super().__init__(id_, folder, name, labels, description, extra)

        last_commit_id = CLIENT.list_commit(asset_path=self.path,
                                            ref='main')[0]['id']
        self._branch = Branch(asset=self,
                              name='main',
                              commit_id=last_commit_id)

    @property
    def commit_id(self) -> str:
        return self._branch.commit_id

    def list_commit(self) -> List[Dict[str, Any]]:
        """Lists commits of this Dataset."""
        return self._branch.list_commit()

    def list_object(self) -> List[Dict[str, Any]]:
        """Lists objects of this Dataset."""
        return self._branch.list_object()

    def create_commit(
        self,
        msg: str,
        delete: Optional[Sequence[str]] = None,
        add: Union[Sequence[str], Mapping[str, str], None] = None
    ) -> Optional['Commit']:
        """Commits changes to this Dataset.

        First delete, then add.

        Examples:
            Add a file as object to this Dataset:
            ```
            dataset.create_commit(msg='add ...', add=['0.png'])
            ```

            Specify a path in Dataset for an object to add:
            ```
            dataset.create_commit(msg='add ...', add={'0.png': 'data/'})
            ```

            Add all files under a directory as objects:
            ```
            dataset.create_commit(msg='add ...', add=['./data'])
            ```

            Delete an object from this Dataset:
            ```
            dataset.create_commit(msg='delete ...', delete=['0.png'])
            ```

            Delete all objects under the specified path:
            ```
            dataset.create_commit(msg='delete ...', delete=['data/'])
            ```

        Args:
            msg:
                Commit message.
            delete:
                Files or directories to delete from the Dataset, can be a
                sequence of paths in Dataset or `None`. If empty sequence or
                `None`, delete nothing. If the files or directories to delete
                do not exist, do nothing (rather than raise an error). Here
                format `a/.../b` signifies a file, while `a/.../b/` signifies a
                directory.
            add:
                Files or directories to add to the Dataset, can be a sequence
                of local paths, a mapping from local paths to their paths in
                Dataset, or `None`. If empty sequence, empty mapping or `None`,
                add nothing.

        Returns:
            A `Commit` instance representing created commit if changes are
            commited, `None` if not.
        """
        return self._branch.create_commit(msg=msg, delete=delete, add=add)

    def get_commit(self,
                   index: Optional[int] = None,
                   id: Optional[str] = None) -> 'Commit':
        """Gets a commit of this Dataset.

        If neither `index` or `id` is provided, return the last commit. If both
        `index` and `id` are provided, `id` will not be used.

        Args:
            index:
                Index of the commit in this branch, `0` for the last commit,
                `-1` for the first commit.
            id:
                A prefix of ID of the commit.

        Returns:
            A `Commit` instance representing retrieved commit.
        """
        return self._branch.get_commit(index=index, id=id)

    def download(self,
                 paths: Optional[Sequence[str]] = None,
                 save_dir: str = '.') -> None:
        """Downloads objects of this Dataset.

        Args:
            paths:
                Files or directories to download from this Dataset, is a
                sequence of paths in Dataset. Here format `a/.../b` signifies
                a file while `a/.../b/` signifies a directory. Defaults to all
                objects.
            save_dir:
                Local directory which objects are downloaded to. If the
                directory does not exist, create it. Defaults to current
                working directory.
        """
        self._branch.download(paths=paths, save_dir=save_dir)


class _Ref(object):
    """Represents a reference of Asset."""

    def __init__(self, asset: Union[Model, Dataset]) -> None:
        self._asset = asset

        if self.kind == 'commit':
            self._path = '{}:{}'.format(asset.path, self.id)
        else:
            self._path = '{}:{}'.format(asset.path, self.name)

        self._objects_map = {}
        self._alive = True

    @property
    def path(self) -> str:
        return self._path

    @property
    def asset(self) -> Union[Model, Dataset]:
        return self._asset

    @property
    def kind(self) -> str:
        return self._kind

    @property
    def name(self) -> str:
        return self._name

    @property
    def alive(self) -> bool:
        return self._alive

    def list_commit(self) -> List[Dict[str, Any]]:
        """Lists commits of this reference."""
        return CLIENT.list_commit(asset_path=self.asset.path, ref=self.name)

    def list_object(self) -> List[Dict[str, Any]]:
        """Lists objects of this reference."""
        ref = self.id if hasattr(self, 'id') else self.name
        object_data = CLIENT.list_object(asset_path=self.asset.path, ref=ref)
        self._objects_map = {obj['path']: obj for obj in object_data}
        return object_data

    def download(self,
                 paths: Optional[Sequence[str]] = None,
                 save_dir: str = '.') -> None:
        """Downloads objects of this reference.

        Args:
            paths:
                Files or directories to download from this reference, is a
                sequence of paths in reference. Here format `a/.../b` signifies
                a file while `a/.../b/` signifies a directory. Defaults to all
                objects.
            save_dir:
                Local directory which objects are downloaded to. If the
                directory does not exist, create it. Defaults to current
                working directory.
        """
        if paths is None:
            paths = ['/']
        elif len(paths) == 0:
            return

        self.list_object()
        CLIENT.download(ref_obj=self, object_paths=paths, save_dir=save_dir)

    def _kill(self) -> None:
        """Sets the attribute `alive` to `False`."""
        self._alive = False


@_all_methods_alive_only
class Branch(_Ref):
    """Represents a branch of Asset.

    Attributes:
        path:
            Path of the branch.
        asset:
            A `Model` or `Dataset` instance corresponding to the Asset that the
            branch belongs to.
        kind:
            A string `'branch'`.
        name:
            Name of the branch.
        commit_id:
            ID of the commit that the branch points to.
        alive:
            Whether the branch is alive.
    """

    def __init__(self, asset: Union[Model, Dataset], name: str,
                 commit_id: str) -> None:
        self._kind = 'branch'
        self._name = name
        self._commit_id = commit_id
        super().__init__(asset)

    @property
    def commit_id(self) -> str:
        return self._commit_id

    def create_commit(self,
                      msg: str,
                      delete: Optional[Sequence[str]] = None,
                      add: Union[Sequence[str], Mapping[str, str],
                                 None] = None,
                      force: bool = False) -> Optional['Commit']:
        """Commits changes to this branch.

        First delete, then add.

        Examples:
            Add a file as object to this branch:
            ```
            branch.create_commit(msg='add ...', add=['model.pt'])
            ```

            Specify a path in Asset for a file to add:
            ```
            branch.create_commit(msg='add ...', add={'model.pt': 'saved_model/'})
            ```

            Add all files under a directory as objects (with the directory):
            ```
            branch.create_commit(msg='add ...', add=['./saved_model'])
            ```

            Add all files under a directory as objects (without the directory):
            ```
            branch.create_commit(msg='add ...', add=['./saved_model/*'])
            ```

            Specify a path in Asset for a directory to add:
            ```
            branch.create_commit(msg='add ...', add={'./saved_model': 'path/to/[saved_model]'})
            # or
            branch.create_commit(msg='add ...', add={'./saved_model': 'path/to/renamed_dir'})
            ```

            Delete an object from this branch:
            ```
            branch.create_commit(msg='delete ...', delete=['model.pt'])
            ```

            Delete all objects under the specified path:
            ```
            branch.create_commit(msg='delete ...', delete=['saved_model/'])
            ```

        Args:
            msg:
                Commit message.
            delete:
                Files or directories to delete from the branch, can be a
                sequence of paths in branch or `None`. If empty sequence or
                `None`, delete nothing. If the files or directories to delete
                do not exist, do nothing (rather than raise an error). Here
                format `a/.../b` signifies a file, while `a/.../b/` signifies a
                directory.
            add:
                Files or directories to add to the branch, can be a sequence
                of local paths, a mapping from local paths to their paths in
                Asset, or `None`. If empty sequence, empty mapping or `None`,
                add nothing.
            force:
                Whether to create a new commit if unknown changes or
                unimplemented changes are found.

        Returns:
            A `Commit` instance representing created commit if changes are
            commited, `None` if not.
        """
        _logger.info('Committing changes to branch %s', cyan(self.path))

        id_ = CLIENT.update_branch(asset_path=self.asset.path,
                                   branch_name=self.name,
                                   msg=msg,
                                   delete=delete,
                                   add=add,
                                   force=force)

        if id_:
            _logger.info('Commit %s created', cyan(id_[:8]))
            self._id = id_
            ref = Commit(asset=self.asset, id_=id_)
            self.asset._refs[id_] = ref
            return ref

    def get_commit(self,
                   index: Optional[int] = None,
                   id: Optional[str] = None) -> 'Commit':
        """Gets a commit of this branch.

        If neither `index` or `id` is provided, return the last commit. If both
        `index` and `id` are provided, `id` will not be used.

        Args:
            index:
                Index of the commit in this branch, `0` for the last commit,
                `-1` for the first commit.
            id:
                A prefix of ID of the commit.

        Returns:
            A `Commit` instance representing retrieved commit.
        """
        if index is not None:
            commit_id = self.list_commit()[index]['id']
        elif id is not None:
            if len(id) <= 3:
                _logger.error(
                    'Provided commit ID must be longer than 3 characters')
                raise ValueError('Provided commit ID must be longer than 3 '
                                 'characters')
            elif len(id) <= 6:
                _logger.warning('Provided commit ID is recommended to be '
                                'longer than 6 characters')
            match_num = 0
            for c in self.list_commit():
                if c['id'].startswith(id):
                    commit_id = c['id']
                    match_num += 1
            if match_num == 0:
                _logger.error('No commit matches ID %s for branch %s',
                              *red(id, self.path))
                raise RuntimeError(
                    "No commit matches ID for branch '{}': '{}'".format(
                        self.path, id))
            elif match_num > 1:
                _logger.error('Multiple commits match ID %s for branch %s',
                              *red(id, self.path))
                raise RuntimeError(
                    "Multiple commits match ID for branch '{}': '{}'".format(
                        self.path, id))
        else:
            commit_id = self.list_commit()[0]['id']

        ref = Commit(asset=self.asset, id_=commit_id)
        self.asset._refs[commit_id] = ref
        return ref

    def create_tag(self, name: str) -> 'Tag':
        """Creates a tag that points to this branch.

        Args:
            name: Name of the tag.

        Returns:
            A `Tag` instance representing created tag.
        """
        CLIENT.create_tag(asset_path=self.asset.path,
                          ref=self.name,
                          tag_name=name)

        _logger.info('Tag %s created from branch %s for Model %s',
                     *cyan(name, self.name, self.asset.path))
        ref = Tag(asset=self.asset, name=name, commit_id=self.commit_id)
        self.asset._refs[name] = ref
        return ref

    def delete(self) -> None:
        """Deletes this branch."""
        CLIENT.delete_branch(asset_path=self.asset.path, branch_name=self.name)
        _logger.info('Branch %s deleted for Model %s',
                     *cyan(self.name, self.asset.path))

        self._kill()

    def merge(self) -> None:
        """Merges this branch to the main branch.

        Here, the specific operation of "merge" involves deleting all objects
        from the main branch and then copying all objects from this branch to
        the main branch.

        Note that this branch itself cannot be the main branch.
        """
        if self.name == 'main':
            _logger.error('Cannot merge the main branch')
            raise RuntimeError('Cannot merge the main branch')

        try:
            CLIENT.copy_branch(branch_path=self.path)
            _logger.info('Branch %s merged to the main branch for Model %s',
                         *cyan(self.name, self.asset.path))
        except RuntimeError as e:
            msg = e.args[0]
            if 'already merged' in msg:
                _logger.info(
                    'Branch %s already merged to the main branch for Model %s',
                    *cyan(self.name, self.asset.path))
            else:
                raise e

    def reset(self) -> None:
        """Resets this branch to clear all uncommitted changes."""
        asset_path, branch_name = self.path.split(sep=':')
        CLIENT.reset_branch(asset_path=asset_path, branch_name=branch_name)


@_all_methods_alive_only
class Tag(_Ref):
    """Represents a tag of Asset.

    Attributes:
        path:
            Path of the tag.
        asset:
            A `Model` or `Dataset` instance corresponding to the Asset that the
            tag belongs to.
        kind:
            A string `'tag'`.
        name:
            Name of the tag.
        commit_id:
            ID of the commit that the tag points to.
        alive:
            Whether the tag is alive.
    """

    def __init__(self, asset: Union[Model, Dataset], name: str,
                 commit_id: str) -> None:
        self._kind = 'tag'
        self._name = name
        self._commit_id = commit_id
        super().__init__(asset)

    @property
    def commit_id(self) -> str:
        return self._commit_id

    def create_tag(self, name: str) -> 'Tag':
        """Creates another tag that points to this tag.

        Args:
            name: Name of the tag.

        Returns:
            A `Tag` instance representing created tag.
        """
        CLIENT.create_tag(asset_path=self.asset.path,
                          ref=self.name,
                          tag_name=name)

        _logger.info('Tag %s created from tag %s for %s %s',
                     *cyan(name, self.name), self.asset.kind,
                     cyan(self.asset.path))
        ref = Tag(asset=self.asset, name=name, commit_id=self.commit_id)
        self.asset._refs[name] = ref
        return ref

    def delete(self) -> None:
        """Deletes this tag."""
        CLIENT.delete_tag(asset_path=self.asset.path, tag_name=self.name)
        _logger.info('Tag %s deleted for %s %s', cyan(self.name),
                     self.asset.kind, cyan(self.asset.path))

        self._kill()


@_all_methods_alive_only
class Commit(_Ref):
    """Represents a commit of Asset.

    Attributes:
        path:
            Path of the commit.
        asset:
            A `Model` or `Dataset` instance corresponding to the Asset that the
            commit belongs to.
        kind:
            A string `'commit'`.
        name:
            First 8 characters of ID of the commit.
        id:
            ID of the commit.
        alive:
            Whether the commit is alive.
    """

    def __init__(self, asset: Union[Model, Dataset], id_: str) -> None:
        self._kind = 'commit'
        self._id = id_
        self._name = id_[:8]
        super().__init__(asset)

    @property
    def id(self) -> str:
        return self._id

    def create_tag(self, name: str) -> Tag:
        """Creates a tag that points to this commit.

        Args:
            name: Name of the tag.

        Returns:
            A `Tag` instance representing created tag.
        """
        CLIENT.create_tag(asset_path=self.asset.path,
                          ref=self.id,
                          tag_name=name)

        _logger.info('Tag %s created from commit %s for %s %s',
                     *cyan(name, self.name), self.asset.kind,
                     cyan(self.asset.path))
        ref = Tag(asset=self.asset, name=name, commit_id=self.id)
        self.asset._refs[name] = ref
        return ref


def _labels_to_list(labels: Optional[Sequence[str]]) -> List[str]:
    if labels is None:
        return []
    elif isinstance(labels, Sequence):
        for label in labels:
            assert isinstance(label, str)
        return list(labels)
    else:
        _logger.error(
            'Sequence or NoneType instance expected but %s instance '
            'received for arg `labels`',
            type(labels).__name__)
        raise TypeError('Invalid kind for labels')
