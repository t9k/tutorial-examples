"""Asset Hub client."""

import logging
import math
import os
import re
from typing import (Any, BinaryIO, Dict, Iterator, List, Mapping, Optional,
                    Sequence, Union, TYPE_CHECKING)

import requests
from requests import HTTPError
import simplejson
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

from t9k import CONFIG
from t9k.utils.file_utils import (abspath, basename, dirname, exists, isdir,
                                  isfile, join, relpath, get_file_size,
                                  get_file_md5)
from t9k.utils.print_utils import red, cyan, magenta, yellow, eprint
from t9k.utils.url_utils import check_url
from t9k.utils.uuid_utils import is_uuid

if TYPE_CHECKING:
    from t9k.ah.core import _Ref

_logger = logging.getLogger(__name__)


def _all_methods_online_only(cls):

    def online_only(func):

        def wrapper(self, *args, offline_ok=False, **kwargs):
            if self.online:
                return func(self, *args, **kwargs)
            elif offline_ok:
                return
            else:
                _logger.error('Cannot correspond with Asset Hub server and '
                              'AIStore server for not logging in, please '
                              'first call `ah.login()`')
                raise RuntimeError('Cannot correspond with Asset Hub server '
                                   'and AIStore server for not logging in, '
                                   'please first call `ah.login()`')

        return wrapper

    for attr in cls.__dict__:
        if callable(getattr(cls, attr)) and attr not in [
                '__init__', '_determine_object_key', 'test_ah_connection',
                'test_ais_connection', 'request'
        ]:
            setattr(cls, attr, online_only(getattr(cls, attr)))
    return cls


@_all_methods_online_only
class _AssetHubClient(object):
    """Corresponds with Asset Hub server and AIStore server."""

    def __init__(self):
        self.ah_host = None
        self.ais_host = None
        self.api_key = None

        self.headers = {}
        self.timeout = None

        self.online = False

    def _create_node(self, node_data: Dict[str, Any]) -> str:
        """Creates a node."""
        node_path = '{}/{}'.format(node_data['parent'], node_data['name'])
        node_kind = node_data['type']
        _logger.debug('Create %s %s', node_kind, node_path)

        url = '{}/apis/v1/nodes'.format(self.ais_host)
        try:
            return self.request(method='POST', url=url,
                                json_data=node_data)['id']
        except HTTPError as e:
            resp = e.response
            if (resp.status_code == 400
                    and 'Invalid conflicting node Name' in resp.text):
                raise RuntimeError("{} already exists: '{}'".format(
                    node_kind, node_path)) from e
            else:
                raise e

    def _get_node_data(self, node_kind: str, node_path: str) -> Dict[str, Any]:
        """Gets data of a node."""
        _logger.debug('Get data of %s %s', node_kind, node_path)

        url = '{}/apis/v1/nodes/info'.format(self.ais_host)
        params = {'node': node_path}
        try:
            return self.request(method='GET', url=url, params=params)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 404 and 'node not found' in resp.text:
                _logger.error('%s %s does not exist', node_kind,
                              red(node_path))
                raise RuntimeError("{} does not exist: '{}'".format(
                    node_kind, node_path)) from e
            else:
                raise e

    def _update_node(self, node_kind: str, node_data: Dict[str, Any]) -> None:
        """Updates data of a node."""
        node_data_copy = node_data.copy()
        node = node_data_copy.pop('node')
        _logger.debug('Update %s %s with data %s', node_kind, node,
                      node_data_copy)

        url = '{}/apis/v1/nodes'.format(self.ais_host)
        try:
            self.request(method='PUT', url=url, json_data=node_data)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 400 and 'conflicting node Name' in resp.text:
                name = node_data['name']
                _logger.error('%s name %s already exists', node_kind,
                              red(name))
                raise RuntimeError("{} name already exists: '{}'".format(
                    node_kind, name)) from e
            else:
                raise e

    def _delete_node(self, node_kind: str, node_path: str) -> None:
        """Deletes a node by path."""
        _logger.debug('Delete %s %s', node_kind, node_path)

        url = '{}/apis/v1/nodes'.format(self.ais_host)
        node_data = {'node': node_path}
        self.request(method='DELETE', url=url, json_data=node_data)

    def _traverse_pages(self, url: str,
                        params: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Traverses all pages and returns a complete list of data."""
        all_data = []
        page = 1

        while True:
            params['page'] = page
            data = self.request(method='GET', url=url, params=params)
            if data['data'] is None:
                break
            all_data.extend(data['data'])
            pagination = data['pagination']
            if page * pagination['size'] >= pagination['total']:
                break
            page += 1

        return all_data

    def create_folder(self, folder_path: str, labels: List[str],
                      description: str, extra: str) -> str:
        """Creates a Folder.

        Args:
            folder_path:
                Path of the Folder.
            labels:
                Labels of the Folder.
            description:
                Description of the Folder.
            extra:
                Extra information about the Folder.

        Returns:
            ID of the Folder.
        """
        assert ('/t9k-assethub/model/' in folder_path
                or '/t9k-assethub/dataset/' in folder_path)
        if '/t9k-assethub/model/' in folder_path:
            if 'assethub:model' not in labels:
                labels.append('assethub:model')
        else:
            if 'assethub:dataset' not in labels:
                labels.append('assethub:dataset')

        parent, name = folder_path.rsplit(sep='/', maxsplit=1)
        folder_data = {
            'parent': parent,
            'name': name,
            'labels': labels,
            'description': description,
            'type': 'Folder',
            'storageType': 0,
            'extra': extra
        }
        return self._create_node(node_data=folder_data)

    def list_folder(self,
                    asset_kind: str,
                    scope: str = 'own') -> List[Dict[str, Any]]:
        """Lists Folders.

        Args:
            asset_kind:
                Asset kind of the Folders, must be `'Model'` or `'Dataset'`.
            scope:
                Scope of listing, must be `'own'`, `'shared'` or `'public'`.

        Returns:
            Folders' data retrieved.
        """
        _logger.debug('List %s Folders of Asset kind %s', scope, asset_kind)

        assert asset_kind in ['Model', 'Dataset']
        label = ('assethub:model'
                 if asset_kind == 'Model' else 'assethub:dataset')

        assert scope in ['own', 'shared', 'public']
        if scope == 'own':
            url = '{}/apis/v1/nodes'.format(self.ais_host)
            parent = '/{}/t9k-assethub/{}'.format(self.user_name,
                                                  asset_kind.lower())
            params = {
                'parent': parent,
                'type': 'Folder',
                'label': label,
                'size': 1000,
            }
        else:
            url = '{}/apis/v1/nodes/{}'.format(self.ais_host, scope)
            params = {
                'type': 'Folder',
                'label': label,
                'size': 1000,
            }

        return self._traverse_pages(url=url, params=params)

    def get_folder_data(self, folder_path: str) -> Dict[str, Any]:
        """Gets data of a Folder."""
        return self._get_node_data(node_kind='Folder', node_path=folder_path)

    def update_folder(self, folder_data: Dict[str, Any]) -> None:
        """Updates data of a Folder."""
        folder_path = folder_data['node']
        labels = folder_data['labels']
        if '/t9k-assethub/model/' in folder_path:
            if 'assethub:model' not in labels:
                labels.append('assethub:model')
        else:
            if 'assethub:dataset' not in labels:
                labels.append('assethub:dataset')

        self._update_node(node_kind='Folder', node_data=folder_data)

    def delete_folder(self, folder_path: str) -> None:
        """Deletes a Folder."""
        self._delete_node(node_kind='Folder', node_path=folder_path)

    def create_asset(self, asset_path: str, labels: List[str],
                     description: str, extra: str) -> str:
        """Creates an Asset.

        Args:
            asset_path:
                Path of the Asset.
            labels:
                Labels of the Asset.
            description:
                Description of the Asset.
            extra:
                Extra information about the Asset.

        Returns:
            ID of the Asset.
        """
        assert ('/t9k-assethub/model/' in asset_path
                or '/t9k-assethub/dataset/' in asset_path)
        asset_kind = ('Model'
                      if '/t9k-assethub/model/' in asset_path else 'Dataset')

        parent, name = asset_path.rsplit(sep='/', maxsplit=1)
        asset_data = {
            'parent': parent,
            'name': name,
            'labels': labels,
            'description': description,
            'type': asset_kind,
            'storageType': 3,
            'extra': extra
        }
        return self._create_node(node_data=asset_data)

    def list_asset(self, folder_path: str) -> List[Dict[str, Any]]:
        """Lists Assets in the specified Folder.

        Args:
            folder_path: Path of the Folder in which Assets are listed.

        Returns:
            Assets' data retrieved.
        """
        _logger.debug('List Assets in Folder %s', folder_path)

        assert ('/t9k-assethub/model/' in folder_path
                or '/t9k-assethub/dataset/' in folder_path)
        asset_kind = ('Model'
                      if '/t9k-assethub/model/' in folder_path else 'Dataset')

        url = '{}/apis/v1/nodes'.format(self.ais_host)
        params = {
            'parent': folder_path,
            'type': asset_kind,
            'size': 1000,
        }
        return self._traverse_pages(url=url, params=params)

    def get_asset_data(self, asset_kind: str,
                       asset_path: str) -> Dict[str, Any]:
        """Gets data of an Asset."""
        return self._get_node_data(node_kind=asset_kind, node_path=asset_path)

    def update_asset(self, asset_kind: str, asset_data: Dict[str,
                                                             Any]) -> None:
        """Updates data of an Asset."""
        assert asset_kind in ['Model', 'Dataset']
        self._update_node(node_kind=asset_kind, node_data=asset_data)

    def delete_asset(self, asset_path: str) -> None:
        """Deletes an Asset."""
        self._delete_node(node_kind='Asset', node_path=asset_path)

    def create_branch(self, asset_path: str, ref: str,
                      branch_name: str) -> None:
        """Creates a branch of Asset.

        Args:
            asset_path:
                Path of the Asset.
            ref:
                Reference (branch name, tag name or commit ID) that the created
                branch points to.
            branch_name:
                Name of the branch.
        """
        _logger.debug('Create branch %s from ref %s of Asset %s', branch_name,
                      ref, asset_path)
        url = '{}/apis/v1/nodes/branches'.format(self.ais_host)
        params = {'node': asset_path}
        branch_data = {'name': branch_name, 'source': ref}
        self.request(method='POST',
                     url=url,
                     params=params,
                     json_data=branch_data)

    def create_empty_branch(self, asset_path: str, branch_name: str) -> str:
        """Creates an empty branch of Asset.

        Args:
            asset_path:
                ID of the Asset.
            branch_name:
                Name of the branch.

        Returns:
            ID of the first commit.
        """
        _logger.debug('Create empty branch %s of Asset %s', branch_name,
                      asset_path)
        first_commit = self.list_commit(asset_path=asset_path, ref='main')[-1]
        assert first_commit['parents'] == []
        self.create_branch(asset_path=asset_path,
                           branch_name=branch_name,
                           ref=first_commit['id'])
        return first_commit['id']

    def list_branch(self, asset_path: str) -> List[Dict[str, str]]:
        """Lists branches of the specified Asset.

        Args:
            asset_path: Path of the Asset whose branches are listed.

        Returns:
            Branches' data retrieved.
        """
        _logger.debug('List branches of Asset %s', asset_path)
        url = '{}/apis/v1/nodes/branches'.format(self.ais_host)
        params = {'node': asset_path, 'size': 1000}
        return self._traverse_pages(url=url, params=params)

    def delete_branch(self, asset_path: str, branch_name: str) -> None:
        """Deletes a branch of Asset."""
        _logger.debug('Delete branch %s of Asset %s', branch_name, asset_path)
        url = '{}/apis/v1/nodes/branches'.format(self.ais_host)
        params = {'node': asset_path, 'branch': branch_name}
        try:
            self.request(method='DELETE', url=url, params=params)
        except HTTPError as e:
            resp = e.response
            if (resp.status_code == 500 and
                    'cannot delete repository default branch' in resp.text):
                _logger.error('Cannot delete the main branch')
                raise RuntimeError('Cannot delete the main branch') from e
            else:
                raise e

    def create_tag(self, asset_path: str, ref: str, tag_name: str) -> None:
        """Creates a tag of Asset.

        Args:
            asset_path:
                Path of the Asset.
            ref:
                Reference (branch name, tag name or commit ID) that the created
                tag points to.
            tag_name:
                Name of the tag.
        """
        _logger.debug('Create tag %s from ref %s of Asset %s', tag_name, ref,
                      asset_path)
        url = '{}/apis/v1/nodes/tags'.format(self.ais_host)
        params = {'node': asset_path}
        tag_data = {'name': tag_name, 'ref': ref}
        try:
            self.request(method='POST',
                         url=url,
                         params=params,
                         json_data=tag_data)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 409 and 'tag already exists' in resp.text:
                _logger.error('Tag %s of Asset %s already exists',
                              *red(tag_name, asset_path))
                raise RuntimeError(
                    "Tag of Asset {} already exists: '{}'".format(
                        asset_path, tag_name)) from e
            else:
                raise e

    def list_tag(self, asset_path: str) -> None:
        """Lists tags of the specified Asset.

        Args:
            asset_path: Path of the Asset whose tags are listed.

        Returns:
            Tags' data retrieved.
        """
        _logger.debug('List tags of Asset %s', asset_path)
        url = '{}/apis/v1/nodes/tags'.format(self.ais_host)
        params = {'node': asset_path, 'size': 1000}
        return self._traverse_pages(url=url, params=params)

    def delete_tag(self, asset_path: str, tag_name: str) -> None:
        """Deletes a tag of Asset."""
        _logger.debug('Delete tag %s of Asset %s', tag_name, asset_path)
        url = '{}/apis/v1/nodes/tags'.format(self.ais_host)
        params = {'node': asset_path, 'tag': tag_name}
        self.request(method='DELETE', url=url, params=params)

    def list_object(self, asset_path: str, ref: str) -> List[Dict[str, Any]]:
        """Lists objects of the specified commit.

        Args:
            asset_path:
                Path of the Asset.
            ref:
                Reference (branch name, tag name or commit ID) whose objects
                are listed.
        """
        _logger.debug('List objects of ref %s of Asset %s', ref, asset_path)
        url = '{}/apis/v1/objects/ls'.format(self.ais_host)
        params = {'path': '{}:{}'.format(asset_path, ref), 'size': 1000}
        return self._traverse_pages(url=url, params=params)

    def download(self, ref_obj: '_Ref', object_paths: Sequence[str],
                 save_dir: str) -> None:
        """Downloads objects of the specified reference.

        Args:
            ref_obj:
                A `Branch`, `Tag` or `Commit` instance.
            object_paths:
                Paths of the objects to download from the reference. Here
                format `a/.../b` signifies a file while `a/.../b/` signifies
                a directory.
            save_dir:
                Local directory which objects are downloaded to. If the
                directory does not exist, create it.
        """
        objects_map = ref_obj._objects_map
        ref_kind = ref_obj.kind
        if ref_kind == 'commit':
            ref = ref_obj.id
        else:  # 'commit'
            ref = ref_obj.name

        download_keys = []
        for key in object_paths:
            if not key.endswith('/'):  # file
                if key in objects_map:
                    download_keys.append(key)
                else:
                    _logger.error('File %s does not exist in %s %s', red(key),
                                  ref_kind, red(ref))
                    raise RuntimeError(
                        "File does not exist in {} '{}': '{}'".format(
                            ref_kind, ref, key))
            else:  # dir
                if key == '/':  # all objects
                    key = ''
                is_dir_flag = False
                for k in objects_map:
                    if k.startswith(key):
                        is_dir_flag = True
                        download_keys.append(k)
                if not is_dir_flag:
                    if key == '':
                        _logger.warning(
                            'No objects exist in %s %s, download nothing',
                            ref_kind, yellow(ref))
                        return
                    _logger.error('Directory %s does not exist in %s %s',
                                  red(key), ref_kind, red(ref))
                    raise RuntimeError(
                        "Directory does not exist in {} '{}': '{}'".format(
                            ref_kind, ref, key))

        download_keys = list(set(download_keys))
        object_num = len(download_keys)
        for i, key in enumerate(download_keys, start=1):
            file_path = join(save_dir, key)

            if isfile(file_path):
                obj_metadata = ref_obj._objects_map[key]
                _logger.info(
                    'Local file for object %s/%s %s already exists, verifying '
                    'its size and checksum', i, object_num, cyan(key))
                if (get_file_size(file_path) == obj_metadata['size_bytes'] and
                        get_file_md5(file_path) == obj_metadata['checksum']):
                    print(' ' * 9 + 'Verification passed, skip this download',
                          flush='True')
                    continue
                else:
                    # For objects larger than 100MiB, since they are multipart
                    # uploaded, currently their checksum does not mean
                    # anything, thus MD5 verification is bound to fail.
                    print(' ' * 9 +
                          ('Verification failed, or object size > 100MiB '
                           'prevented verification, redownload and overwrite '
                           'the original file.'),
                          flush='True')

            os.makedirs(dirname(file_path), exist_ok=True)
            _logger.info('Downloading object %s/%s %s:', i, object_num,
                         cyan(key))
            self._download_object(asset_path=ref_obj.asset.path,
                                  ref=ref,
                                  key=key,
                                  size=objects_map[key]['size_bytes'],
                                  download_path=file_path)

    def _download_object(self, asset_path: str, ref: str, key: str, size: int,
                         download_path: str) -> None:
        """Downloads an object of the specified reference."""
        object_path = '{}:{}/{}'.format(asset_path, ref, key)
        _logger.debug('Download object %s', object_path)
        url = '{}/apis/v1/objects'.format(self.ais_host)
        params = {'path': object_path, 'apikey': self.api_key}

        _logger.debug('Request info:')
        _logger.debug('  URL: %s', url)
        _logger.debug('  method: GET')
        _logger.debug('  params: %s', params)

        progress = Progress(' ' * 8,
                            BarColumn(bar_width=None),
                            '[progress.percentage]{task.percentage:>3.1f}%',
                            '•',
                            DownloadColumn(),
                            '•',
                            TransferSpeedColumn(),
                            '•',
                            TimeRemainingColumn(),
                            console=Console(stderr=True))
        with progress:
            task_id = progress.add_task('download', start=False)
            progress.update(task_id, total=size)

            with requests.get(url=url,
                              params=params,
                              stream=True,
                              timeout=self.timeout,
                              allow_redirects=False) as r:
                r.raise_for_status()
                progress.start_task(task_id)
                with open(download_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=16384):  # 16KB
                        f.write(chunk)
                        progress.update(task_id, advance=len(chunk))

    def update_branch(self, asset_path: str, branch_name: str, msg: str,
                      delete: Optional[Sequence[str]],
                      add: Union[Sequence[str], Mapping[str, str],
                                 None], force: bool) -> Optional[str]:
        """Updates a branch of Asset.

        First delete, then add.

        Args:
            asset_path:
                Path of the Asset.
            branch_name:
                Name of the branch to update.
            msg:
                Update message.
            delete:
                Files or directories to delete from the branch, can be a
                sequence of keys or `None`. If empty sequence or `None`,
                delete nothing.
            add:
                Files or directories to add to the branch, can be a sequence
                of local paths, a mapping from local paths to their keys, or
                `None`. If empty sequence, empty mapping or `None`, add
                nothing.
            force:
                Whether to create a new commit if unknown changes or
                unimplemented changes are found.

        Returns:
            ID of created commit if the branch is updated, `None` if not.
        """
        _logger.debug('Update branch %s of Asset %s', branch_name, asset_path)

        delete_changes = {}
        add_changes = {}
        try:
            if delete:
                if isinstance(delete, Sequence):
                    for path in delete:
                        if path.endswith('/*'):
                            path = path[:-1]

                        if path.endswith('/'):
                            paths = self._delete_dir(asset_path=asset_path,
                                                     branch_name=branch_name,
                                                     key=path)
                            for p in paths:
                                delete_changes[p] = {
                                    'path': p,
                                    'path_type': 'object',
                                    'size_bytes': 0
                                }
                        else:
                            self._delete_object(asset_path=asset_path,
                                                branch_name=branch_name,
                                                key=path)
                            delete_changes[path] = {
                                'path': path,
                                'path_type': 'object',
                                'size_bytes': 0
                            }
                else:
                    _logger.error(
                        'Sequence or NoneType instance expected but %s '
                        'instance received for arg `delete`',
                        type(delete).__name__)
                    raise TypeError('Invalid type for `delete`')
            if add:
                if not (isinstance(add, Sequence) or isinstance(add, Mapping)):
                    _logger.error(
                        'Sequence, Mapping or NoneType instance expected but '
                        '%s instance received for arg add',
                        type(add).__name__)
                    raise TypeError('Invalid type for arg add')

                self.__upload_count = 0
                self.__upload_total = 0
                for path in add:
                    if path.endswith('/*') or path.endswith('\\*'):
                        path = path[:-1]
                        if not isdir(path):
                            _logger.error('Directory %s does not exist',
                                          red(path))
                            raise FileNotFoundError(
                                "No such directory: '{}'".format(path))
                        self.__upload_total += sum(
                            [len(files) for _, _, files in os.walk(path)])
                    elif not exists(path):
                        _logger.error('Path %s does not exist', red(path))
                        raise FileNotFoundError(
                            "No such file or directory: '{}'".format(path))
                    elif isfile(path):
                        self.__upload_total += 1
                    else:  # isdir(path)
                        self.__upload_total += sum(
                            [len(files) for _, _, files in os.walk(path)])

                if isinstance(add, Sequence):
                    for path in add:
                        if path.startswith('\\'):  # Windows path
                            path = re.sub(r'^\\([A-Z])\\', r'\1:\\', path)

                        if path.endswith('/*') or path.endswith(
                                '\\*'):  # dir with wildcard
                            path = path[:-1]
                            objs = self._add_dir(asset_path=asset_path,
                                                 branch_name=branch_name,
                                                 dir_path=path,
                                                 key='')
                            for obj in objs:
                                add_changes[obj['path']] = obj
                        elif isfile(path):
                            obj = self._add_file(asset_path=asset_path,
                                                 branch_name=branch_name,
                                                 file_path=path)
                            add_changes[obj['path']] = obj
                        else:  # isdir(path)
                            objs = self._add_dir(asset_path=asset_path,
                                                 branch_name=branch_name,
                                                 dir_path=path)
                            for obj in objs:
                                add_changes[obj['path']] = obj
                else:  # isinstance(add, Mapping)
                    for path, key in add.items():
                        if isfile(path):
                            obj = self._add_file(asset_path=asset_path,
                                                 branch_name=branch_name,
                                                 file_path=path,
                                                 key=key)
                            add_changes[obj['path']] = obj
                        else:  # isdir(path)
                            objs = self._add_dir(asset_path=asset_path,
                                                 branch_name=branch_name,
                                                 dir_path=path,
                                                 key=key)
                            for obj in objs:
                                add_changes[obj['path']] = obj
        except (KeyboardInterrupt, Exception) as e:
            _logger.info('Commit canceled')
            _logger.debug('Cancel update of branch %s of Asset %s',
                          branch_name, asset_path)
            self.reset_branch(asset_path=asset_path, branch_name=branch_name)
            raise e

        # compare changes before commit
        unknown_changes = []
        unimplemented_changes = []

        real_changes = self.diff_branch(asset_path=asset_path,
                                        branch_name=branch_name)
        objects = self.list_object(asset_path=asset_path, ref=branch_name)
        objects = {obj['path']: obj for obj in objects}

        for rc in real_changes:
            if rc['type'] == 'removed':
                if rc['path'] not in delete_changes:
                    unknown_changes.append(rc['path'])
            else:  # 'added' or 'changed'
                if rc['path'] not in add_changes:
                    unknown_changes.append(rc['path'])
        for dc in delete_changes:
            if dc in objects and dc not in add_changes:
                unimplemented_changes.append(dc)
        for ac, obj in add_changes.items():
            if ac not in objects:
                unimplemented_changes.append(ac)
            elif obj['size_bytes'] != objects[ac]['size_bytes']:
                unimplemented_changes.append(ac)

        if unknown_changes:
            _logger.warning('Unknown changes found: %s', unknown_changes)
        if unimplemented_changes:
            _logger.warning('Unimplemented changes found: %s', unknown_changes)
        if (unknown_changes or unimplemented_changes) and (not force):
            _logger.error(
                'Commit canceled for unknown or unimplemented changes')
            raise RuntimeError(
                'Commit canceled for unknown or unimplemented changes')

        if not real_changes:
            _logger.warning('No changes to commit')
            return

        new_commit_id = self.create_commit(asset_path=asset_path,
                                           branch_name=branch_name,
                                           msg=msg)

        # cannot compare changes after commit, because cannot get commit
        # changes

        return new_commit_id

    def _add_file(self,
                  asset_path: str,
                  branch_name: str,
                  file_path: str,
                  key: Optional[str] = None) -> Dict[str, Any]:
        """Uploads a local file as an object to a branch of Asset.

        Args:
            asset_path:
                Path of the Asset.
            branch_name:
                Name of the branch to update.
            file_path:
                Path of the file to be uploaded.
            key:
                Key of the object. It might be modified by
                `_determine_object_key()`.

        Returns:
            Object data.
        """
        file_path = abspath(file_path)
        assert isfile(file_path)

        key = self._determine_object_key(file_path, key)
        self.__upload_count += 1
        _logger.info('Uploading object %s/%s %s:', self.__upload_count,
                     self.__upload_total, cyan(key))
        return self._upload_object(asset_path=asset_path,
                                   branch_name=branch_name,
                                   key=key,
                                   file_path=file_path)

    def _add_dir(self,
                 asset_path: str,
                 branch_name: str,
                 dir_path: str,
                 key: Optional[str] = None) -> List[Dict[str, Any]]:
        """Uploads all files under a local directory as objects to a branch
        of Asset.

        Args:
            asset_path:
                Path of the Asset.
            branch_name:
                Name of the branch to update.
            dir_path:
                Path of the directory under which all files are to be uploaded.
            key:
                Key of the object. It might be modified by
                `_determine_object_key()`.

        Returns:
            Objects data.
        """
        dir_path = abspath(dir_path)
        assert isdir(dir_path)

        key = self._determine_object_key(dir_path, key)

        objs_data = []
        for root, _, files in os.walk(dir_path):
            for file in files:
                file_path = join(root, file)
                file_key = join(key, relpath(file_path,
                                             dir_path)).replace('\\', '/')
                self.__upload_count += 1
                _logger.info('Uploading object %s/%s %s:', self.__upload_count,
                             self.__upload_total, cyan(file_key))
                data = self._upload_object(asset_path=asset_path,
                                           branch_name=branch_name,
                                           key=file_key,
                                           file_path=file_path)
                objs_data.append(data)

        return objs_data

    @staticmethod
    def _determine_object_key(path: str, key: Optional[str] = None) -> str:
        if key is None:
            return basename(path)

        if key.startswith('/'):
            key = key[1:]
        if key.endswith('/'):
            key = key + basename(path)
        return key

    def _upload_object(self, asset_path: str, branch_name: str, key: str,
                       file_path: str) -> Dict[str, Any]:
        """Uploads an object to a branch of Asset."""
        object_path = '{}:{}/{}'.format(asset_path, branch_name, key)
        _logger.debug('Upload file %s to object path %s', file_path,
                      object_path)

        assert isfile(file_path)
        size = get_file_size(file_path)
        if size <= 100 * 1024 * 1024:  # 100MiB
            print(' ' * 9 + 'Uploading...', end='', flush='True')
            url = '{}/apis/v1/objects'.format(self.ais_host)
            params = {'path': object_path}
            files = {'content': open(file_path, 'rb')}
            data = self.request(method='POST',
                                url=url,
                                params=params,
                                files=files)
            print('\r' + ' ' * 9 + 'Done' + ' ' * 8, flush='True')
            return data

        elif size <= 25_000_000 * 1024 * 1024:  # 25,000,000MiB, ~23.842TiB
            url_create = '{}/apis/v1/objects/multipart'.format(self.ais_host)
            params = {'path': object_path}
            upload_id = self.request(method='POST',
                                     url=url_create,
                                     params=params)['uploadId']
            url_upload = ('{}/apis/v1/objects/multipart/{}').format(
                self.ais_host, upload_id)

            def read_in_chunks(file_object: BinaryIO,
                               chunk_size: int) -> Iterator[bytes]:
                while True:
                    data = file_object.read(chunk_size)
                    if not data:
                        break
                    yield data

            # Expressed in units of MiB, the chunk size is determined by taking
            # the square root of the object size and rounding down, e.g.
            #
            # | object size             | chunk num * size           |
            # | ----------------------- | -------------------------- |
            # | 100MiB                  | 10 * 10Mi                  |
            # | 1,000MiB (~0.98GiB)     | 33 * 31Mi                  |
            # | 10,000MiB (~9.8GiB)     | 100 * 100 MiB              |
            # | 100,000MiB (~98GiB)     | 317 * 316Mi                |
            # | 1,000,000MiB (~0.95TiB) | 1000 * 1000 MiB (~0.98GiB) |
            # | 10,000,000MiB (~9.5TiB) | 3163 * 3162 MiB (~3.1GiB)  |
            # | 25,000,000MiB (~24TiB)  | 5000 * 5000 MiB (~4.9GiB)  |

            size_in_mib = size / 1024**2
            chunk_size_in_mib = math.floor(math.sqrt(size_in_mib))
            chunk_size = chunk_size_in_mib * 1024**2

            progress = Progress(
                ' ' * 8,
                BarColumn(bar_width=None),
                '[progress.percentage]{task.percentage:>3.1f}%',
                '•',
                DownloadColumn(),
                '•',
                TransferSpeedColumn(),
                '•',
                TimeRemainingColumn(),
                console=Console(stderr=True))
            with progress:
                task_id = progress.add_task('upload', start=False)
                progress.update(task_id, total=size)

                # The try-except block is used to cancel multipart upload.
                # Currently the server supports canceling multipart upload.
                try:
                    with open(file_path, 'rb') as f:
                        parts = []
                        progress.start_task(task_id)
                        for n, piece in enumerate(read_in_chunks(
                                f, chunk_size),
                                                  start=1):

                            params = {'path': object_path, 'partNumber': n}
                            files = {'content': piece}
                            etag = self.request(method='PUT',
                                                url=url_upload,
                                                params=params,
                                                files=files)['eTag']

                            parts.append({'etag': etag, 'partNumber': n})
                            progress.update(task_id, advance=len(piece))

                        params = {'path': object_path}
                        self.request(method='POST',
                                     url=url_upload,
                                     params=params,
                                     json_data={'parts': parts})
                        return {
                            'path': key,
                            'path_type': 'object',
                            'size_bytes': size
                        }
                except (KeyboardInterrupt, Exception) as e:
                    _logger.info('Upload canceled')
                    _logger.debug('Cancel uploading file %s to object path %s',
                                  file_path, object_path)
                    params = {'path': object_path}
                    self.request(method='DELETE',
                                 url=url_upload,
                                 params=params)
                    raise e
        else:
            size_in_tib = round(size / 1024**4, 2)
            _logger.error(
                'Cannot upload object %s, its size %sTiB exceeds the limit '
                'of ~23.842TiB', *red(key, size_in_tib))
            raise RuntimeError(
                'Cannot upload object {}, its size {}TiB exceeds the limit '
                'of ~23.842TiB'.format(key, size_in_tib))

    def _delete_object(self, asset_path: str, branch_name: str,
                       key: str) -> None:
        """Deletes an object from the specified branch of Asset."""
        object_path = '{}:{}/{}'.format(asset_path, branch_name, key)
        _logger.debug('Delete object %s', object_path)
        _logger.info('Deleting object %s:', cyan(key))

        print(' ' * 9 + 'Deleting...', end='', flush='True')
        url = '{}/apis/v1/objects'.format(self.ais_host)
        params = {'path': object_path}
        self.request(method='DELETE', url=url, params=params)
        print('\r' + ' ' * 9 + 'Done' + ' ' * 8, flush='True')

    def _delete_dir(self, asset_path: str, branch_name: str,
                    key: str) -> List[str]:
        """Deletes a directory from the specified branch of Asset."""
        branch_path = '{}:{}'.format(asset_path, branch_name)
        dir_path = '{}:{}/{}'.format(asset_path, branch_name, key)
        _logger.debug('Delete all objects under path %s', dir_path)
        _logger.info('Deleting all objects under path %s:', cyan(key))

        print(' ' * 9 + 'Deleting...', end='', flush='True')
        objects = self.list_object(asset_path=asset_path, ref=branch_name)
        paths = [obj['path'] for obj in objects if obj['path'].startswith(key)]
        url = '{}/apis/v1/objects/delete'.format(self.ais_host)
        data = {'node': branch_path, 'paths': paths}
        self.request(method='POST', url=url, json_data=data)
        print('\r' + ' ' * 9 + 'Done' + ' ' * 8, flush='True')

        return paths

    def diff_branch(self, asset_path: str,
                    branch_name: str) -> List[Dict[str, Any]]:
        """Gets uncommitted changes of a branch of Asset."""
        _logger.debug('Get uncommitted changes of branch %s of Asset %s',
                      branch_name, asset_path)
        url = '{}/apis/v1/nodes/branches/diff'.format(self.ais_host)
        params = {'node': asset_path, 'branch': branch_name, 'size': 1000}
        return self._traverse_pages(url=url, params=params)

    def reset_branch(self, asset_path: str, branch_name: str) -> str:
        """Removes uncommitted changes of a branch of Asset."""
        _logger.debug('Remove uncommitted changes of branch %s of Asset %s',
                      branch_name, asset_path)
        url = '{}/apis/v1/nodes/branches'.format(self.ais_host)
        params = {'node': asset_path, 'branch': branch_name}
        data = {'type': 'reset'}
        self.request(method='PUT', url=url, params=params, json_data=data)

    def create_commit(self, asset_path: str, branch_name: str,
                      msg: str) -> str:
        """Creates a new commit of the specified branch of Asset.

        Returns:
            ID of the created commit.
        """
        _logger.debug('Create a new commit of branch %s of Asset %s',
                      asset_path, branch_name)
        url = '{}/apis/v1/nodes/commits'.format(self.ais_host)
        params = {'node': asset_path, 'branch': branch_name}
        commit_data = {'message': msg}
        return self.request(method='POST',
                            url=url,
                            params=params,
                            json_data=commit_data)['id']

    def list_commit(self, asset_path: str, ref: str) -> Dict[str, Any]:
        """Lists commits of the specified reference.

        Args:
            asset_path: Path of the Asset.
            reference: Name/ID of the reference whose commits are listed.

        Returns:
            Commits' data retrieved.
        """
        _logger.debug('List commits of reference %s of Asset %s', ref,
                      asset_path)
        url = '{}/apis/v1/nodes/commits'.format(self.ais_host)
        params = {'node': asset_path, 'ref': ref, 'size': 1000}
        return self._traverse_pages(url=url, params=params)

    def get_commit_data(self, asset_path: str,
                        commit_id: str) -> Dict[str, Any]:
        """Gets data of a commit."""
        url = '{}/apis/v1/nodes/commits/info'.format(self.ais_host)
        params = {'node': asset_path, 'commit': commit_id}
        try:
            return self.request(method='GET', url=url, params=params)
        except HTTPError as e:
            resp = e.response
            if (resp.status_code == 404 and 'commit not found' in resp.text):
                _logger.error(
                    'No commit matches ID or multiple commits match ID %s',
                    red(commit_id))
                raise ValueError(
                    "No commit matches ID or multiple commits match ID: '{}'".
                    format(commit_id)) from e
            else:
                raise e

    def copy_branch(self, branch_path: str) -> None:
        """Copies the specified branch to the main branch."""
        asset_path, branch_name = branch_path.split(sep=':')
        _logger.debug('Copy branch %s to the main branch', branch_path)
        url = '{}/apis/v1/nodes/copy'.format(self.ais_host)
        data = {
            'from': {
                'node': asset_path,
                'ref': branch_name
            },
            'to': {
                'node': asset_path,
                'branch': 'main'
            },
            'mode': 'replace'
        }
        try:
            self.request(method='POST', url=url, json_data=data)
        except HTTPError as e:
            resp = e.response
            if (resp.status_code == 400 and 'commit: no changes' in resp.text):
                raise RuntimeError(
                    "Branch already merged: '{}'".format(branch_path)) from e
            else:
                raise e

    def test_ah_connection(self) -> None:
        """Tests connection to Asset Hub server."""
        _logger.debug('Test connection to Asset Hub server with URL %s',
                      self.ah_host)

        url = '{}/apis/v1/init'.format(self.ah_host)
        try:
            self.request(method='GET', url=url)
        except requests.ConnectionError as e:
            _logger.error(
                'Unable to connect to Asset Hub server, please check '
                'your network connection, status of server, or URL of server')
            raise e
        except RuntimeError as e:
            if e.args[0] == 'Incorrect URL':
                _logger.error(
                    'Incorrect URL of Asset Hub server: %s, please '
                    'check the provided URL', red(self.ah_host))
                raise RuntimeError(
                    "Incorrect URL of Asset Hub server: '{}'".format(
                        self.ah_host)) from e
            else:
                raise e

    def test_ais_connection(self) -> None:
        """Tests connection to AIStore server."""
        _logger.debug('Test connection to AIStore server with URL %s',
                      self.ais_host)

        try:
            url = '{}/oauth2/userinfo'.format(self.ais_host)
            params = {'apikey': self.api_key}
            self.user_name = self.request(method='GET', url=url,
                                          params=params)['preferred_username']
            _logger.debug("Get user name '%s'", self.user_name)

            url = '{}/apis/v1/nodes'.format(self.ais_host)
            params = {
                'parent': '/{}/t9k-assethub'.format(self.user_name),
                'type': 'Folder',
            }
            resp = self.request(method='GET', url=url, params=params)
            # resp should be like
            # {'pagination': {'page': 1, 'size': 10, 'total': 2}, 'data': [...]}
            # print('---')
            # print(resp)
            # print('---')
            assert isinstance(resp, Dict)
            assert resp['pagination']['total'] == 2
        except requests.ConnectionError as e:
            _logger.error(
                'Unable to connect to AIStore server, please check '
                'your network connection, status of server, or URL of server')
            raise e
        except RuntimeError as e:
            if e.args[0] == 'Incorrect URL':
                _logger.error(
                    'Incorrect URL of AIStore server: %s, please '
                    'check the provided URL', red(self.ais_host))
                raise RuntimeError(
                    "Incorrect URL of AIStore server: '{}'".format(
                        self.ais_host)) from e
            else:
                raise e

        _logger.info(
            'Logged in to Asset Hub server and AIStore server as user %s',
            magenta(self.user_name, bold=True))

    def request(self,
                method: str,
                url: str,
                params: Optional[Dict[str, Any]] = None,
                json_data: Optional[Any] = None,
                data: Optional[Any] = None,
                files: Optional[Dict[str, Any]] = None,
                headers: Optional[Dict[str, str]] = None) -> str:
        """Sends request to server.

        Args:
            method: Method of the HTTP request.
            url: URL of the HTTP request.
            params: Query parameters of the HTTP request.
            data: Contents to be sent in the request body.
            headers: Headers of the HTTP request.

        Returns:
            A dict parsed from JSON in content of the response, or a string of
            content of the response if the response body does not contain valid
            JSON.

        Raises:
            requests.HTTPError: An HTTP error occurred.
        """
        params = params if params else {}
        params['apikey'] = self.api_key
        headers = headers if headers else self.headers

        _logger.debug('Request info:')
        _logger.debug('  URL: %s', url)
        _logger.debug('  method: %s', method)
        _logger.debug('  params: %s', params)
        if json_data:
            _logger.debug('  json: %s', json_data)
        if data:
            _logger.debug('  data: %s', data)
        if files:
            files_to_print = {k: '...' for k in files}
            _logger.debug('  files: %s', files_to_print)

        resp = requests.request(method=method,
                                url=url,
                                params=params,
                                json=json_data,
                                data=data,
                                files=files,
                                headers=headers,
                                timeout=self.timeout,
                                allow_redirects=False)

        if not resp.ok:
            http_error_msg = ''
            if resp.status_code == 302:
                _logger.error('API Key not provided')
                raise RuntimeError('API Key not provided')
            if 400 <= resp.status_code < 500:
                if resp.status_code == 400 and resp.text.startswith(
                        'api key') and resp.text.endswith('not found\n'):
                    _logger.error(
                        'API Key not found, please check the provided API Key')
                    raise RuntimeError('API Key not found')
                elif resp.status_code == 400 and resp.text.startswith(
                        'query is needed'):
                    _logger.error(
                        'Empty string provided for API Key, please provide '
                        'a valid API Key')
                    raise RuntimeError('Empty string provided for API Key')
                if (resp.status_code == 403
                        and resp.text == 'permission denied'):
                    _logger.error(
                        'Permission denied, please confirm that the provided '
                        'API Key has corresponding permissions')
                    raise RuntimeError('Permission denied')
                elif resp.status_code == 404 and not resp.text:
                    raise RuntimeError('Incorrect URL')
                else:
                    http_error_msg = '%s Client Error: %s for URL %s' % (
                        resp.status_code, resp.reason, resp.url)
                    if resp.text:
                        http_error_msg = http_error_msg + ': ' + resp.text
            elif 500 <= resp.status_code < 600:
                if (resp.status_code == 500 and
                        resp.text.startswith('user root node does not exist')):
                    user = resp.text.split(':')[1][1:]
                    _logger.error('User %s does not exist', red(user))
                    raise RuntimeError("Non-existent user: '{}'".format(user))
                else:
                    http_error_msg = '%s Server Error: %s for URL %s' % (
                        resp.status_code, resp.reason, resp.url)
                    if resp.text:
                        http_error_msg = http_error_msg + ': ' + resp.text
            if http_error_msg:
                raise HTTPError(http_error_msg, response=resp)
        _logger.debug('Request succeeded')

        try:
            return resp.json()
        except simplejson.JSONDecodeError:
            return resp.text


CLIENT = _AssetHubClient()


def login(ah_host: Optional[str] = None,
          ais_host: Optional[str] = None,
          api_key: Optional[str] = None,
          timeout: Optional[int] = None) -> None:
    """Logs in to AIStore server and Asset Hub server.

    Sets up the client that corresponds with AIStore server and Asset Hub
    server.

    Args:
        ah_host:
            URL of Asset Hub server. Defaults to
            `t9k.CONFIG['asset_hub_host']`.
        ais_host:
            URL of AIStore server. Defaults to `t9k.CONFIG['aistore_host']`.
        api_key:
            API Key for requesting server. Defaults to
            `t9k.CONFIG['api_key']`.
        timeout:
            How many seconds to wait for server to send data before giving up.

    Raises:
        requests.HTTPError:
            Unable to connect to the server.
    """
    if ah_host:
        CLIENT.ah_host = ah_host
    elif CONFIG['asset_hub_host']:
        CLIENT.ah_host = CONFIG['asset_hub_host']
        ah_host = CONFIG['asset_hub_host']
    else:
        _logger.error(
            'Asset Hub host not provided by either argument or config')
        raise RuntimeError('Asset Hub host not provided')

    if ais_host:
        CLIENT.ais_host = ais_host
    elif CONFIG['aistore_host']:
        CLIENT.ais_host = CONFIG['aistore_host']
        ais_host = CONFIG['aistore_host']
    else:
        _logger.error('AIStore host not provided by either argument or config')
        raise RuntimeError('AIStore host not provided')

    if api_key:
        CLIENT.api_key = api_key
    elif CONFIG['api_key']:
        CLIENT.api_key = CONFIG['api_key']
        api_key = CONFIG['api_key']
    else:
        _logger.error('API Key not provided by either argument or config')
        raise RuntimeError('API Key not provided')

    check_url(CLIENT.ah_host)
    check_url(CLIENT.ais_host)
    if not is_uuid(CLIENT.api_key):
        _logger.error('Invalid API Key format')
        raise ValueError('Invalid API Key format')

    CLIENT.ah_host = CLIENT.ah_host.rstrip('/')
    CLIENT.ais_host = CLIENT.ais_host.rstrip('/')

    CLIENT.timeout = timeout

    CLIENT.test_ah_connection()
    CLIENT.test_ais_connection()

    CLIENT.online = True


def logout() -> None:
    """Logs out from the current AIStore server and Asset Hub server.

    The client is unset, it can no longer correspond with AIStore server and
    Asset Hub server until it is set up again.
    """
    if CLIENT.online:
        _logger.info(
            'Logged out from AIStore server %s and Asset Hub server %s',
            *magenta(CLIENT.ais_host, CLIENT.ah_host))
        CLIENT.online = False
    else:
        _logger.warning('Not log out, for having not logged in to any '
                        'AIStore server and Asset Hub server')


def _login_for_cli_cmd() -> None:
    """Logs in to Asset Hub server, for functions in `cli` module."""
    CLIENT.ah_host = CONFIG['asset_hub_host']
    CLIENT.ais_host = CONFIG['aistore_host']
    CLIENT.api_key = CONFIG['api_key']
    check_url(CLIENT.ah_host)
    check_url(CLIENT.ais_host)
    if not is_uuid(CLIENT.api_key):
        eprint('Invalid API Key format')
    CLIENT.test_ah_connection()
    CLIENT.test_ais_connection()
    CLIENT.online = True
    return


if __name__ == '__main__':
    pass
