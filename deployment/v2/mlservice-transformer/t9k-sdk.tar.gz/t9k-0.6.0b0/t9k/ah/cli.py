"""Implementation of CLI."""

from datetime import datetime
from functools import wraps
import json
import sys
from typing import Callable, Tuple

import click
from dateutil import parser
import tabulate

import t9k
from t9k.ah.apis import (list, create, delete, commit, download, update, merge,
                         reset)
from t9k.ah.client import _login_for_cli_cmd
from t9k.utils.datetime_utils import get_local_now_iso, format_timedelta
from t9k.utils.file_utils import human_readable_size
from t9k.utils.print_utils import eprint

CONTEXT_SETTINGS = dict(help_option_names=['--help'])

tabulate.PRESERVE_WHITESPACE = True


@click.group(context_settings=CONTEXT_SETTINGS)
@click.version_option(t9k.__version__)
@click.pass_context
def cli(ctx):
    del ctx  # Unused
    pass


def handle_cmd_exception(f: Callable) -> Callable:
    """Handles common exceptions for command functions."""

    @wraps(f)
    def wrapper(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except ValueError:
            eprint("Invalid argument: '{}'".format(kwargs['path']))
        except RuntimeError as e:
            if 'cannot be used as a prefix' in e.args[0]:
                eprint("Invalid argument: '{}'".format(kwargs['path']))
            elif 'Invalid path' in e.args[0]:
                eprint("Invalid argument: '{}'".format(kwargs['path']))
            else:
                eprint(e.args[0])

    return wrapper


def _tabulate_nodes(nodes_data, detail):
    if detail:
        headers = [
            'NAME', 'PATH', 'EDITOR', 'LABELS', 'DESCRIPTION', 'CREATED',
            'MODIFIED', 'PERMISSION'
        ]
    else:
        headers = ['NAME', 'PATH', 'LABELS', 'PERMISSION']

    table = []
    for node in nodes_data:
        name = node['name']
        path = node['path']
        labels = [l for l in node['labels'] if not l.startswith('assethub:')]
        labels = ', '.join(labels)
        permission = node['permission']

        row = []
        if detail:
            editor = node['editor']
            description = node['description']
            try:
                created_timestamp = json.loads(
                    node['extra'])['createdTimestamp']
                t_delta = datetime.fromisoformat(
                    get_local_now_iso()) - parser.isoparse(
                        created_timestamp.replace('Z', '+00:00'))
                created = format_timedelta(t_delta, brief=True) + ' ago'
            except (json.decoder.JSONDecodeError, KeyError):
                created = ''
            t_delta = datetime.fromisoformat(
                get_local_now_iso()) - parser.isoparse(
                    node['modifiedTimestamp'].replace('Z', '+00:00'))
            modified = format_timedelta(t_delta, brief=True) + ' ago'
            row.extend([
                name, path, editor, labels, description, created, modified,
                permission
            ])
        else:
            row.extend([name, path, labels, permission])
        table.append(row)

    click.echo(
        tabulate.tabulate(table, headers, tablefmt='plain', numalign='left'))


@click.argument('path', nargs=1)
@click.option('-d',
              '--detail',
              is_flag=True,
              default=False,
              help='Show detailed information about the resources.')
@click.option('-h',
              '--human-readable',
              is_flag=True,
              default=False,
              help='Print sizes in human readable format.')
@click.option('-b',
              '--branch',
              'list_branch',
              is_flag=True,
              default=False,
              help=('List branches instead of objects. Only applicable when '
                    '\033[1mPATH\033[0m points to an Asset.'))
@click.option('-t',
              '--tag',
              'list_tag',
              is_flag=True,
              default=False,
              help=('List tags instead of objects. Only applicable when '
                    '\033[1mPATH\033[0m points to an Asset.'))
@click.option('-c',
              '--commit',
              'list_commit',
              is_flag=True,
              default=False,
              help=('List commits instead of objects. Only applicable when '
                    '\033[1mPATH\033[0m points to a branch of Asset.'))
@cli.command('ls', context_settings=CONTEXT_SETTINGS)
@handle_cmd_exception
def ls(path: str, detail: bool, human_readable: bool, list_branch: bool,
       list_tag: bool, list_commit: bool):
    """List resources.

    Based on the provided \033[1mPATH\033[0m, list Folders with the specified
    Asset kind and scope, Assets within the specified Folder, or all objects of
    the specified reference (branch, tag or commit) of Asset.

    To list Folders that are shared with you, use path \033[1mshared/model\033[0m
    (or \033[1mshared/dataset\033[0m); to list Folders that are public, use path
    \033[1m/public/t9k-assethub/model\033[0m (or \033[1m/public/t9k-assethub/dataset\033[0m).

    To list branches, tags or commits of the specified Asset, additional
    option \033[1m--branch\033[0m, \033[1m--tag\033[0m or \033[1m--commit\033[0m
    need to be provided respectively.

    If a reference is expected but omitted, \033[1m:main\033[0m
    will be used.

    \b
    Examples:
        \b
        # List Model Folders that you own:
        ah ls model
        \b
        # List Model Folders that are shared with you:
        ah ls shared/model
        \b
        # List Model Folders that are public:
        ah ls /public/t9k-assethub/model
        \b
        # List Models in your own Folder:
        ah ls model/llm
        \b
        # List Models in another user's Folder:
        ah ls /user1/t9k-assethub/model/llm
        \b
        # List objects of the specified branch of Model:
        ah ls model/llm/gpt2:v1
        \b
        # List objects of the specified tag of Dataset:
        ah ls dataset/images/cifar10:20220101
        \b
        # List branches of the specified Model:
        ah ls model/llm/gpt2 --branch
        \b
        # List tags of the specified Model:
        ah ls model/llm/gpt2 --tag
        \b
        # List commits of the specified branch of Model:
        ah ls model/llm/gpt2:v1 --commit
        \b
        # List commits of the specified Dataset:
        ah ls dataset/images/cifar10 --commit
    """
    _login_for_cli_cmd()

    resource = 'default'
    if list_branch:
        resource = 'branch'
    elif list_tag:
        resource = 'tag'
    elif list_commit:
        resource = 'commit'

    data = list(path=path, resource=resource)

    if not data:
        sys.exit(0)

    if resource == 'branch':
        headers = ['NAME', 'COMMIT_ID']
        table = []
        for b in data:
            name = b['id']
            commit_id = b['commit_id'][:8]
            table.append([name, commit_id])

        click.echo(tabulate.tabulate(table, headers, tablefmt='plain'))

    elif resource == 'tag':
        headers = ['NAME', 'COMMIT_ID']
        table = []
        for t in data:
            name = t['id']
            commit_id = t['commit_id'][:8]
            table.append([name, commit_id])

        click.echo(tabulate.tabulate(table, headers, tablefmt='plain'))

    elif resource == 'commit':
        headers = ['COMMIT_ID', 'MESSAGE', 'CREATED']
        table = []
        for c in data:
            commit_id = c['id'][:8]
            msg = c['message']
            t_delta = datetime.fromisoformat(
                get_local_now_iso()) - datetime.fromtimestamp(
                    c['creation_date']).astimezone()
            created = format_timedelta(t_delta, brief=True) + ' ago'
            table.append([commit_id, msg, created])

        click.echo(
            tabulate.tabulate(table,
                              headers,
                              tablefmt='plain',
                              numalign='left'))

    else:
        if 'type' in data[0]:
            if data[0]['type'] == 'Folder':
                _tabulate_nodes(data, detail)
            else:  # Asset
                _tabulate_nodes(data, detail)

        else:  # object
            headers = ['PATH', 'BYTES', 'MODIFIED']
            table = []
            for obj in data:
                path = obj['path']
                if human_readable:
                    size = human_readable_size(obj['size_bytes'])
                else:
                    size = str(obj['size_bytes']) + 'B'
                t_delta = datetime.fromisoformat(
                    get_local_now_iso()) - datetime.fromtimestamp(
                        obj['mtime']).astimezone()
                created = format_timedelta(t_delta, brief=True) + ' ago'
                table.append([path, size, created])

            if table:
                click.echo(
                    tabulate.tabulate(table,
                                      headers,
                                      tablefmt='plain',
                                      colalign=['left', 'right', 'left']))
            else:
                click.echo(tabulate.tabulate(table, headers, tablefmt='plain'))


@click.argument('path', nargs=1)
@click.option('-l',
              '--label',
              'labels',
              type=str,
              metavar='LABEL',
              multiple=True,
              help=('Labels of the resource. Only applicable for creating a '
                    'Folder, Model or Dataset.'))
@click.option('-d',
              '--description',
              type=str,
              help=('Description of the resource. Only applicable for '
                    'creating a Folder, Model or Dataset.'))
@click.option(
    '-t',
    '--tag',
    'create_tag',
    is_flag=True,
    default=False,
    help=('Create a tag instead of a branch. Only applicable for creating '
          'a branch or tag.'))
@click.option(
    '-s',
    '--source',
    type=str,
    default='main',
    help=('Name/ID or path of the source reference (branch, tag or commit)'
          'from which a tag is created. Only applicable for creating a tag.'))
@cli.command('create', context_settings=CONTEXT_SETTINGS)
@handle_cmd_exception
def cli_create(path: str, labels: Tuple[str, ...], description: str,
               create_tag: bool, source: str):
    """Create a resource.

    \b
    Examples:
        \b
        # Create a Folder:
        ah create model/llm
        \b
        # Create a Model with labels:
        ah create model/llm/gpt2 --label "PyTorch"
        \b
        # Create a Dataset with description:
        ah create dataset/images/cifar10 --description "CIFAR-10 is a widely used benchmark dataset ..."
        \b
        # Create a branch of the specified Model:
        ah create model/llm/gpt2:v1
        \b
        # Create a tag from the specified branch of Model:
        ah create model/llm/gpt2:20220101 --tag --source [model/llm/gpt2:]v1
    """
    _login_for_cli_cmd()

    create(path=path,
           labels=labels,
           description=description,
           create_tag=create_tag,
           source=source)


@click.argument('path', nargs=1)
@click.option('-f',
              '--force',
              is_flag=True,
              default=False,
              help='Ignore non-existent resources.')
@cli.command('delete', context_settings=CONTEXT_SETTINGS)
@handle_cmd_exception
def cli_delete(path: str, force: bool):
    """Delete a resource.

    \b
    Examples:
        \b
        # Delete a Folder:
        ah delete model/llm
        \b
        # Delete a Model:
        ah delete model/llm/gpt2
        \b
        # Delete a Dataset:
        ah delete dataset/images/cifar10
        \b
        # Delete a non-main branch of the specified Model:
        ah delete model/llm/gpt2:v1
        \b
        # Delete a tag:
        ah delete model/llm/gpt2:20220101
        \b
        # Delete another user's Folder:
        ah delete /user1/t9k-assethub/model/llm
        \b
        # If the Folder does not exist, exit with code 0:
        ah delete model/llm --force
    """
    _login_for_cli_cmd()

    delete(path=path, force=force)


@click.argument('path', nargs=1)
@click.option('-m',
              '--message',
              type=str,
              metavar='MESSAGE',
              help='Commit message.')
@click.option('-d',
              '--delete',
              'deletes',
              type=str,
              metavar='PATH',
              multiple=True,
              help='Files or directories to delete from the branch.')
@click.option('-a',
              '--add',
              'adds',
              type=str,
              metavar='LOCAL_PATH[:PATH]',
              multiple=True,
              help='Files or directories to add to the branch.')
@click.option('-f',
              '--force',
              is_flag=True,
              default=False,
              help='Create a new commit if unknown changes or '
              'unimplemented changes are found.')
@cli.command('commit', context_settings=CONTEXT_SETTINGS)
@handle_cmd_exception
def cli_commit(path: str, message: str, deletes: Tuple[str, ...],
               adds: Tuple[str, ...], force: bool):
    """Commit changes to a branch of an Asset.

    First delete, then add.

    If no branch is provided, \033[1m:main\033[0m will be used.

    For Windows platform, if you use \033[1m--add LOCAL_PATH[:PATH]\033[0m and
    \033[1mLOCAL_PATH\033[0m is an absolute path, change its format from
    \033[1mC:\\local\\path\033[0m to \033[1m\\C\\local\\path\033[0m.

    \b
    Examples:
        \b
        # Add a file as object to specified branch of Model:
        ah commit model/llm/gpt2:v1 --message "add ..." --add model.pt
        \b
        # Specify a path in Asset for a file to add:
        ah commit model/llm/gpt2:v1 --message "add ..." --add /path/to/model.pt:saved_model/[model.pt]
        \b
        # Add all files under a directory as objects (with the directory):
        ah commit model/llm/gpt2:v1 --message "add ..." --add ./saved_model
        \b
        # Add all files under a directory as objects (without the directory):
        ah commit model/llm/gpt2:v1 --message "add ..." --add "./saved_model/*"
        \b
        # Specify a path in Asset for a directory to add:
        ah commit model/llm/gpt2:v1 --message "add ..." --add ./saved_model:path/to/[saved_model]
        # or
        ah commit model/llm/gpt2:v1 --message "add ..." --add ./saved_model:path/to/renamed_dir
        \b
        # Delete an object from a Dataset:
        ah commit dataset/images/cifar10 --message "delete ..." --delete 0.png
        \b
        # Delete all objects under the specified path:
        ah commit dataset/images/cifar10 --message "delete ..." --delete data/

    \b
    Examples for Windows:
        \b
        # Specify path in Model for an object to add:
        ah commit model/llm/gpt2:v1 --message "add ..." --add \\C\\path\\to\\model.pt:saved_model/[model.pt]
        \b
        # Add all files under a directory as objects:
        ah commit model/llm/gpt2:v1 --message "add ..." --add .\\saved_model
    """
    _login_for_cli_cmd()

    commit(path=path, msg=message, delete=deletes, add=adds, force=force)


@click.argument('path', nargs=1)
@click.option('-o',
              '--object',
              'objects',
              type=str,
              metavar='PATH',
              multiple=True,
              help='Objects to download.')
@click.option('-s',
              '--save-dir',
              type=click.Path(),
              metavar='SAVE_DIR',
              default='.',
              help='Local directory which objects are downloaded to.')
@cli.command('download', context_settings=CONTEXT_SETTINGS)
def cli_download(path: str, objects: Tuple[str, ...], save_dir: str):
    """Download objects of a reference of an Asset.

    If no reference is provided, \033[1m:main\033[0m will be used.

    \b
    Examples:
        \b
        # Download all objects of the specified branch of Model to current working directory:
        ah download model/llm/gpt2:v1
        \b
        # Download an object to specified directory:
        ah download model/llm/gpt2:v1 --object model.pt --save-dir ./saved_model
        \b
        # Download all objects under the same path:
        ah download model/llm/gpt2:v1 --object saved_model/
        \b
        # Specify the reference by tag:
        ah download dataset/images/cifar10:20220101
        \b
        # Specify the reference by commit:
        ah download dataset/images/cifar10:a41ac4ec
    """
    _login_for_cli_cmd()

    download(path=path, objects=objects, save_dir=save_dir)


@click.argument('path', nargs=1)
@click.option('-n', '--name', type=str, help='New name of the Folder.')
@click.option('-l',
              '--label',
              'labels',
              type=str,
              metavar='LABEL',
              multiple=True,
              help='New labels of the Folder.')
@click.option('-d',
              '--description',
              type=str,
              help='New description of the Folder.')
@cli.command('update', context_settings=CONTEXT_SETTINGS)
@handle_cmd_exception
def cli_update(path: str, name: str, labels: Tuple[str, ...],
               description: str):
    """Update a resource.

    \b
    Examples:
        \b
        # Rename a Folder:
        ah update model/llm --name generative-language-model
        \b
        # Relabel a Model:
        ah update model/llm/gpt2 --label "JAX"
    """
    _login_for_cli_cmd()

    update(path=path, name=name, labels=labels, description=description)


@click.argument('path', nargs=1)
@cli.command('merge', context_settings=CONTEXT_SETTINGS)
@handle_cmd_exception
def cli_merge(path: str):
    """Merge a branch of a Model to the main branch.

    Here, the specific operation of "merge" involves deleting all objects from
    the main branch and then copying all objects from the specified branch to
    the main branch.

    \b
    Examples:
        \b
        ah merge model/llm/gpt2:v1
    """
    _login_for_cli_cmd()

    merge(path=path)


@click.argument('path', nargs=1)
@cli.command('reset', context_settings=CONTEXT_SETTINGS)
@handle_cmd_exception
def cli_reset(path: str):
    """Reset a branch to clear all uncommitted changes.

    \b
    Examples:
        \b
        ah reset model/llm/gpt2:main
    """
    _login_for_cli_cmd()

    reset(path=path)
