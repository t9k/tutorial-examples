"""Main APIs."""

from enum import Enum, auto
import json
import logging
import re
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple, Union

from t9k.ah.client import CLIENT
from t9k.ah.core import Folder, Model, Dataset, Branch, Tag, Commit, _labels_to_list
from t9k.utils.datetime_utils import get_utc_now_iso
from t9k.utils.print_utils import cyan, red, yellow

_logger = logging.getLogger(__name__)

_folders = {}


def _online_only(func):
    def wrapper(*args, offline_ok=False, **kwargs):
        if CLIENT.online:
            return func(*args, **kwargs)
        elif offline_ok:
            return
        else:
            _logger.error('Cannot correspond with Asset Hub server and '
                          'AIStore server for not logging in, please '
                          'first call `ah.login()`')
            raise RuntimeError('Cannot correspond with Asset Hub server '
                               'and AIStore server for not logging in, '
                               'please first call `ah.login()`')

    return wrapper


@_online_only
def list(path: str, resource: str = 'default') -> List[Dict[str, Any]]:
    """Lists resources.

    Based on the provided `path`, list Folders with the specified Asset kind,
    Assets within the specified Folder, or all objects of the specified
    reference (branch, tag or commit) of Asset.

    To list Folders that are shared with you, set `path='shared/model'`
    (or `path='shared/dataset'`); to list Folders that are public, set
    `path='/public/t9k-assethub/model'` (or
    `path='/public/t9k-assethub/dataset'`).

    To list branches, provide a `path` that points to an Asset and set
    `resource='branch'`; to list tags, provide a `path` that points to an Asset
    and set `resource='tag'`; to list commits, provide a `path` that points to
    a branch of an Asset and set `resource='commit'`.

    If a reference is expected but omitted, `:main` will be used.

    Examples:
        List Model Folders that you own:
        ```
        folders = ah.list('model')
        ```

        List Model Folders that are shared with you:
        ```
        folders = ah.list('shared/model')
        ```

        List Model Folders that are public:
        ```
        folders = ah.list('/public/t9k-assethub/model')
        ```

        List Models in your own Folder:
        ```
        models = ah.list('model/llm')
        ```

        List Models in another user's Folder:
        ```
        models = ah.list('/user1/t9k-assethub/model/llm')
        ```

        List objects of specified branch of Model:
        ```
        objects = ah.list('model/llm/gpt2:v1')
        ```

        List objects of specified tag of Dataset:
        ```
        objects = ah.list('dataset/images/cifar10:20220101')
        ```

        List branches of specified Model:
        ```
        branches = ah.list('model/llm/gpt2', resource='branch')
        ```

        List tags of specified Model:
        ```
        tags = ah.list('model/llm/gpt2', resource='tag')
        ```

        List commits of specified branch of Model:
        ```
        commits = ah.list('model/llm/gpt2:v1', resource='commit')
        ```

        List commits of specified Dataset:
        ```
        commits = ah.list('dataset/images/cifar10', resource='commit')
        ```

    Args:
        path:
            Path to be listed.
        resource:
            Kind of the resources, must be `'default'`, `'branch'`, '`tag`' or
            `'commit'`. This parameter is used to list branches, tags or
            commits: to list branches, provide a `path` that points to an Asset
            and set `resource='branch'`; to list tags, provide a `path` that
            points to an Asset and set `resource='tag'`; to list commits,
            provide a `path` that points to a branch of an Asset and set
            `resource='commit'`.

    Returns:
        A list of resources.
    """
    path, kind, scope = _resolve_path(path=path)

    if kind == Kind.FOLDER_PARENT:  # list Folder
        parts = path.split(sep='/')

        # check user name
        user_name = parts[1]
        if user_name not in [CLIENT.user_name, 'public']:
            _logger.error('Cannot list Folders of another user: %s',
                          red(user_name))
            raise RuntimeError(
                "Cannot list Folders of another user: '{}'".format(user_name))

        asset_kind = parts[-1].capitalize()
        folders = CLIENT.list_folder(asset_kind=asset_kind, scope=scope)
        for f in folders:
            if 'assethub:model' in f['labels']:
                f['labels'].remove('assethub:model')
            else:
                f['labels'].remove('assethub:dataset')
        return folders

    elif kind == Kind.FOLDER:  # list Asset
        folder = _get_folder(path=path)
        return folder.list_asset()

    elif kind == Kind.ASSET:
        asset = _get_asset(path=path)
        if resource == 'branch':
            return asset.list_branch()
        elif resource == 'tag':
            return asset.list_tag()
        elif resource == 'commit':
            if asset.kind == 'Model':
                return asset.get_branch(name='main').list_commit()
            else:
                return asset.list_commit()
        else:  # object
            return asset.list_object()

    else:  # Kind.REFERENCE
        if resource in ['branch', 'tag']:
            _logger.error('Cannot list branches or tags for a reference')
            raise RuntimeError('Cannot list branches or tags for reference')

        ref = _get_branch_tag_commit(path=path)
        if resource == 'commit':
            return ref.list_commit()
        else:  # object
            return ref.list_object()


@_online_only
def create(path: str,
           labels: Optional[Sequence[str]] = None,
           description: str = '',
           exist_ok: bool = False,
           create_tag: bool = False,
           source: str = 'main') -> Union[Folder, Model, Dataset, Branch, Tag]:
    """Creates a resource.

    Note that you cannot create a Folder for another user.

    Examples:
        Create a Folder:
        ```
        folder = ah.create('model/llm')
        ```

        Create a Model with labels:
        ```
        model = ah.create('model/llm/gpt2', labels=['PyTorch'])
        ```

        Create a Dataset with a description:
        ```
        description = 'CIFAR-10 is a widely used benchmark dataset ...'
        dataset = ah.create('dataset/images/cifar10', description=description)
        ```

        Create a non-main branch of specified Model:
        ```
        branch = ah.create('model/llm/gpt2:v1')
        ```

        Create a tag:
        ```
        tag = ah.create('model/llm/gpt2:20220101', create_tag=True, source='v1')
        # or
        tag = ah.create('model/llm/gpt2:20220101', create_tag=True, source='model/llm/gpt2:v1')
        ```

        Create a Model for another user:
        ```
        model = ah.create('/user/t9k-assethub/model/llm/gpt2')
        ```

    Args:
        path:
            Path of the resource.
        labels:
            Labels of the resource. Only applicable for creating a Folder,
            Model or Dataset.
        description:
            Description of the resource. Only applicable for creating a Folder,
            Model or Dataset.
        exist_ok:
            If True and the resource already exists, return a corresponding
            instance representing the resource; if False and resource exists,
            raise a `RuntimeError`. Only applicable for creating a Folder,
            Model or Dataset.
        create_tag:
            Whether to create a tag instead of a branch. Only applicable for
            creating a branch or tag.
        source:
            Name/ID or path of the source reference (branch, tag or commit)
            from which a tag is created. Only applicable for creating a tag.

    Returns:
        A corresponding instance representing retrieved resource.
    """
    path, kind, _ = _resolve_path(path=path)
    labels = _labels_to_list(labels)

    if kind == Kind.FOLDER:
        return _create_folder(path=path,
                              labels=labels,
                              description=description,
                              exist_ok=exist_ok)

    elif kind == Kind.ASSET:
        folder_path, asset_name = path.rsplit(sep='/', maxsplit=1)
        folder = _create_folder(path=folder_path, exist_ok=True)
        return folder.create_asset(name=asset_name,
                                   labels=labels,
                                   description=description,
                                   exist_ok=exist_ok)

    elif kind == Kind.REFERENCE:
        asset_path, name = path.split(':')
        asset = _get_asset(path=asset_path)
        if create_tag:  # tag
            if ':' in source:
                asset_path_, source = source.split(sep=':')
                if asset_path != asset_path_:
                    _logger.error('Asset paths do not match: %s and %s',
                                  *red(asset_path, asset_path_))
                    raise ValueError(
                        "Asset paths do not match: '{}' and '{}'".format(
                            asset_path, asset_path_))
            source_path = ':'.join([asset_path, source])
            ref = _get_branch_tag_commit(path=source_path)
            return ref.create_tag(name=name)
        else:  # branch
            if asset.kind == 'dataset':
                _logger.error('Cannot create branch for a Dataset')
                raise RuntimeError('Cannot create branch for a Dataset')
            return asset.create_branch(name=name)

    else:  # Kind.FOLDER_PARENT
        _logger.error('Invalid path for creating: %s', red(path))
        raise RuntimeError("Invalid path for creating: '{}'".format(path))


@_online_only
def _create_folder(path: str,
                   labels: Optional[Sequence[str]] = None,
                   description: str = '',
                   exist_ok: bool = False) -> Folder:
    """Creates a Folder.

    Args:
        path:
            Path of the Folder.
        labels:
            Labels of the Folder.
        description:
            Description of the Folder.
        exist_ok:
            If True and the Folder already exists, return a `Folder` instance
            representing this Folder; if False and Folder exists, raise a
            `RuntimeError`.

    Returns:
        A `Folder` instance representing the created Folder.
    """
    _, _, _, asset_kind, name = path.split(sep='/')
    asset_kind = asset_kind.capitalize()
    labels = _labels_to_list(labels)

    try:
        extra = json.dumps({'createdTimestamp': get_utc_now_iso()})
        id_ = CLIENT.create_folder(folder_path=path,
                                   labels=labels,
                                   description=description,
                                   extra=extra)
        _logger.info('Folder %s created', cyan(path))
    except RuntimeError as e:
        msg = e.args[0]
        if 'already exists' in msg:
            if exist_ok:
                _logger.info('Folder %s already exists and is reused',
                             cyan(path))
                return _get_folder(path=path)
            else:
                _logger.error('Folder %s already exists', red(path))
                raise e
        else:
            raise e

    folder = Folder(path=path,
                    id_=id_,
                    owner=CLIENT.user_name,
                    asset_kind=asset_kind,
                    name=name,
                    labels=labels,
                    description=description,
                    extra=extra)
    _folders[path] = folder
    return folder


@_online_only
def get(path: str) -> Union[Folder, Model, Dataset, Branch, Tag, Commit]:
    """Gets a resource.

    To get a commit, please provide a commit ID with a length of at least 4
    to avoid potential conflicts with branches or tags.

    Examples:
        Get a Folder:
        ```
        folder = ah.get('model/llm')
        ```

        Get a Model:
        ```
        model = ah.get('model/llm/gpt2')
        ```

        Get a Dataset:
        ```
        dataset = ah.get('dataset/images/cifar10')
        ```

        Get a non-main branch of specified Model:
        ```
        branch = ah.get('model/llm/gpt2:v1')
        ```

        Get a tag:
        ```
        tag = ah.get('model/llm/gpt2:20220101')
        ```

        Get another user's Folder:
        ```
        folder = ah.get('/user/t9k-assethub/model/llm')
        ```

    Args:
        path: Path of the resource.

    Returns:
        A instance representing retrieved resource.
    """
    path, kind, _ = _resolve_path(path=path)

    if kind == Kind.FOLDER:
        return _get_folder(path=path)
    elif kind == Kind.ASSET:
        return _get_asset(path=path)
    elif kind == Kind.REFERENCE:
        return _get_branch_tag_commit(path=path)
    else:  # Kind.FOLDER_PARENT
        _logger.error('Invalid path for getting: %s', red(path))
        raise RuntimeError("Invalid path for getting: '{}'".format(path))


@_online_only
def _get_folder(path: str) -> Folder:
    """Gets a Folder by path.

    Args:
        path: Path of the Folder.

    Returns:
        A `Folder` instance representing retrieved Folder.
    """
    _, owner, _, asset_kind, _ = path.split(sep='/')
    asset_kind = asset_kind.capitalize()

    # cache
    if path in _folders:
        return _folders[path]

    folder_data = CLIENT.get_folder_data(folder_path=path)
    id_ = folder_data['id']
    name = folder_data['name']
    labels = folder_data['labels']
    description = folder_data['description']
    extra = folder_data['extra']
    folder = Folder(path=path,
                    id_=id_,
                    owner=owner,
                    asset_kind=asset_kind,
                    name=name,
                    labels=labels,
                    description=description,
                    extra=extra)
    _folders[path] = folder
    return folder


@_online_only
def _get_asset(path: str) -> Union[Model, Dataset]:
    """Gets an Asset by path.

    Args:
        path: Path of the Asset.

    Returns:
        A `Model` or `Dataset` instance representing retrieved Model or
        Dataset.
    """
    folder_path, name = path.rsplit(sep='/', maxsplit=1)
    return _get_folder(path=folder_path).get_asset(name=name)


@_online_only
def _get_branch_tag_commit(
        path: str,
        get_commit: bool = True,
        warning: bool = False) -> Union[Branch, Tag, Commit]:
    """Gets a branch, tag or commit by path.

    Args:
        path: Path of the branch, tag or commit.
        get_commit: If False, do not get a commit.
        warning: Whether to log warning instead of error.

    Returns:
        A `Branch`, `Tag` or `Commit` instance representing retrieved branch,
        tag or commit.
    """
    asset_path, name = path.split(sep=':')
    asset = _get_asset(path=asset_path)

    if asset.kind == 'Model':
        try:
            return asset.get_branch(name=name, verbose=False)
        except RuntimeError:
            pass
    else:
        if name == 'main':
            return asset._branch

    try:
        return asset.get_tag(name=name, verbose=False)
    except RuntimeError:
        pass

    if get_commit:
        try:
            return asset.get_commit(id=name)
        except RuntimeError:
            pass

        if warning:
            _logger.warning('No such branch, tag or commit: %s', yellow(path))
        else:
            _logger.error('No such branch, tag or commit: %s', red(path))
        raise RuntimeError("No such branch, tag or commit: '{}'".format(path))

    if warning:
        _logger.warning('No such branch or tag: %s', yellow(path))
    else:
        _logger.error('No such branch or tag: %s', red(path))
    raise RuntimeError("No such branch or tag: '{}'".format(path))


@_online_only
def delete(path: str, force: bool = False) -> None:
    """Deletes a resource.

    Examples:
        Delete a Folder:
        ```
        ah.delete('model/llm')
        ```

        Delete a Model:
        ```
        ah.delete('model/llm/gpt2')
        ```

        Delete a Dataset:
        ```
        ah.delete('dataset/images/cifar10')
        ```

        Delete a non-main branch of specified Model:
        ```
        ah.delete('model/llm/gpt2:v1')
        ```

        Delete a tag:
        ```
        ah.delete('model/llm/gpt2:20220101')
        ```

        Delete another user's Folder:
        ```
        ah.delete('/user/t9k-assethub/model/llm')
        ```

        If the Folder does not exist, do nothing:
        ```
        ah.delete('model/llm', force=True)
        ```

    Args:
        path: Path of the resource.
        force: If True, ignore non-existent resources.
    """
    path, kind, _ = _resolve_path(path=path)

    try:
        if kind == Kind.FOLDER:
            _get_folder(path=path).delete()
        elif kind == Kind.ASSET:
            _get_asset(path=path).delete()
        elif kind == Kind.REFERENCE:
            _get_branch_tag_commit(path=path, get_commit=False,
                                   warning=force).delete()
        else:  # Kind.FOLDER_PARENT
            _logger.error('Invalid path for deleting: %s', red(path))
            raise RuntimeError("Invalid path for deleting: '{}'".format(path))

    except RuntimeError as e:
        if not force:
            raise e


@_online_only
def commit(path: str,
           msg: str,
           delete: Optional[Sequence[str]] = None,
           add: Union[Sequence[str], Mapping[str, str], None] = None,
           force: bool = False) -> Optional['Commit']:
    """Commits changes to a branch of an Asset.

    First delete, then add.

    If no branch is provided, `:main` will be used.

    For Windows platform, if you provide absolute paths for parameter `add`,
    change its format from 'C:\\local\\path' to '\\C\\local\\path'.

    Examples:
        Add a file as object to specified branch of Model:
        ```
        ah.commit('model/llm/gpt2:v1', msg='add ...', add=['model.pt'])
        ```

        Specify a path in Asset for a file to add:
        ```
        ah.commit('model/llm/gpt2:v1', msg='add ...', add={'model.pt': 'saved_model/'})
        ```

        Add all files under a directory as objects (with the directory):
        ```
        ah.commit('model/llm/gpt2:v1', msg='add ...', add=['./saved_model'])
        ```

        Add all files under a directory as objects (without the directory):
        ```
        ah.commit('model/llm/gpt2:v1', msg='add ...', add=['./saved_model/*'])
        ```

        Specify a path in Asset for a directory to add:
        ```
        ah.commit('model/llm/gpt2:v1', msg='add ...', add={'./saved_model': 'path/to/[saved_model]'})
        # or
        ah.commit('model/llm/gpt2:v1', msg='add ...', add={'./saved_model': 'path/to/renamed_dir'})
        ```

        Delete an object from a Dataset:
        ```
        ah.commit('dataset/images/cifar10', msg='delete ...', delete=['0.png'])
        ```

        Delete all objects under the specified path:
        ```
        ah.commit('dataset/images/cifar10', msg='delete ...', delete=['data/'])
        ```

    Args:
        path:
            Path of the branch.
        msg:
            Commit message.
        delete:
            Files or directories to delete from the branch, can be a
            sequence of paths in branch or `None`. If empty sequence or
            `None`, delete nothing. If the files or directories to delete
            do not exist, do nothing (rather than raise an error). Here
            format `a/.../b` signifies a file, while `a/.../b/` signifies a
            directory.
        add:
            Files or directories to add to the branch, can be a sequence
            of local paths, a mapping from local paths to their paths in
            Asset, or `None`. If empty sequence, empty mapping or `None`,
            add nothing.
        force:
            Whether to create a new commit if unknown changes or
            unimplemented changes are found.

    Returns:
        A `Commit` instance representing created commit if changes are
        commited, `None` if not.
    """
    path, kind, _ = _resolve_path(path=path)

    if kind in [Kind.FOLDER, Kind.FOLDER_PARENT]:
        _logger.error('Invalid path for committing: %s', red(path))
        raise RuntimeError("Invalid path for committing: '{}'".format(path))

    if kind == Kind.ASSET:
        path = path + ':main'

    # Kind.REFERENCE
    branch = _get_branch_tag_commit(path=path)
    if branch.kind != 'branch':
        _logger.error('Cannot commit changes to a %s', branch.kind)
        raise RuntimeError('Cannot commit changes to a {}'.format(branch.kind))

    add_list = []
    add_dict = {}
    for i in add:
        if ':' in i:
            local_path, path = i.split(':')
            add_dict[local_path] = path
        else:
            add_list.append(i)
    if add_dict:
        for local_path in add_list:
            add_dict[local_path] = None
        return branch.create_commit(msg=msg,
                                    delete=delete,
                                    add=add_dict,
                                    force=force)
    else:
        return branch.create_commit(msg=msg,
                                    delete=delete,
                                    add=add_list,
                                    force=force)


@_online_only
def download(path: str,
             objects: Optional[Sequence[str]] = None,
             save_dir: str = '.') -> None:
    """Download objects of a reference of an Asset.

    If no reference is provided, `:main` will be used.

    Examples:
        Download all objects of specified branch of Model to current working directory:
        ```
        ah.download('model/llm/gpt2:v1')
        ```

        Download an object to specified directory:
        ```
        ah.download('model/llm/gpt2:v1', objects=['model.pt'], save_dir='./saved_model')
        ```

        Download all objects under the same path:
        ```
        ah.download('model/llm/gpt2:v1', objects=['saved_model/'])
        ```

        Specify the reference by tag:
        ```
        ah.download('dataset/images/cifar10:20220101')
        ```

        Specify the reference by commit:
        ```
        ah.download('dataset/images/cifar10:a41ac4ec')
        ```

    Args:
        path:
            Path of the reference from which objects are downloaded.
        objects:
            Objects to download.
        save_dir:
            Local directory which objects are downloaded to.
    """
    path, kind, _ = _resolve_path(path=path)

    if kind in [Kind.FOLDER, Kind.FOLDER_PARENT]:
        _logger.error('Invalid path for downloading: %s', red(path))
        raise RuntimeError("Invalid path for downloading: '{}'".format(path))

    if kind == Kind.ASSET:
        path = path + ':main'

    # Kind.REFERENCE
    ref = _get_branch_tag_commit(path=path)
    if not objects:
        objects = ['/']
    ref.download(paths=objects, save_dir=save_dir)


@_online_only
def update(path: str,
           name: Optional[str] = None,
           labels: Optional[Sequence[str]] = None,
           description: Optional[str] = None) -> None:
    """Updates a resource.

    Only Folders and Assets can be updated.

    If none of the args is provided, do nothing.

    Examples:
        Rename a Folder:
        ```
        ah.update('model/llm', name='generative-language-model')
        ```

        Relabel a Model:
        ```
        ah.update('model/llm/gpt2', labels=['JAX'])
        ```

    Args:
        name:
            New name of the resource.
        labels:
            New labels of the resource.
        description:
            New description of the resource.
    """
    path, kind, _ = _resolve_path(path=path)

    if kind == Kind.FOLDER:
        _get_folder(path=path).update(name=name,
                                      labels=labels,
                                      description=description)
    elif kind == Kind.ASSET:
        _get_asset(path=path).update(name=name,
                                     labels=labels,
                                     description=description)
    elif kind == Kind.REFERENCE:
        _logger.error('Cannot update a reference')
        raise RuntimeError('Cannot update a reference')
    else:  # Kind.FOLDER_PARENT
        _logger.error('Invalid path for updating: %s', red(path))
        raise RuntimeError("Invalid path for updating: '{}'".format(path))


@_online_only
def merge(path: str) -> None:
    """Merges a branch of a Model to the main branch.

    Here, the specific operation of "merge" involves deleting all objects from
    the main branch and then copying all objects from the specified branch to
    the main branch.

    Note that the specified branch itself cannot be the main branch.

    Examples:
        ```
        ah.merge('model/llm/gpt2:v1')
        ```

    Args:
        path: Path of the branch.
    """
    path, kind, _ = _resolve_path(path=path)

    cannot_merge = False

    if kind == Kind.REFERENCE:
        branch = _get_branch_tag_commit(path=path)
        if branch.kind == 'branch':
            branch.merge()
        else:
            cannot_merge = True
    else:
        cannot_merge = True

    if cannot_merge:
        _logger.error('Only branches can be merged')
        raise RuntimeError('Only branches can be merged')


@_online_only
def reset(path: str) -> None:
    """Resets a branch to clear all uncommitted changes.

    Examples:
        ```
        ah.reset('model/llm/gpt2:main')
        ```

    Args:
        path: Path of the branch.
    """
    path, kind, _ = _resolve_path(path=path)

    cannot_reset = False

    if kind == Kind.REFERENCE:
        branch = _get_branch_tag_commit(path=path)
        if branch.kind == 'branch':
            branch.reset()
        else:
            cannot_reset = True
    else:
        cannot_reset = True

    if cannot_reset:
        _logger.error('Only branches can be reset')
        raise RuntimeError('Only branches can be reset')


class Kind(Enum):
    FOLDER_PARENT = auto()
    FOLDER = auto()
    ASSET = auto()  # no need to be identified further
    REFERENCE = auto()  # cannot be identified further


def _resolve_path(path: str) -> Tuple[str, int]:
    """Resolves a path and returns full path, kind and scope."""
    if not path.startswith('/'):
        path = '/{}/t9k-assethub/{}'.format(CLIENT.user_name, path)
    path = path.rstrip('/')

    def invalid_path() -> None:
        _logger.error('Invalid path of resource: %s', red(path))
        raise ValueError("Invalid path of resource: '{}'".format(path))

    name = r'[A-Za-z0-9]+([A-Za-z0-9_-]*[A-Za-z0-9]+)?'
    asset = r'(model|dataset)'

    if m := re.match(rf'/{name}/t9k-assethub/shared/{asset}', path):
        # check user name later
        if len(path) > m.end():
            lib = path[:m.end()]
            asset_kind = lib.split(sep='/')[-1]
            _logger.error(
                '%s cannot be used as a prefix for the path, as there may be '
                'shared Folders with the same name, please use the original '
                "path of the Folder. Use `ah.list('shared/%s')` for Python "
                'API or `ah ls shared/%s` for CLI to get original paths.',
                red(lib), asset_kind, asset_kind)
            raise RuntimeError(
                "'{}' cannot be used as a prefix for the path".format(lib))
        subpath = ''
        scope = 'shared'

    elif m := re.match(rf'/public/t9k-assethub/{asset}', path):
        if len(path) > m.end():
            lib = path[:m.end()]
            asset_kind = lib.split(sep='/')[-1]
            _logger.error(
                '%s cannot be used as a prefix for the path, as there may be '
                'public Folders with the same name, please use the original '
                "path of the Folder. Use `ah.list('/public/t9k-assethub/%s')` "
                'for Python API or `ah ls /public/t9k-assethub/%s` for CLI to '
                'get original paths.', red(lib), asset_kind, asset_kind)
            raise RuntimeError(
                "'{}' cannot be used as a prefix for the path".format(lib))
        subpath = ''
        scope = 'public'

    elif m := re.match(rf'/{name}/t9k-assethub/{asset}', path):
        # check user name later
        subpath = path[m.end():]
        scope = 'own'

    else:
        invalid_path()

    if subpath == '':
        kind = Kind.FOLDER_PARENT
    elif re.fullmatch(rf'/{name}', subpath):
        kind = Kind.FOLDER
    elif re.fullmatch(rf'/{name}/{name}', subpath):
        kind = Kind.ASSET
    elif re.fullmatch(rf'/{name}/{name}:{name}', subpath):
        kind = Kind.REFERENCE
    else:
        invalid_path()

    return path, kind, scope


if __name__ == '__main__':
    pass
