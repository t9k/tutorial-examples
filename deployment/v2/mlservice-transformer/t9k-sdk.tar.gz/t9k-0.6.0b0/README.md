# TensorStack SDK

This repo hosts SDK for using TensorStack AI platform, including support for:

- autotune, hyper-parameter optimization

## Links

## install

```bash
pip install .
```

## build image
