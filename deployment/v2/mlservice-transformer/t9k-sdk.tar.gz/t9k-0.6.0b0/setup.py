import os
import setuptools


def read(fname):
    return open(os.path.join(os.path.dirname(__file__), fname),
                encoding='utf-8').read()


setuptools.setup(name='t9k',
                 version='0.6.0b0',
                 packages=setuptools.find_packages(),
                 python_requires='>=3.8',
                 install_requires=[
                     'click',
                     'GitPython',
                     'json_tricks',
                     'jsonstream',
                     'kubernetes',
                     'numpy',
                     'onnx',
                     'python-dateutil',
                     'pyyaml',
                     'requests',
                     'rich',
                     'simplejson',
                     'tabulate',
                     'tornado',
                     'watchdog',
                 ],
                 entry_points={
                     'console_scripts': [
                         'em = t9k.em.cli:cli',
                         'ah = t9k.ah.cli:cli',
                     ],
                 },
                 author='TensorStack',
                 author_email='demo@tensorstack.com',
                 description='T9k Python SDK',
                 license='MIT',
                 long_description=read('README.md'))
